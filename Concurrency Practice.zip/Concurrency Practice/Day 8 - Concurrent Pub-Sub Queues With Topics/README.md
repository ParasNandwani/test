# Day 8: Concurrent Pub-Sub Queues With Topics

---

## The Interview Question

> *"Design a pub-sub message broker where multiple publishers can send events to named topics, and each subscriber receives every message independently. A slow subscriber must NOT stall the publisher or other subscribers. What's your isolation strategy?"*

**What the interviewer is testing:**
- Do you understand fan-out patterns and per-subscriber isolation?
- Can you articulate backpressure strategies and when to use BLOCK vs DROP?
- Do you know how to prevent a BLOCK subscriber from stalling the publisher (async delivery threads)?
- Can you reason about memory leaks in long-running pub-sub systems?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: The Problem We're Solving](#part-1-the-problem-were-solving)
2. [Part 2: Messaging Patterns](#part-2-messaging-patterns)
3. [Part 3: Design Problem — Slow Subscribers](#part-3-design-problem--slow-subscribers)
4. [Part 4: Design Problem — Buffer Full](#part-4-design-problem--buffer-full)
5. [Part 5: Design Problem — BLOCK Without Stalling](#part-5-design-problem--block-without-stalling)
6. [Part 6: Design Problem — Memory Leaks](#part-6-design-problem--memory-leaks)
7. [Part 7: System Architecture](#part-7-system-architecture)
8. [Part 8: Code Walkthrough](#part-8-code-walkthrough)
9. [How to Run](#how-to-run)
10. [Design Decisions Summary](#design-decisions-summary)
11. [Directory Structure](#directory-structure)

---

## Part 1: The Problem We're Solving

Imagine you're building the infrastructure for a stock exchange. Every time a trade executes, hundreds of systems need to know about it simultaneously:
- A **real-time dashboard** needs the latest price.
- An **analytics engine** aggregates trade volumes.
- A **compliance monitor** checks for suspicious patterns.
- A **mobile notification service** alerts users about price movements.

Each of these consumers processes at different speeds. The dashboard is lightning-fast. The analytics engine crunches numbers and is slower. The compliance monitor sometimes stalls for 30 seconds while querying external databases.

**The core question:** How do you deliver every trade event to all of these consumers, concurrently, without any single slow consumer dragging down the entire system?

This is the problem a **Pub-Sub Message Broker** solves. And when you add concurrency (multiple publishers, multiple subscribers, all on different threads), it becomes a fascinating systems design challenge involving thread safety, backpressure, memory management, and isolation guarantees.

That's exactly what we build in this project.

---

## Part 2: Messaging Patterns

Before we design our broker, we need to understand the two fundamental patterns for moving messages.

---

### Pattern A: Point-to-Point Queue

```
Producer ──► [ Queue ] ──► Consumer
                           (exactly one)
```

**How it works:**
- A producer places a message onto a queue.
- Exactly **one** consumer picks it up and processes it.
- Once consumed, the message is gone — no other consumer sees it.
- If multiple consumers listen, they **compete** (load-balancing).

**When to use it:** Job/task distribution. "Process this order" or "resize this image" — you want the work done once, by whoever is free.

**Real-world analogy:** A single printer queue in an office. You send a document, one printer prints it, done.

---

### Pattern B: Publish-Subscribe (Pub-Sub) — Our Model

```
Publisher ──► [ Topic: "trades" ] ──┬──► Subscriber A (dashboard)
                                    ├──► Subscriber B (analytics)
                                    └──► Subscriber C (compliance)
```

**How it works:**
- A publisher sends a message to a **topic** — a named logical channel.
- **Every** subscriber registered to that topic gets its own copy (or reference) of the message.
- This is called **fan-out**: 1 message → N independent deliveries.
- Subscribers don't know about each other — they're independent observers.

**When to use it:** Event broadcasting. "A trade happened" and everyone who cares should know, independently.

**Real-world analogy:** A radio station. When the DJ speaks, every tuned-in radio receives the broadcast independently. One radio being turned off doesn't affect the others.

**Key difference from Point-to-Point:**

| | Point-to-Point | Pub-Sub |
|---|---|---|
| Consumers per message | Exactly 1 | All registered (N) |
| Consumer relationship | Competing | Independent |
| Message after delivery | Gone | Still available to others |
| Use case | Task dispatch | Event broadcasting |

---

## Part 3: Design Problem — Slow Subscribers

Now that we're building Pub-Sub, let's face the first real challenge.

---

### The Scenario

Our broker has a topic `"trades"` with three subscribers:
- **Dashboard** — consumes in 1ms (fast)
- **Analytics** — consumes in 10ms (moderate)
- **Compliance** — consumes in 500ms (slow, queries external DB)

The publisher pushes 1,000 messages per second.

---

### The Naive Approach: Shared Buffer

The simplest implementation gives the topic **one shared queue** that all subscribers read from.

```
Publisher ──► [ Shared Queue ] ──► Dashboard, Analytics, Compliance all read from here
```

**What goes wrong:**
1. Compliance processes at 2 msgs/sec. The queue fills up because messages arrive at 1,000/sec.
2. Once the shared queue is full, the **publisher blocks** (or drops for everyone).
3. Dashboard and Analytics — perfectly healthy and fast — are **starved**. They can't get messages because the queue is backed up behind Compliance.

This is **head-of-line blocking**: one slow entity at the head of a shared resource stalls everyone behind it. It's the same reason a single slow checkout lane at a grocery store makes everyone in that line wait, even if they only have one item.

---

### Solution Approaches

| Approach | How it works | Pros | Cons |
|----------|-------------|------|------|
| **Shared queue** | All subscribers read from one queue | Simple, low memory | Head-of-line blocking; slow consumer stalls all |
| **Per-subscriber buffer** | Each subscriber gets its own independent queue | Full isolation; slow consumer only affects itself | More memory (N buffers × capacity); must manage each buffer independently |
| **Broadcast + pull** | Messages stored in topic log, each subscriber tracks its own offset | Zero-copy, unlimited replay | Complex offset management; requires retention policy |

---

### Our Choice: Per-Subscriber Isolated Buffers

```
Publisher ──► Topic ──┬──► [Buffer: Dashboard]   capacity=1000  ← fast, never fills
                      ├──► [Buffer: Analytics]   capacity=1000  ← moderate, rarely fills
                      └──► [Buffer: Compliance]  capacity=1000  ← slow, fills up!
```

Each subscriber gets its own private `ArrayBlockingQueue` with a fixed capacity. When the topic fans out a message:
- It attempts to insert into **each buffer independently**.
- If Compliance's buffer is full → only Compliance is affected.
- Dashboard and Analytics continue receiving unimpeded.

**Why this is the right trade-off for us:**
- **Fault isolation** — a misbehaving consumer cannot cascade failures to peers.
- **Independent consumption rates** — each subscriber processes at its own pace.
- **Predictable memory** — each buffer has a known max capacity (no surprise OOM from one subscriber).
- **Simplicity** — no complex offset tracking or log compaction needed.

---

## Part 4: Design Problem — Buffer Full

Great, each subscriber has its own buffer. But buffers are **bounded** (we can't allocate infinite memory). So what happens when a subscriber falls behind and its buffer reaches capacity?

This is the **backpressure** problem. There is no free lunch — the system must choose a strategy.

---

### The Scenario

Compliance's buffer (capacity 1000) is full. A new trade message arrives. What should the system do?

---

### Solution Approaches

| Strategy | What happens | Real-world analogy | Best for | Danger |
|----------|-------------|-------------------|----------|--------|
| **BLOCK** | Wait until space opens in the buffer | A full mailbox where the postman stands at the door until you empty it | Guaranteed delivery (zero loss) | If done naively, the waiting stalls the publisher AND other subscribers |
| **DROP** | Discard the message for this subscriber only | A full voicemail inbox — new callers hear "mailbox full" | High-throughput systems where occasional loss is acceptable (metrics, telemetry) | Subscriber permanently misses data |
| **DROP_OLDEST** | Remove the oldest message from the buffer, insert the new one | A news ticker that always shows the latest N headlines | "Latest state" systems (GPS position, live scores) | Historical events are lost |
| **Signal/Alert** | Drop the message but log a warning | A security camera that records "FRAMES DROPPED" but keeps going | Monitoring/observability | Doesn't fix the underlying capacity issue |

---

### Our Choice: Configurable Per-Subscriber Strategy

We don't pick one strategy for the whole system. Instead, **each subscriber declares its own backpressure strategy** at creation time:

```java
Subscriber dashboard  = new Subscriber("dashboard",  1000, BackpressureStrategy.DROP);       // OK to lose occasional updates
Subscriber compliance = new Subscriber("compliance", 1000, BackpressureStrategy.BLOCK);      // Cannot lose any event
Subscriber gps        = new Subscriber("gps",        100,  BackpressureStrategy.DROP_OLDEST); // Only latest position matters
```

This way, the system respects each consumer's requirements without forcing a one-size-fits-all policy.

**Default:** `DROP` — safest for overall system health. A slow subscriber dropping messages is far less catastrophic than a slow subscriber blocking the entire broker.

---

## Part 5: Design Problem — BLOCK Without Stalling

The BLOCK strategy guarantees zero message loss — the system waits until the subscriber has space. But this introduces the most subtle concurrency bug in the entire design.

---

### The Naive (Broken) Implementation

If the Topic fans out messages **synchronously on the publisher's thread**, here's what happens:

```java
// Topic.publish() — NAIVE VERSION (broken)
public void publish(Message message) {
    for (Subscriber sub : subscribers) {
        sub.onMessage(message);  // ← if sub uses BLOCK and buffer is full, THIS LINE HANGS
    }
}
```

**Execution trace when Compliance (BLOCK, full buffer) is first in the list:**

```
Publisher Thread:
  1. publish("AAPL trade") 
  2. → Topic iterates subscribers
  3. → sub[0] = Compliance → buffer.put(msg) → BLOCKS (buffer full!)
  4. ... publisher thread is frozen here ...
  5. → sub[1] = Dashboard  → NEVER REACHED
  6. → sub[2] = Analytics  → NEVER REACHED
```

**The cascade of damage:**
- Dashboard and Analytics get **zero messages** — they're stuck behind Compliance in the loop.
- The publisher thread itself is **completely frozen** — it cannot publish to ANY topic (trades, news, alerts... nothing) until Compliance drains a message.
- If the publisher was also supposed to handle heartbeats or produce to other topics, those are now stalled too.

One slow subscriber has effectively **taken down the entire system**. This is the exact head-of-line blocking we said per-subscriber buffers would prevent — but with naive BLOCK, the blocking just moved from "shared queue" to "fan-out loop."

---

### Solution Approaches

| Approach | How it works | Pros | Cons |
|----------|-------------|------|------|
| **Synchronous fan-out** (naive) | Publisher thread calls each subscriber sequentially | Simplest code | BLOCK subscriber stalls publisher + all peers |
| **Per-subscriber delivery thread** | Each subscriber has its own thread; Topic submits async to each | Perfect isolation; publisher never blocks | 1 thread per subscriber; unbounded delivery queue can grow if consumer is stuck forever |
| **Shared fan-out thread pool** | Topic submits deliveries to a shared N-thread pool | Fewer threads; good resource utilization | If many subscribers BLOCK, pool can be exhausted; imperfect isolation |
| **Bounded delivery queue + CallerRunsPolicy** | Like per-subscriber thread, but with bounded internal queue; when full, publisher thread runs the task itself | Natural backpressure to publisher for that sub only; bounded memory | More complex; publisher experiences per-subscriber slowdown |

---

### Our Choice: Per-Subscriber Delivery Thread (Unbounded Queue)

Each subscriber internally owns a **dedicated single-threaded executor**. When the Topic fans out a message, it calls `submitAsync(message)` which:
1. Enqueues a task to the subscriber's private delivery thread.
2. **Returns immediately** — the publisher thread is never blocked.

The delivery thread later executes `buffer.put(message)`, which may block. But crucially — it only blocks **that subscriber's delivery thread**, not the publisher or any other subscriber.

**Execution trace with the fix:**

```
Publisher Thread:                         Compliance's Delivery Thread:
  │                                            │
  ├─ submitAsync(msg) to Compliance            │
  │   → enqueues task to delivery queue        │
  │   → RETURNS IMMEDIATELY                    │
  │                                            ├─ picks up task
  ├─ submitAsync(msg) to Dashboard             │   → buffer.put(msg)
  │   → RETURNS IMMEDIATELY                    │   → BLOCKS (buffer full!)
  │                                            │   ... waits for consumer to drain ...
  ├─ submitAsync(msg) to Analytics             │
  │   → RETURNS IMMEDIATELY                    │
  │                                            │
  ├─ publish() returns! Publisher is free.     │  (only this thread is stuck)
  │   Can publish to other topics now.         │
```

**The known trade-off:**
The delivery thread uses `newSingleThreadExecutor()` which internally has an **unbounded** `LinkedBlockingQueue`. If the subscriber's consumer never drains its buffer:
- The delivery thread stays blocked on `buffer.put()`.
- New `submitAsync()` calls keep adding tasks to the executor's internal queue.
- Memory grows without limit → eventual `OutOfMemoryError`.

**How production systems fix this (we accept the trade-off for simplicity):**
Replace `newSingleThreadExecutor()` with a `ThreadPoolExecutor` using:
- A **bounded** `ArrayBlockingQueue` (e.g., capacity 128) as the task queue.
- `CallerRunsPolicy` as the rejection handler — when the delivery queue is full, the **publisher's thread** executes the delivery itself, naturally applying backpressure to the publisher for that one subscriber only.

This gives a two-tier buffer: `[Delivery Queue (128)] → Delivery Thread → [Subscriber Buffer (N)] → Consumer`. The bounded delivery queue acts as a shock absorber — smooths out brief bursts without blocking the publisher, but slows the publisher naturally if the subscriber is truly dead.

---

## Part 6: Design Problem — Memory Leaks

The last problem is insidious because it doesn't crash your system immediately — it slowly eats memory over hours or days.

---

### The Problem

In Pub-Sub, a `Message` object is created by the publisher and then placed (by reference) into N subscriber buffers. The JVM's garbage collector can only reclaim a message when **all references** to it are gone. If any subscriber holds a reference forever, the message lives forever.

---

### Scenarios That Cause Leaks

| Scenario | What happens | Memory impact |
|----------|-------------|---------------|
| **Unbounded buffer** | Subscriber's queue grows without limit as messages pile up | Linear memory growth → OOM in hours/days |
| **Subscriber registers but never consumes** | Buffer fills; if BLOCK strategy, delivery queue grows unboundedly too | Silent memory growth |
| **Topic-level replay/history** | All messages stored in a topic log for "replay" without TTL | Entire message history retained forever |
| **Dead subscriber not deregistered** | Subscriber object + buffer held in topic's subscriber set permanently | Reference leak even after consumer is gone |

---

### Our Safeguards

| Safeguard | How it prevents leaks |
|-----------|----------------------|
| **Bounded buffers** (`ArrayBlockingQueue`) | Structurally impossible to hold more than `capacity` messages per subscriber. Once full, messages are dropped or blocked — but memory is capped. |
| **DROP/DROP_OLDEST policies** | Actively discard messages when buffer is at capacity. Old references are released for GC. |
| **Immutable messages** | `Message` objects are created once and never mutated. Safe to share across threads by reference. Once all buffers release the reference, GC reclaims it naturally. No defensive copying needed. |
| **Clean deregistration** | `Topic.unsubscribe(subscriber)` removes the subscriber from the set. The subscriber's buffer + delivery thread + all message references become eligible for GC. |
| **No topic-level retention** | We don't store message history in the Topic itself. Once fan-out is complete, the Topic holds no reference to the message. |

**The key insight:** With bounded buffers and no topic-level retention, memory usage is **statically determinable**: `total memory ≤ (num_subscribers × buffer_capacity × avg_message_size)`. No surprises.

---

## Part 7: System Architecture

Here's the complete picture showing how all the design decisions connect:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                            MessageBroker                                     │
│        (Thread-safe Topic Registry: ConcurrentHashMap<String, Topic>)        │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   Publisher Thread                                                           │
│        │                                                                    │
│        ├── broker.publish("trades", "AAPL=$150")                            │
│        │         │                                                          │
│        │         ▼                                                          │
│        │   Topic["trades"]                                                  │
│        │         │                                                          │
│        │         ├── submitAsync(msg) to Sub-A ──► [Delivery Thread A]      │
│        │         │      (returns immediately)            │                  │
│        │         │                                       ▼                  │
│        │         │                               buffer.offer(msg) [DROP]   │
│        │         │                                       │                  │
│        │         │                                       ▼                  │
│        │         │                               [Buffer A: ████░░░░]       │
│        │         │                                  Consumer A drains       │
│        │         │                                                          │
│        │         ├── submitAsync(msg) to Sub-B ──► [Delivery Thread B]      │
│        │         │      (returns immediately)            │                  │
│        │         │                                       ▼                  │
│        │         │                               buffer.put(msg) [BLOCK]    │
│        │         │                                       │                  │
│        │         │                                       ▼                  │
│        │         │                               [Buffer B: ████████] FULL! │
│        │         │                               Thread B blocks here       │
│        │         │                               (only B is affected)       │
│        │         │                                                          │
│        │         └── submitAsync(msg) to Sub-C ──► [Delivery Thread C]      │
│        │                (returns immediately)            │                  │
│        │                                                 ▼                  │
│        │                                         buffer.offer(msg) [DROP]   │
│        │                                                 │                  │
│        │                                                 ▼                  │
│        │                                         [Buffer C: ██░░░░░░]       │
│        │                                            Consumer C drains       │
│        │                                                                    │
│        ├── publish() returns! Publisher free to do other work.              │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

**Mapping design decisions to problems solved:**

| Problem | Decision | Result |
|---------|----------|--------|
| Slow subscriber stalls peers | Per-subscriber buffers | Fault isolation |
| Buffer full — what to do? | Configurable backpressure (DROP/BLOCK/DROP_OLDEST) | Each subscriber gets appropriate strategy |
| BLOCK stalls publisher | Per-subscriber delivery thread + async submitAsync() | Publisher never blocks |
| Memory leaks over time | Bounded buffers + immutable messages + clean deregistration | Memory statically bounded |
| Concurrent publishers | ConcurrentHashMap for topic registry + thread-safe queues | Lock-free reads, safe writes |
| Topic doesn't exist yet | computeIfAbsent — idempotent creation | Race-free topic creation |
| Graceful shutdown | AtomicBoolean flag + reject new publishes + allow drain | Clean lifecycle, no lost InterruptedExceptions |

---

## Part 8: Code Walkthrough

Read the code in this order for maximum understanding. Each file builds on concepts from the previous.

### File 1: `engine/Message.java` — Start Here (Simplest)
**What to look for:**
- All fields are `final` — immutable by construction.
- UUID + timestamp assigned at creation — each message is uniquely identifiable.
- Safe to share across threads without synchronization or copying.

### File 2: `engine/Subscriber.java` — The Core Isolation Mechanism
**What to look for:**
- `ArrayBlockingQueue<Message> buffer` — the per-subscriber bounded buffer.
- `BackpressureStrategy` enum — configurable behavior when full.
- `ExecutorService deliveryThread` — the dedicated per-subscriber delivery thread.
- `submitAsync(Message)` — the non-blocking entry point called by Topic during fan-out.
- `onMessage(Message)` — the actual backpressure logic (runs on delivery thread, not publisher thread).
- `poll()` / `take()` / `drainAll()` — consumer-side methods to retrieve messages.
- `shutdownDelivery()` — graceful lifecycle cleanup.

### File 3: `engine/Topic.java` — Fan-Out Logic
**What to look for:**
- `CopyOnWriteArraySet<Subscriber>` — safe concurrent iteration during fan-out while allowing subscribe/unsubscribe at any time.
- `publish(Message)` — iterates all subscribers, calls `subscriber.submitAsync(message)` — non-blocking.
- `subscribe()` / `unsubscribe()` — dynamic registration.

### File 4: `engine/MessageBroker.java` — The Global Registry
**What to look for:**
- `ConcurrentHashMap<String, Topic>` — thread-safe topic lookup.
- `computeIfAbsent(topicName, Topic::new)` — idempotent, race-free topic creation.
- `publish(topicName, payload)` — creates Message, routes to Topic.
- `shutdown()` + `isShutdown()` — graceful lifecycle with AtomicBoolean.

### File 5: `runners/InterviewLeanPubSub.java` — Clean Demonstration
**What to look for:** A step-by-step walkthrough of all features in under 150 lines. Suitable for whiteboard presentation. Demonstrates DROP isolation, multi-topic, concurrent publishers, BLOCK isolation, and graceful shutdown.

### File 6: `runners/ComprehensivePubSubStressTest.java` — Proof Under Pressure
**What to look for:** 6 scenarios stress-testing high volume, slow subscriber isolation, dynamic subscription, graceful shutdown, throughput benchmarks, and BLOCK isolation with assertions.

---

## How to Run

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day8:run                                                          # Runs InterviewLeanPubSub
./gradlew :day8:run -PmainClass=runners.ComprehensivePubSubStressTest        # Runs stress test
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on any `main()` method directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out runners.InterviewLeanPubSub
java -ea -cp out runners.ComprehensivePubSubStressTest
```

---

## Design Decisions Summary

| Decision | Problem it solves | Alternative considered | Why we rejected it |
|----------|------------------|----------------------|-------------------|
| `ConcurrentHashMap` for topic registry | Concurrent publisher access | `synchronized HashMap` | Lock contention at high publish rates |
| `ArrayBlockingQueue` per subscriber | Bounded, thread-safe buffer | `LinkedBlockingQueue` | Array-backed = better cache locality, fixed memory |
| Immutable `Message` | Thread-safe sharing | Mutable message with synchronized access | Synchronization overhead; defensive copies expensive |
| `CopyOnWriteArraySet` for subscriber set | Safe iteration during fan-out + dynamic subscribe/unsubscribe | `synchronized ArrayList` | Reads (fan-out) vastly outnumber writes (subscribe) — COWAS is optimal for this ratio |
| Per-subscriber `SingleThreadExecutor` | BLOCK subscriber not stalling publisher/peers | Shared thread pool | Pool exhaustion if many subscribers BLOCK simultaneously |
| `submitAsync()` non-blocking fan-out | Publisher thread isolation | Synchronous `onMessage()` | Synchronous couples publisher to slowest consumer |
| Configurable `BackpressureStrategy` | Different subscribers have different SLAs | Single global policy | Compliance needs BLOCK, dashboard is fine with DROP — one size doesn't fit all |
| `AtomicBoolean` shutdown flag | Graceful lifecycle | `volatile boolean` | AtomicBoolean provides CAS semantics if needed; signals intent clearly |
| Daemon delivery threads | JVM can exit cleanly | Non-daemon threads | Non-daemon threads prevent JVM shutdown if subscribers are never explicitly stopped |

---

## Directory Structure

```
src/
├── engine/
│   ├── Message.java            # Immutable payload wrapper (UUID, topic, payload, timestamp)
│   ├── Subscriber.java         # Per-subscriber buffer + delivery thread + backpressure logic
│   ├── Topic.java              # Named channel, fan-out via async submitAsync()
│   └── MessageBroker.java      # Global registry, routing, lifecycle management
└── runners/
    ├── InterviewLeanPubSub.java              # Whiteboard-ready demo (~150 lines)
    └── ComprehensivePubSubStressTest.java    # 6-scenario stress test with assertions
```

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
