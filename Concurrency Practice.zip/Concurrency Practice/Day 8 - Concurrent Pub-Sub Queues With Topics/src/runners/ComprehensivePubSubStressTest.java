package runners;

import engine.Message;
import engine.MessageBroker;
import engine.Subscriber;
import engine.Subscriber.BackpressureStrategy;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Comprehensive multi-threaded stress test for the Pub-Sub engine.
 *
 * Scenarios covered:
 * 1. Multiple publishers pushing to distinct topics concurrently.
 * 2. Multiple subscribers with varying speeds (fast vs slow consumers).
 * 3. Dynamic subscriber registration mid-stream.
 * 4. Backpressure validation — slow subscribers drop messages without stalling fast ones.
 * 5. Graceful shutdown with drain verification.
 * 6. High volume throughput measurement.
 */
public class ComprehensivePubSubStressTest {

    private static final int NUM_TOPICS = 5;
    private static final int PUBLISHERS_PER_TOPIC = 3;
    private static final int MESSAGES_PER_PUBLISHER = 10_000;
    private static final int FAST_SUBSCRIBERS_PER_TOPIC = 2;
    private static final int SUBSCRIBER_BUFFER_CAPACITY = 512;

    public static void main(String[] args) throws Exception {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║   COMPREHENSIVE PUB-SUB STRESS TEST                          ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
        System.out.println();

        runScenario1_HighVolumeFanOut();
        System.out.println();
        runScenario2_SlowSubscriberIsolation();
        System.out.println();
        runScenario3_DynamicSubscription();
        System.out.println();
        runScenario4_GracefulShutdownAndDrain();
        System.out.println();
        runScenario5_ThroughputBenchmark();
        System.out.println();
        runScenario6_BlockStrategyIsolation();

        System.out.println();
        System.out.println("═══════════════════════════════════════════════════════════════");
        System.out.println("  ALL STRESS TEST SCENARIOS COMPLETED SUCCESSFULLY");
        System.out.println("═══════════════════════════════════════════════════════════════");
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SCENARIO 1: High Volume Fan-Out — Multiple publishers, multiple topics
    // ─────────────────────────────────────────────────────────────────────────────
    private static void runScenario1_HighVolumeFanOut() throws Exception {
        System.out.println("┌─── Scenario 1: High Volume Fan-Out ───────────────────────┐");

        MessageBroker broker = new MessageBroker();
        ExecutorService publisherPool = Executors.newFixedThreadPool(NUM_TOPICS * PUBLISHERS_PER_TOPIC);
        ExecutorService consumerPool = Executors.newFixedThreadPool(NUM_TOPICS * FAST_SUBSCRIBERS_PER_TOPIC);

        // Create topics and subscribers
        List<Subscriber> allSubscribers = new ArrayList<>();
        for (int t = 0; t < NUM_TOPICS; t++) {
            String topicName = "topic-" + t;
            for (int s = 0; s < FAST_SUBSCRIBERS_PER_TOPIC; s++) {
                Subscriber sub = new Subscriber(
                        topicName + "-sub-" + s,
                        SUBSCRIBER_BUFFER_CAPACITY,
                        BackpressureStrategy.DROP
                );
                broker.subscribe(topicName, sub);
                allSubscribers.add(sub);
            }
        }

        // Track consumed messages
        AtomicLong totalConsumed = new AtomicLong(0);
        CountDownLatch publishingDone = new CountDownLatch(1);

        // Start consumer threads
        List<Future<?>> consumerFutures = new ArrayList<>();
        for (Subscriber sub : allSubscribers) {
            consumerFutures.add(consumerPool.submit(() -> {
                try {
                    while (!publishingDone.await(0, TimeUnit.MILLISECONDS) || sub.getBufferSize() > 0) {
                        Message msg = sub.poll(10, TimeUnit.MILLISECONDS);
                        if (msg != null) {
                            totalConsumed.incrementAndGet();
                        }
                    }
                    // Final drain
                    Message msg;
                    while ((msg = sub.poll()) != null) {
                        totalConsumed.incrementAndGet();
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }));
        }

        // Start publishers
        long startTime = System.nanoTime();
        List<Future<?>> publisherFutures = new ArrayList<>();
        for (int t = 0; t < NUM_TOPICS; t++) {
            String topicName = "topic-" + t;
            for (int p = 0; p < PUBLISHERS_PER_TOPIC; p++) {
                final int pubId = p;
                publisherFutures.add(publisherPool.submit(() -> {
                    for (int m = 0; m < MESSAGES_PER_PUBLISHER; m++) {
                        broker.publish(topicName, "pub-" + pubId + "-msg-" + m);
                    }
                }));
            }
        }

        // Wait for publishers to finish
        for (Future<?> f : publisherFutures) {
            f.get();
        }
        long publishDuration = System.nanoTime() - startTime;
        publishingDone.countDown();

        // Wait for consumers to finish
        for (Future<?> f : consumerFutures) {
            f.get(5, TimeUnit.SECONDS);
        }

        long totalPublished = (long) NUM_TOPICS * PUBLISHERS_PER_TOPIC * MESSAGES_PER_PUBLISHER;
        long totalFannedOut = totalPublished * FAST_SUBSCRIBERS_PER_TOPIC;

        System.out.printf("  Topics: %d | Publishers: %d | Messages/pub: %d%n",
                NUM_TOPICS, NUM_TOPICS * PUBLISHERS_PER_TOPIC, MESSAGES_PER_PUBLISHER);
        System.out.printf("  Total published: %,d | Fan-out target: %,d%n", totalPublished, totalFannedOut);
        System.out.printf("  Total consumed: %,d | Drop rate: %.2f%%%n",
                totalConsumed.get(), (1.0 - (double) totalConsumed.get() / totalFannedOut) * 100);
        System.out.printf("  Publish throughput: %,.0f msgs/sec%n",
                totalPublished / (publishDuration / 1_000_000_000.0));

        publisherPool.shutdown();
        consumerPool.shutdown();
        broker.shutdown();

        System.out.println("└───────────────────────────────────────────────────────────┘");
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SCENARIO 2: Slow Subscriber Isolation — prove slow consumers don't block fast ones
    // ─────────────────────────────────────────────────────────────────────────────
    private static void runScenario2_SlowSubscriberIsolation() throws Exception {
        System.out.println("┌─── Scenario 2: Slow Subscriber Isolation ─────────────────┐");

        MessageBroker broker = new MessageBroker();
        String topic = "price-updates";

        // Fast subscriber with large buffer
        Subscriber fastSub = new Subscriber("fast-consumer", 10_000, BackpressureStrategy.DROP);
        // Slow subscriber with tiny buffer (simulates a consumer that can't keep up)
        Subscriber slowSub = new Subscriber("slow-consumer", 16, BackpressureStrategy.DROP);

        broker.subscribe(topic, fastSub);
        broker.subscribe(topic, slowSub);

        // Publish 5000 messages rapidly
        int messageCount = 5000;
        for (int i = 0; i < messageCount; i++) {
            broker.publish(topic, "price-" + i);
        }

        // Allow delivery threads to process (fan-out is async)
        Thread.sleep(500);

        System.out.printf("  Published: %,d messages to '%s'%n", messageCount, topic);
        System.out.printf("  Fast subscriber: received=%d, dropped=%d, buffer=%d/%d%n",
                fastSub.getReceivedCount(), fastSub.getDroppedCount(),
                fastSub.getBufferSize(), fastSub.getCapacity());
        System.out.printf("  Slow subscriber: received=%d, dropped=%d, buffer=%d/%d%n",
                slowSub.getReceivedCount(), slowSub.getDroppedCount(),
                slowSub.getBufferSize(), slowSub.getCapacity());

        // Verify isolation: fast subscriber got all messages, slow one dropped most
        assert fastSub.getReceivedCount() == messageCount :
                "Fast subscriber should have received all messages!";
        assert slowSub.getDroppedCount() > 0 :
                "Slow subscriber should have dropped some messages!";
        assert fastSub.getDroppedCount() == 0 :
                "Fast subscriber should NOT have dropped any messages!";

        System.out.println("  ✓ VERIFIED: Slow subscriber drops did NOT affect fast subscriber");

        broker.shutdown();
        System.out.println("└───────────────────────────────────────────────────────────┘");
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SCENARIO 3: Dynamic Subscription — subscribers join mid-stream
    // ─────────────────────────────────────────────────────────────────────────────
    private static void runScenario3_DynamicSubscription() throws Exception {
        System.out.println("┌─── Scenario 3: Dynamic Subscription ──────────────────────┐");

        MessageBroker broker = new MessageBroker();
        String topic = "events";

        Subscriber earlyBird = new Subscriber("early-bird", 1000, BackpressureStrategy.DROP);
        broker.subscribe(topic, earlyBird);

        // Publish first batch — only earlyBird receives
        for (int i = 0; i < 100; i++) {
            broker.publish(topic, "batch1-msg-" + i);
        }

        // Allow delivery thread to process
        Thread.sleep(100);

        // Late subscriber joins
        Subscriber lateComer = new Subscriber("late-comer", 1000, BackpressureStrategy.DROP);
        broker.subscribe(topic, lateComer);

        // Publish second batch — both receive
        for (int i = 0; i < 100; i++) {
            broker.publish(topic, "batch2-msg-" + i);
        }

        // Allow delivery threads to process
        Thread.sleep(100);

        System.out.printf("  Early bird: received=%d (should be 200)%n", earlyBird.getReceivedCount());
        System.out.printf("  Late comer: received=%d (should be 100)%n", lateComer.getReceivedCount());

        assert earlyBird.getReceivedCount() == 200 : "Early bird should have 200 messages";
        assert lateComer.getReceivedCount() == 100 : "Late comer should have 100 messages";

        System.out.println("  ✓ VERIFIED: Dynamic subscription works correctly");

        // Test unsubscribe
        broker.unsubscribe(topic, earlyBird);

        // Publish third batch — only lateComer receives
        for (int i = 0; i < 50; i++) {
            broker.publish(topic, "batch3-msg-" + i);
        }

        // Allow delivery threads to process
        Thread.sleep(100);

        assert earlyBird.getReceivedCount() == 200 : "Unsubscribed early bird should still have 200";
        assert lateComer.getReceivedCount() == 150 : "Late comer should now have 150";

        System.out.println("  ✓ VERIFIED: Unsubscription stops message delivery");

        broker.shutdown();
        System.out.println("└───────────────────────────────────────────────────────────┘");
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SCENARIO 4: Graceful Shutdown — ensure drain and no exceptions
    // ─────────────────────────────────────────────────────────────────────────────
    private static void runScenario4_GracefulShutdownAndDrain() throws Exception {
        System.out.println("┌─── Scenario 4: Graceful Shutdown & Drain ─────────────────┐");

        MessageBroker broker = new MessageBroker();
        String topic = "shutdown-test";

        Subscriber sub = new Subscriber("drain-sub", 500, BackpressureStrategy.DROP);
        broker.subscribe(topic, sub);

        // Publish messages
        for (int i = 0; i < 300; i++) {
            broker.publish(topic, "msg-" + i);
        }

        // Allow delivery thread to process
        Thread.sleep(200);

        System.out.printf("  Pre-shutdown: buffered=%d%n", sub.getBufferSize());

        // Shutdown broker
        broker.shutdown();

        // Verify no new publishes allowed
        boolean exceptionThrown = false;
        try {
            broker.publish(topic, "should-fail");
        } catch (IllegalStateException e) {
            exceptionThrown = true;
        }
        assert exceptionThrown : "Publishing after shutdown should throw";
        System.out.println("  ✓ VERIFIED: Publish rejected after shutdown");

        // Drain remaining messages
        List<Message> drained = sub.drainAll();
        System.out.printf("  Drained %d messages after shutdown%n", drained.size());
        assert drained.size() == 300 : "Should drain all 300 messages";
        assert sub.getBufferSize() == 0 : "Buffer should be empty after drain";

        System.out.println("  ✓ VERIFIED: Graceful drain completed successfully");
        System.out.println("└───────────────────────────────────────────────────────────┘");
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SCENARIO 5: Throughput Benchmark — measure raw publish speed
    // ─────────────────────────────────────────────────────────────────────────────
    private static void runScenario5_ThroughputBenchmark() throws Exception {
        System.out.println("┌─── Scenario 5: Throughput Benchmark ──────────────────────┐");

        MessageBroker broker = new MessageBroker();
        String topic = "benchmark";
        int numSubscribers = 10;
        int numMessages = 100_000;

        // Register many subscribers (buffer must be >= numMessages to guarantee zero drops)
        List<Subscriber> subs = new ArrayList<>();
        for (int i = 0; i < numSubscribers; i++) {
            Subscriber sub = new Subscriber("bench-sub-" + i, numMessages, BackpressureStrategy.DROP);
            broker.subscribe(topic, sub);
            subs.add(sub);
        }

        // Benchmark single-threaded publish with fan-out to 10 subscribers
        long start = System.nanoTime();
        for (int i = 0; i < numMessages; i++) {
            broker.publish(topic, "bench-" + i);
        }
        long elapsed = System.nanoTime() - start;

        double seconds = elapsed / 1_000_000_000.0;
        double msgsPerSec = numMessages / seconds;
        double fansPerSec = (numMessages * (long) numSubscribers) / seconds;

        System.out.printf("  Messages: %,d | Subscribers: %d%n", numMessages, numSubscribers);
        System.out.printf("  Elapsed: %.3f sec%n", seconds);
        System.out.printf("  Publish rate: %,.0f msgs/sec%n", msgsPerSec);
        System.out.printf("  Fan-out rate: %,.0f deliveries/sec%n", fansPerSec);

        // Allow delivery threads to fully process all messages
        Thread.sleep(2000);

        // Verify all subscribers received all messages (buffer large enough)
        for (Subscriber sub : subs) {
            assert sub.getReceivedCount() == numMessages :
                    sub.getName() + " should have received all " + numMessages + " messages, got: " + sub.getReceivedCount();
        }
        System.out.println("  ✓ VERIFIED: All subscribers received all messages");

        // Multi-threaded publish benchmark
        int numThreads = 8;
        int msgsPerThread = 50_000;
        ExecutorService pool = Executors.newFixedThreadPool(numThreads);

        // Reset with fresh broker
        MessageBroker broker2 = new MessageBroker();
        Subscriber singleSub = new Subscriber("mt-sub", numThreads * msgsPerThread, BackpressureStrategy.DROP);
        broker2.subscribe("mt-bench", singleSub);

        long mtStart = System.nanoTime();
        List<Future<?>> futures = new ArrayList<>();
        for (int t = 0; t < numThreads; t++) {
            final int threadId = t;
            futures.add(pool.submit(() -> {
                for (int m = 0; m < msgsPerThread; m++) {
                    broker2.publish("mt-bench", "t" + threadId + "-m" + m);
                }
            }));
        }
        for (Future<?> f : futures) {
            f.get();
        }
        long mtElapsed = System.nanoTime() - mtStart;

        long totalMt = (long) numThreads * msgsPerThread;
        double mtSeconds = mtElapsed / 1_000_000_000.0;

        System.out.printf("  Multi-threaded: %d threads × %,d msgs = %,d total%n",
                numThreads, msgsPerThread, totalMt);
        System.out.printf("  MT Elapsed: %.3f sec | Rate: %,.0f msgs/sec%n",
                mtSeconds, totalMt / mtSeconds);

        // Allow delivery thread to process all messages
        Thread.sleep(2000);

        assert singleSub.getReceivedCount() == totalMt :
                "MT subscriber should have received all " + totalMt + " messages, got: " + singleSub.getReceivedCount();
        System.out.println("  ✓ VERIFIED: Multi-threaded publish integrity maintained");

        pool.shutdown();
        broker.shutdown();
        broker2.shutdown();

        System.out.println("└───────────────────────────────────────────────────────────┘");
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SCENARIO 6: BLOCK Strategy Isolation — prove BLOCK subscriber doesn't stall
    //             the publisher or other subscribers (async delivery thread validation)
    // ─────────────────────────────────────────────────────────────────────────────
    private static void runScenario6_BlockStrategyIsolation() throws Exception {
        System.out.println("┌─── Scenario 6: BLOCK Strategy Isolation ──────────────────┐");
        System.out.println("  Testing: A BLOCK subscriber with a full buffer must NOT");
        System.out.println("  stall the publisher or other subscribers on the same topic.");
        System.out.println();

        MessageBroker broker = new MessageBroker();
        String topic = "block-test";

        // Fast subscriber (DROP strategy, large buffer) — should receive ALL messages
        Subscriber fastSub = new Subscriber("fast-drop-sub", 10_000, BackpressureStrategy.DROP);

        // BLOCK subscriber with tiny buffer (capacity=5) — will block its delivery thread
        // but must NOT block the publisher or the fast subscriber
        Subscriber blockSub = new Subscriber("block-sub", 5, BackpressureStrategy.BLOCK);

        // Slow subscriber (DROP strategy, small buffer) — uses SLOW_SUBSCRIBERS_PER_TOPIC concept
        // Simulates the originally-declared-but-unused slow subscriber pattern
        Subscriber slowDropSub = new Subscriber("slow-drop-sub", 16, BackpressureStrategy.DROP);

        broker.subscribe(topic, fastSub);
        broker.subscribe(topic, blockSub);
        broker.subscribe(topic, slowDropSub);

        int messageCount = 500;

        // Publish messages — this should return quickly because fan-out is async.
        // If BLOCK were synchronous, this would hang because blockSub's buffer (5)
        // fills up and buffer.put() would block the publisher thread forever.
        long publishStart = System.nanoTime();
        for (int i = 0; i < messageCount; i++) {
            broker.publish(topic, "block-test-msg-" + i);
        }
        long publishElapsed = System.nanoTime() - publishStart;
        double publishMs = publishElapsed / 1_000_000.0;

        // The publisher should return VERY quickly (< 1 second) because submitAsync is non-blocking.
        // If it took longer, the BLOCK subscriber is stalling the publisher (bug!).
        System.out.printf("  Publisher finished in %.1f ms (should be fast, NOT blocked)%n", publishMs);
        assert publishMs < 5000 : "Publisher took too long! BLOCK subscriber is stalling it. Took: " + publishMs + " ms";
        System.out.println("  ✓ VERIFIED: Publisher was NOT blocked by BLOCK subscriber");

        // Give the fast subscriber's delivery thread time to process
        Thread.sleep(200);

        // Fast subscriber should have received all messages (its buffer is large enough)
        System.out.printf("  Fast subscriber: received=%d (expected=%d)%n",
                fastSub.getReceivedCount(), messageCount);
        assert fastSub.getReceivedCount() == messageCount :
                "Fast subscriber should have received all " + messageCount + " messages, got: " + fastSub.getReceivedCount();
        System.out.println("  ✓ VERIFIED: Fast subscriber received ALL messages despite BLOCK peer");

        // Slow-drop subscriber should have received some and dropped the rest
        System.out.printf("  Slow-drop subscriber: received=%d, dropped=%d%n",
                slowDropSub.getReceivedCount(), slowDropSub.getDroppedCount());
        assert slowDropSub.getReceivedCount() > 0 : "Slow-drop subscriber should have received some messages";
        assert slowDropSub.getDroppedCount() > 0 : "Slow-drop subscriber should have dropped some messages";
        System.out.println("  ✓ VERIFIED: Slow-drop subscriber operated independently");

        // BLOCK subscriber: its buffer is only 5, but its delivery thread is blocked.
        // It should have received exactly 5 messages into its buffer (the first 5 fit).
        // The remaining messages are queued in its delivery thread's internal task queue.
        System.out.printf("  BLOCK subscriber: buffer=%d/%d (delivery thread blocked, tasks queued)%n",
                blockSub.getBufferSize(), blockSub.getCapacity());

        // Now simulate the consumer draining the BLOCK subscriber's buffer to unblock delivery
        System.out.println("  [Draining BLOCK subscriber to unblock its delivery thread...]");
        int drained = 0;
        long drainDeadline = System.currentTimeMillis() + 5000; // 5 sec timeout
        while (drained < messageCount && System.currentTimeMillis() < drainDeadline) {
            Message msg = blockSub.poll(100, TimeUnit.MILLISECONDS);
            if (msg != null) {
                drained++;
            }
        }

        System.out.printf("  BLOCK subscriber: drained=%d, receivedCount=%d (expected=%d)%n",
                drained, blockSub.getReceivedCount(), messageCount);

        // Since BLOCK guarantees zero loss, eventually all messages should be delivered
        assert drained == messageCount :
                "BLOCK subscriber should eventually receive all " + messageCount + " messages (got " + drained + ")";
        assert blockSub.getDroppedCount() == 0 :
                "BLOCK subscriber should have ZERO drops (got " + blockSub.getDroppedCount() + ")";
        System.out.println("  ✓ VERIFIED: BLOCK subscriber received ALL messages with zero drops");
        System.out.println("  ✓ VERIFIED: BLOCK strategy guarantees delivery without stalling peers");

        // Cleanup
        fastSub.shutdownDelivery();
        blockSub.shutdownDelivery();
        slowDropSub.shutdownDelivery();
        broker.shutdown();

        System.out.println("└───────────────────────────────────────────────────────────┘");
    }
}
