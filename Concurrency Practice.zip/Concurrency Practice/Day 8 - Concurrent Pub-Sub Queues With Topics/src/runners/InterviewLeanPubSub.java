package runners;

import engine.Message;
import engine.MessageBroker;
import engine.Subscriber;
import engine.Subscriber.BackpressureStrategy;

import java.util.concurrent.TimeUnit;

/**
 * INTERVIEW-READY: Minimal, clean demonstration of the Pub-Sub engine.
 *
 * This file is designed to be presentable on a whiteboard. It shows:
 * 1. Topic registration
 * 2. Subscriber creation with isolated buffers
 * 3. Message publishing with fan-out
 * 4. Independent consumption by each subscriber
 * 5. Backpressure isolation (slow subscriber doesn't block fast one)
 * 6. Graceful shutdown and drain
 *
 * No external dependencies. No test frameworks. Just core Java concurrency.
 */
public class InterviewLeanPubSub {

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Lean Pub-Sub Demo ===\n");

        // ─── Step 1: Create the broker (central topic registry) ───
        MessageBroker broker = new MessageBroker();

        // ─── Step 2: Create subscribers with isolated bounded buffers ───
        Subscriber alice = new Subscriber("Alice", 100, BackpressureStrategy.DROP);
        Subscriber bob   = new Subscriber("Bob",   5,   BackpressureStrategy.DROP);  // tiny buffer!

        // ─── Step 3: Subscribe to a topic ───
        broker.subscribe("stock-prices", alice);
        broker.subscribe("stock-prices", bob);

        // ─── Step 4: Publish messages — fan-out to all subscribers ───
        System.out.println("[Publisher] Sending 20 messages to 'stock-prices'...");
        for (int i = 1; i <= 20; i++) {
            broker.publish("stock-prices", "AAPL=$" + (150 + i));
        }

        // Give delivery threads time to process (fan-out is async)
        Thread.sleep(100);

        // ─── Step 5: Observe backpressure isolation ───
        System.out.println("\n[Backpressure Check]");
        System.out.printf("  Alice: received=%d, dropped=%d (buffer capacity=100)%n",
                alice.getReceivedCount(), alice.getDroppedCount());
        System.out.printf("  Bob:   received=%d, dropped=%d (buffer capacity=5)%n",
                bob.getReceivedCount(), bob.getDroppedCount());
        System.out.println("  → Bob's drops did NOT block Alice's delivery!\n");

        // ─── Step 6: Consume messages independently ───
        System.out.println("[Alice consuming]");
        Message msg;
        int count = 0;
        while ((msg = alice.poll()) != null) {
            if (count < 3) System.out.println("  " + msg.getPayload());
            count++;
        }
        System.out.printf("  ... consumed %d messages total%n%n", count);

        System.out.println("[Bob consuming]");
        count = 0;
        while ((msg = bob.poll()) != null) {
            System.out.println("  " + msg.getPayload());
            count++;
        }
        System.out.printf("  ... consumed %d messages total (others were dropped)%n%n", count);

        // ─── Step 7: Multi-topic demonstration ───
        Subscriber charlie = new Subscriber("Charlie", 50, BackpressureStrategy.DROP);
        broker.subscribe("news", charlie);
        broker.subscribe("stock-prices", charlie);  // Charlie subscribes to BOTH topics

        broker.publish("news", "Breaking: Market reaches all-time high!");
        broker.publish("stock-prices", "AAPL=$200");

        // Give delivery threads time to process
        Thread.sleep(50);

        System.out.println("[Multi-topic: Charlie subscribed to 'news' AND 'stock-prices']");
        while ((msg = charlie.poll()) != null) {
            System.out.println("  Charlie received: " + msg.getPayload() + " (from topic: " + msg.getTopic() + ")");
        }

        // ─── Step 8: Concurrent publish demonstration ───
        System.out.println("\n[Concurrent publishers]");
        Subscriber listener = new Subscriber("Listener", 200, BackpressureStrategy.DROP);
        broker.subscribe("trades", listener);

        Thread pub1 = new Thread(() -> {
            for (int i = 0; i < 50; i++) broker.publish("trades", "P1-trade-" + i);
        }, "Publisher-1");

        Thread pub2 = new Thread(() -> {
            for (int i = 0; i < 50; i++) broker.publish("trades", "P2-trade-" + i);
        }, "Publisher-2");

        pub1.start();
        pub2.start();
        pub1.join();
        pub2.join();

        // Give delivery threads time to process
        Thread.sleep(100);

        System.out.printf("  Listener received %d messages from 2 concurrent publishers%n",
                listener.getReceivedCount());

        // ─── Step 9: BLOCK strategy isolation demonstration ───
        // This is the KEY interview scenario: prove that a BLOCK subscriber
        // with a full buffer does NOT stall the publisher or other subscribers.
        System.out.println("\n[BLOCK Strategy Isolation Demo]");
        System.out.println("  Scenario: BLOCK subscriber (buffer=3) vs DROP subscriber (buffer=100)");
        System.out.println("  Publishing 30 messages. BLOCK sub's buffer fills at 3.");
        System.out.println("  If async fan-out works: publisher returns fast, DROP sub gets all 30.\n");

        Subscriber dropSub = new Subscriber("DropSub", 100, BackpressureStrategy.DROP);
        Subscriber blockSub = new Subscriber("BlockSub", 3, BackpressureStrategy.BLOCK);

        broker.subscribe("isolation-test", dropSub);
        broker.subscribe("isolation-test", blockSub);

        // Publish 30 messages — publisher must NOT block despite blockSub's tiny buffer
        long start = System.nanoTime();
        for (int i = 0; i < 30; i++) {
            broker.publish("isolation-test", "iso-msg-" + i);
        }
        double publishMs = (System.nanoTime() - start) / 1_000_000.0;

        System.out.printf("  Publisher returned in %.1f ms (non-blocking ✓)%n", publishMs);

        // Wait for DROP subscriber's delivery thread to process
        Thread.sleep(100);

        System.out.printf("  DropSub:  received=%d, dropped=%d (expected: 30 received, 0 dropped)%n",
                dropSub.getReceivedCount(), dropSub.getDroppedCount());
        System.out.println("  → DROP subscriber got ALL messages despite BLOCK peer!");

        // Now drain the BLOCK subscriber to prove zero-loss guarantee
        System.out.println("  [Draining BlockSub to prove zero-loss BLOCK guarantee...]");
        int blockDrained = 0;
        long deadline = System.currentTimeMillis() + 3000;
        while (blockDrained < 30 && System.currentTimeMillis() < deadline) {
            Message m = blockSub.poll(50, TimeUnit.MILLISECONDS);
            if (m != null) blockDrained++;
        }
        System.out.printf("  BlockSub: drained=%d, dropped=%d (expected: 30 drained, 0 dropped)%n",
                blockDrained, blockSub.getDroppedCount());
        System.out.println("  → BLOCK subscriber received ALL messages (zero loss) without stalling peers!\n");

        // ─── Step 10: Graceful shutdown ───
        broker.shutdown();
        System.out.println("[Broker shut down]");

        // Drain remaining from listener
        int drained = listener.drainAll().size();
        System.out.printf("  Drained %d remaining messages from Listener's buffer%n", drained);

        // Cleanup delivery threads
        listener.shutdownDelivery();
        dropSub.shutdownDelivery();
        blockSub.shutdownDelivery();

        System.out.println("\n=== Demo Complete ===");
    }
}
