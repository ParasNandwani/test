package engine;

import java.util.Collections;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Manages a specific named topic category, its registered subscribers,
 * and the fan-out logic for message delivery.
 * 
 * Thread-safety:
 * - Subscriber set uses CopyOnWriteArraySet for safe concurrent iteration during fan-out
 *   while allowing dynamic registration/deregistration.
 * - This is optimal when reads (fan-out iterations) vastly outnumber writes (subscribe/unsubscribe).
 */
public class Topic {

    private final String name;
    private final Set<Subscriber> subscribers;
    private final AtomicLong publishedCount = new AtomicLong(0);

    public Topic(String name) {
        this.name = name;
        this.subscribers = new CopyOnWriteArraySet<>();
    }

    /**
     * Registers a subscriber to this topic.
     * The subscriber will receive all future messages published to this topic.
     *
     * @param subscriber The subscriber to register
     * @return true if the subscriber was newly added, false if already registered
     */
    public boolean subscribe(Subscriber subscriber) {
        return subscribers.add(subscriber);
    }

    /**
     * Deregisters a subscriber from this topic.
     * The subscriber will no longer receive messages from this topic.
     *
     * @param subscriber The subscriber to remove
     * @return true if the subscriber was removed, false if it wasn't registered
     */
    public boolean unsubscribe(Subscriber subscriber) {
        return subscribers.remove(subscriber);
    }

    /**
     * Publishes a message to all currently registered subscribers via ASYNC fan-out.
     * 
     * Fan-out iterates over the snapshot of subscribers (CopyOnWriteArraySet guarantees
     * a consistent snapshot during iteration). Each subscriber's submitAsync() is called,
     * which submits the delivery task to the subscriber's dedicated delivery thread and
     * returns IMMEDIATELY — the publisher thread is never blocked.
     * 
     * This ensures that a BLOCK subscriber whose buffer is full will only stall its own
     * delivery thread, not the publisher or any other subscriber on this topic.
     *
     * @param message The message to fan out
     */
    public void publish(Message message) {
        publishedCount.incrementAndGet();
        for (Subscriber subscriber : subscribers) {
            subscriber.submitAsync(message);
        }
    }

    /**
     * Returns the number of currently registered subscribers.
     */
    public int getSubscriberCount() {
        return subscribers.size();
    }

    /**
     * Returns the total number of messages published to this topic.
     */
    public long getPublishedCount() {
        return publishedCount.get();
    }

    /**
     * Returns an unmodifiable view of the current subscribers.
     * Primarily for monitoring/debugging.
     */
    public Set<Subscriber> getSubscribers() {
        return Collections.unmodifiableSet(subscribers);
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return String.format("[Topic name=%s subscribers=%d published=%d]",
                name, subscribers.size(), publishedCount.get());
    }
}