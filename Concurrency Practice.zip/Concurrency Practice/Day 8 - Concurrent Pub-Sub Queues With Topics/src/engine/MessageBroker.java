package engine;

import java.util.Collection;
import java.util.Collections;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The global registry managing topics via thread-safe lookups.
 *
 * Responsibilities:
 * - Create and retrieve topics by name (idempotent, thread-safe via computeIfAbsent).
 * - Route publish calls to the correct topic.
 * - Manage subscriber registration/deregistration against topics.
 * - Provide graceful shutdown with drain support.
 *
 * Thread-safety: ConcurrentHashMap provides lock-free reads and safe concurrent writes
 * for the topic registry. Each Topic internally manages its own subscriber fan-out safely.
 */
public class MessageBroker {

    private final ConcurrentHashMap<String, Topic> topicRegistry = new ConcurrentHashMap<>();
    private final AtomicBoolean shutdown = new AtomicBoolean(false);

    /**
     * Gets or creates a topic by name. Idempotent — calling with the same name
     * always returns the same Topic instance.
     *
     * @param topicName The name of the topic
     * @return The Topic instance
     */
    public Topic getOrCreateTopic(String topicName) {
        if (shutdown.get()) {
            throw new IllegalStateException("Broker is shut down. Cannot create new topics.");
        }
        return topicRegistry.computeIfAbsent(topicName, Topic::new);
    }

    /**
     * Retrieves an existing topic by name, or null if it doesn't exist.
     *
     * @param topicName The name of the topic
     * @return The Topic instance or null
     */
    public Topic getTopic(String topicName) {
        return topicRegistry.get(topicName);
    }

    /**
     * Publishes a message to the specified topic.
     * If the topic doesn't exist, it will be created on-the-fly.
     *
     * @param topicName The target topic name
     * @param payload   The message payload string
     * @return The published Message object
     */
    public Message publish(String topicName, String payload) {
        if (shutdown.get()) {
            throw new IllegalStateException("Broker is shut down. Cannot publish messages.");
        }
        Topic topic = getOrCreateTopic(topicName);
        Message message = new Message(topicName, payload);
        topic.publish(message);
        return message;
    }

    /**
     * Publishes a pre-constructed Message to the specified topic.
     *
     * @param topicName The target topic name
     * @param message   The message to publish
     */
    public void publish(String topicName, Message message) {
        if (shutdown.get()) {
            throw new IllegalStateException("Broker is shut down. Cannot publish messages.");
        }
        Topic topic = getOrCreateTopic(topicName);
        topic.publish(message);
    }

    /**
     * Subscribes a subscriber to a topic.
     * Creates the topic if it doesn't exist yet.
     *
     * @param topicName  The topic to subscribe to
     * @param subscriber The subscriber to register
     */
    public void subscribe(String topicName, Subscriber subscriber) {
        if (shutdown.get()) {
            throw new IllegalStateException("Broker is shut down. Cannot register subscribers.");
        }
        Topic topic = getOrCreateTopic(topicName);
        topic.subscribe(subscriber);
    }

    /**
     * Unsubscribes a subscriber from a topic.
     *
     * @param topicName  The topic to unsubscribe from
     * @param subscriber The subscriber to remove
     * @return true if the subscriber was removed
     */
    public boolean unsubscribe(String topicName, Subscriber subscriber) {
        Topic topic = topicRegistry.get(topicName);
        if (topic != null) {
            return topic.unsubscribe(subscriber);
        }
        return false;
    }

    /**
     * Returns the number of registered topics.
     */
    public int getTopicCount() {
        return topicRegistry.size();
    }

    /**
     * Returns all topic names currently registered.
     */
    public Collection<String> getTopicNames() {
        return Collections.unmodifiableSet(topicRegistry.keySet());
    }

    /**
     * Returns all topics currently registered.
     */
    public Collection<Topic> getAllTopics() {
        return Collections.unmodifiableCollection(topicRegistry.values());
    }

    /**
     * Initiates graceful shutdown of the broker.
     * After shutdown:
     * - No new topics can be created
     * - No new messages can be published
     * - No new subscribers can register
     * - Existing subscriber buffers can still be drained
     */
    public void shutdown() {
        shutdown.set(true);
    }

    /**
     * Returns whether the broker is in shutdown state.
     */
    public boolean isShutdown() {
        return shutdown.get();
    }

    /**
     * Prints a status summary of all topics and their subscribers.
     * Useful for debugging and monitoring.
     */
    public void printStatus() {
        System.out.println("=== MessageBroker Status ===");
        System.out.println("Shutdown: " + shutdown.get());
        System.out.println("Topics: " + topicRegistry.size());
        for (Map.Entry<String, Topic> entry : topicRegistry.entrySet()) {
            Topic topic = entry.getValue();
            System.out.println("  " + topic);
            for (Subscriber sub : topic.getSubscribers()) {
                System.out.println("    " + sub);
            }
        }
        System.out.println("============================");
    }
}