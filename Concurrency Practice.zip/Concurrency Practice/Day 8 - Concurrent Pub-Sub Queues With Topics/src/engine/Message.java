package engine;

import java.time.Instant;
import java.util.UUID;

/**
 * Immutable message payload wrapper.
 *
 * Thread-safety guarantee: All fields are final and set at construction time.
 * This object can be safely shared across threads without synchronization or defensive copying.
 */
public final class Message {

    private final String id;
    private final String topic;
    private final String payload;
    private final Instant timestamp;

    public Message(String topic, String payload) {
        this.id = UUID.randomUUID().toString();
        this.topic = topic;
        this.payload = payload;
        this.timestamp = Instant.now();
    }

    public String getId() {
        return id;
    }

    public String getTopic() {
        return topic;
    }

    public String getPayload() {
        return payload;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        return String.format("[Message id=%s topic=%s payload=%s ts=%s]",
                id.substring(0, 8), topic, payload, timestamp);
    }
}