package engine;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * A distinct data consumer with its own isolated, bounded buffer.
 * 
 * Each Subscriber maintains:
 * 1. An independent ArrayBlockingQueue (the consumer-facing buffer).
 * 2. A dedicated single-threaded delivery executor (for async fan-out from the Topic).
 * 
 * WHY A DEDICATED DELIVERY THREAD?
 * ---------------------------------
 * The Topic's publish() fans out to all subscribers. If the fan-out were synchronous
 * and a BLOCK subscriber's buffer were full, the publisher's thread would block on
 * buffer.put() — stalling delivery to ALL other subscribers on the same topic AND
 * preventing the publisher from publishing to any other topic.
 * 
 * By giving each subscriber its own delivery thread:
 * - Topic.publish() calls submitAsync() which returns IMMEDIATELY (non-blocking).
 * - The actual buffer insertion happens on the subscriber's private delivery thread.
 * - If BLOCK strategy causes buffer.put() to block, only THIS subscriber's delivery
 *   thread is blocked. The publisher and all other subscribers are unaffected.
 * 
 * TRADE-OFF / KNOWN LIMITATION (BLOCK + unbounded delivery queue):
 * ----------------------------------------------------------------
 * The delivery thread uses an unbounded internal task queue (LinkedBlockingQueue inside
 * newSingleThreadExecutor). If the subscriber's consumer never drains its buffer,
 * the delivery thread stays blocked on buffer.put(), and new submitAsync() calls keep
 * accumulating tasks in the executor's internal queue — growing memory without bound.
 * 
 * In production, this would be addressed by bounding the delivery queue (e.g., using
 * a ThreadPoolExecutor with a bounded ArrayBlockingQueue and CallerRunsPolicy), which
 * naturally applies backpressure to the publisher when the subscriber is overwhelmed.
 * For this implementation, we accept the unbounded queue as the simpler model that
 * still achieves the primary goal: publisher and peer-subscriber isolation.
 */
public class Subscriber {

    /**
     * Configurable backpressure strategy when the subscriber's buffer is full.
     */
    public enum BackpressureStrategy {
        /**
         * Block the delivery thread until space is available in the subscriber's buffer.
         * Guarantees zero message loss for this subscriber, but the delivery thread will
         * stall. Tasks from the publisher accumulate in the delivery executor's internal
         * (unbounded) task queue. Publisher thread itself is NOT blocked.
         */
        BLOCK,
        /** Drop the message for this subscriber only. Preserves throughput for others. */
        DROP,
        /** Drop the oldest message in the buffer to make room for the new one. */
        DROP_OLDEST
    }

    private final String name;
    private final BlockingQueue<Message> buffer;
    private final int capacity;
    private final BackpressureStrategy backpressureStrategy;
    private final AtomicLong receivedCount = new AtomicLong(0);
    private final AtomicLong droppedCount = new AtomicLong(0);

    /**
     * Dedicated single-threaded executor for this subscriber's message delivery.
     * Ensures that Topic.publish() (via submitAsync) never blocks the publisher thread.
     * Uses an unbounded LinkedBlockingQueue internally — see class-level Javadoc for trade-offs.
     */
    private final ExecutorService deliveryThread;

    /**
     * Creates a subscriber with specified buffer capacity and backpressure strategy.
     *
     * @param name                  Human-readable subscriber identifier
     * @param capacity              Maximum number of messages the buffer can hold
     * @param backpressureStrategy  Strategy when buffer is full
     */
    public Subscriber(String name, int capacity, BackpressureStrategy backpressureStrategy) {
        this.name = name;
        this.capacity = capacity;
        this.buffer = new ArrayBlockingQueue<>(capacity);
        this.backpressureStrategy = backpressureStrategy;
        this.deliveryThread = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "delivery-" + name);
            t.setDaemon(true); // Won't prevent JVM shutdown
            return t;
        });
    }

    /**
     * Convenience constructor with default DROP strategy and capacity of 1024.
     */
    public Subscriber(String name) {
        this(name, 1024, BackpressureStrategy.DROP);
    }

    /**
     * Non-blocking async submission called by Topic.publish() during fan-out.
     * 
     * This method returns IMMEDIATELY regardless of the backpressure strategy.
     * The actual buffer insertion (which may block for BLOCK strategy) happens
     * asynchronously on this subscriber's dedicated delivery thread.
     * 
     * This is the key to subscriber isolation: a BLOCK subscriber's full buffer
     * only stalls its own delivery thread, never the publisher or other subscribers.
     *
     * @param message The message to deliver asynchronously
     */
    public void submitAsync(Message message) {
        try {
            deliveryThread.submit(() -> onMessage(message));
        } catch (RejectedExecutionException e) {
            // Delivery thread has been shut down — drop the message
            droppedCount.incrementAndGet();
        }
    }

    /**
     * Synchronous delivery — applies the configured backpressure strategy.
     * 
     * When called via submitAsync(), this executes on the subscriber's dedicated
     * delivery thread. For BLOCK strategy, buffer.put() will block only this
     * delivery thread — NOT the publisher thread.
     *
     * @param message The message to deliver
     * @return true if the message was accepted into the buffer, false if dropped
     */
    public boolean onMessage(Message message) {
        switch (backpressureStrategy) {
            case BLOCK:
                try {
                    // Blocks only THIS subscriber's delivery thread until space is available.
                    // The publisher thread (which called submitAsync) already returned.
                    buffer.put(message);
                    receivedCount.incrementAndGet();
                    return true;
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return false;
                }

            case DROP:
                boolean offered = buffer.offer(message);
                if (offered) {
                    receivedCount.incrementAndGet();
                } else {
                    droppedCount.incrementAndGet();
                }
                return offered;

            case DROP_OLDEST:
                while (!buffer.offer(message)) {
                    buffer.poll(); // discard oldest to make room
                    droppedCount.incrementAndGet();
                }
                receivedCount.incrementAndGet();
                return true;

            default:
                return false;
        }
    }

    /**
     * Polls a message from this subscriber's buffer.
     * Non-blocking — returns null if no message is available.
     */
    public Message poll() {
        return buffer.poll();
    }

    /**
     * Polls a message with a timeout. Useful for consumer threads that
     * want to wait briefly before checking shutdown conditions.
     */
    public Message poll(long timeout, TimeUnit unit) throws InterruptedException {
        return buffer.poll(timeout, unit);
    }

    /**
     * Takes a message from the buffer, blocking until one is available.
     */
    public Message take() throws InterruptedException {
        return buffer.take();
    }

    /**
     * Drains all currently buffered messages into the provided list.
     * Non-blocking — returns immediately with whatever is available.
     *
     * @return Number of messages drained
     */
    public int drain(List<Message> destination) {
        return buffer.drainTo(destination);
    }

    /**
     * Drains all remaining messages and returns them.
     */
    public List<Message> drainAll() {
        List<Message> messages = new ArrayList<>();
        buffer.drainTo(messages);
        return messages;
    }

    /**
     * Gracefully shuts down the delivery thread.
     * In-flight deliveries will complete, but no new submissions will be accepted.
     */
    public void shutdownDelivery() {
        deliveryThread.shutdown();
    }

    /**
     * Awaits termination of the delivery thread after shutdown.
     */
    public boolean awaitDeliveryTermination(long timeout, TimeUnit unit) throws InterruptedException {
        return deliveryThread.awaitTermination(timeout, unit);
    }

    public String getName() {
        return name;
    }

    public int getBufferSize() {
        return buffer.size();
    }

    public int getCapacity() {
        return capacity;
    }

    public long getReceivedCount() {
        return receivedCount.get();
    }

    public long getDroppedCount() {
        return droppedCount.get();
    }

    public BackpressureStrategy getBackpressureStrategy() {
        return backpressureStrategy;
    }

    @Override
    public String toString() {
        return String.format("[Subscriber name=%s buffered=%d/%d received=%d dropped=%d strategy=%s]",
                name, buffer.size(), capacity, receivedCount.get(), droppedCount.get(), backpressureStrategy);
    }
}