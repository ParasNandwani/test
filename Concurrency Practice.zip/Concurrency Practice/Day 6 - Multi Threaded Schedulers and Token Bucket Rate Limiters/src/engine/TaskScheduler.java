package engine;

import java.util.PriorityQueue;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.TimeUnit;

/**
 * A custom task scheduler that manages background execution of timed or recurring tasks.
 *
 * Design:
 * - Tasks are stored in a PriorityQueue sorted by execution timestamp (nanoTime).
 * - A single coordinator daemon thread sleeps (via awaitNanos) until the earliest task is due.
 * - When a client submits a more urgent task (new queue head), the coordinator is signaled
 *   immediately to re-evaluate its wait window.
 * - Supports one-shot and fixed-rate recurring tasks.
 */
public class TaskScheduler {

    // ─── Inner class: Represents a scheduled unit of work ───────────────────────

    public static class ScheduledTask implements Comparable<ScheduledTask> {
        private final String name;
        private final Runnable action;
        private long executionTimeNanos;       // absolute nanoTime when task should fire
        private final long periodNanos;        // 0 = one-shot; >0 = recurring interval
        private final long sequenceNumber;     // tie-breaker for equal timestamps (FIFO)

        ScheduledTask(String name, Runnable action, long executionTimeNanos,
                      long periodNanos, long sequenceNumber) {
            this.name = name;
            this.action = action;
            this.executionTimeNanos = executionTimeNanos;
            this.periodNanos = periodNanos;
            this.sequenceNumber = sequenceNumber;
        }

        public String getName() { return name; }
        public boolean isRecurring() { return periodNanos > 0; }

        @Override
        public int compareTo(ScheduledTask other) {
            int cmp = Long.compare(this.executionTimeNanos, other.executionTimeNanos);
            return cmp != 0 ? cmp : Long.compare(this.sequenceNumber, other.sequenceNumber);
        }
    }

    // ─── Core State ─────────────────────────────────────────────────────────────

    private final PriorityQueue<ScheduledTask> taskQueue = new PriorityQueue<>();
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition taskAvailable = lock.newCondition();

    private volatile boolean isShutdown = false;
    private long sequenceCounter = 0;
    private final Thread coordinatorThread;

    // ─── Constructor ────────────────────────────────────────────────────────────

    public TaskScheduler() {
        this.coordinatorThread = new Thread(this::coordinatorLoop, "TaskScheduler-Coordinator");
        this.coordinatorThread.setDaemon(true);
        this.coordinatorThread.start();
    }

    // ─── Public API ─────────────────────────────────────────────────────────────

    /**
     * Schedule a one-shot task to execute after the given delay.
     */
    public void schedule(String name, Runnable action, long delay, TimeUnit unit) {
        long executeAt = System.nanoTime() + unit.toNanos(delay);
        enqueue(new ScheduledTask(name, action, executeAt, 0, nextSequence()));
    }

    /**
     * Schedule a recurring task that fires at a fixed rate after an initial delay.
     */
    public void scheduleAtFixedRate(String name, Runnable action,
                                    long initialDelay, long period, TimeUnit unit) {
        long executeAt = System.nanoTime() + unit.toNanos(initialDelay);
        long periodNanos = unit.toNanos(period);
        enqueue(new ScheduledTask(name, action, executeAt, periodNanos, nextSequence()));
    }

    /**
     * Gracefully shut down the scheduler. No new tasks will be accepted.
     * The coordinator thread will drain and exit.
     */
    public void shutdown() {
        lock.lock();
        try {
            isShutdown = true;
            taskAvailable.signal();
        } finally {
            lock.unlock();
        }
    }

    /**
     * Shut down and wait for the coordinator thread to terminate.
     */
    public void shutdownAndAwait(long timeout, TimeUnit unit) throws InterruptedException {
        shutdown();
        coordinatorThread.join(unit.toMillis(timeout));
    }

    /**
     * Returns the current number of pending tasks in the queue.
     */
    public int getPendingTaskCount() {
        lock.lock();
        try {
            return taskQueue.size();
        } finally {
            lock.unlock();
        }
    }

    // ─── Internal Mechanics ─────────────────────────────────────────────────────

    private long nextSequence() {
        lock.lock();
        try {
            return sequenceCounter++;
        } finally {
            lock.unlock();
        }
    }

    private void enqueue(ScheduledTask task) {
        lock.lock();
        try {
            if (isShutdown) {
                System.err.println("[TaskScheduler] Rejected task '" + task.getName()
                        + "' — scheduler is shut down.");
                return;
            }

            // Check if this task will become the new head (most urgent)
            boolean isNewHead = taskQueue.isEmpty()
                    || task.compareTo(taskQueue.peek()) < 0;

            taskQueue.offer(task);

            // Signal coordinator ONLY if the new task is more urgent than what it's waiting for
            if (isNewHead) {
                taskAvailable.signal();
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * The coordinator loop: sleeps until the next task is due, executes it,
     * and optionally re-enqueues recurring tasks.
     */
    private void coordinatorLoop() {
        lock.lock();
        try {
            while (!isShutdown || !taskQueue.isEmpty()) {

                // ── Phase 1: Wait for work ──────────────────────────────────
                if (taskQueue.isEmpty()) {
                    if (isShutdown) break;
                    taskAvailable.await(); // park until signaled
                    continue;
                }

                // ── Phase 2: Timed wait until the head task is due ──────────
                long now = System.nanoTime();
                ScheduledTask head = taskQueue.peek();
                long delay = head.executionTimeNanos - now;

                if (delay > 0) {
                    // Sleep precisely until this task's fire time.
                    // If a more urgent task arrives, signal() wakes us early.
                    taskAvailable.awaitNanos(delay);
                    continue; // re-check head — it may have changed
                }

                // ── Phase 3: Execute the task ───────────────────────────────
                taskQueue.poll(); // remove head

                // Release lock during execution to avoid blocking submitters
                lock.unlock();
                try {
                    head.action.run();
                } catch (Exception e) {
                    System.err.println("[TaskScheduler] Task '" + head.getName()
                            + "' threw exception: " + e.getMessage());
                } finally {
                    lock.lock();
                }

                // ── Phase 4: Re-enqueue if recurring ────────────────────────
                if (head.isRecurring() && !isShutdown) {
                    head.executionTimeNanos = System.nanoTime() + head.periodNanos;
                    taskQueue.offer(head);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }

        System.out.println("[TaskScheduler] Coordinator thread exiting.");
    }
}