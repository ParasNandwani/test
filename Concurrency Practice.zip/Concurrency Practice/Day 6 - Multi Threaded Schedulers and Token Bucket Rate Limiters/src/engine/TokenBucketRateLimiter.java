package engine;

import java.util.concurrent.locks.ReentrantLock;

/**
 * A Token-Bucket Rate Limiter using the Lazy Refill optimization.
 *
 * Design:
 * - No background refill thread. Tokens are computed mathematically on-demand.
 * - On each allowRequest() call:
 *     1. Acquire lock
 *     2. Compute elapsed time since last refill using System.nanoTime() (monotonic)
 *     3. Add proportional tokens (capped at maxTokens)
 *     4. Attempt to consume one token
 *     5. Release lock
 * - Thread-safe via ReentrantLock (fair mode optional for predictability under contention).
 */
public class TokenBucketRateLimiter {

    // ─── Configuration ──────────────────────────────────────────────────────────

    private final long maxTokens;            // bucket capacity
    private final double refillRatePerNano;  // tokens added per nanosecond

    // ─── Mutable State (protected by lock) ──────────────────────────────────────

    private double currentTokens;
    private long lastRefillNanos;

    // ─── Concurrency Control ────────────────────────────────────────────────────

    private final ReentrantLock lock = new ReentrantLock();

    // ─── Metrics (for observability) ────────────────────────────────────────────

    private long totalRequests = 0;
    private long allowedRequests = 0;
    private long deniedRequests = 0;

    // ─── Constructor ────────────────────────────────────────────────────────────

    /**
     * @param maxTokens      Maximum tokens the bucket can hold (burst capacity).
     * @param refillPerSecond Number of tokens added per second (sustained rate).
     */
    public TokenBucketRateLimiter(long maxTokens, double refillPerSecond) {
        if (maxTokens <= 0) throw new IllegalArgumentException("maxTokens must be > 0");
        if (refillPerSecond <= 0) throw new IllegalArgumentException("refillPerSecond must be > 0");

        this.maxTokens = maxTokens;
        this.refillRatePerNano = refillPerSecond / 1_000_000_000.0;
        this.currentTokens = maxTokens; // start full
        this.lastRefillNanos = System.nanoTime();
    }

    // ─── Public API ─────────────────────────────────────────────────────────────

    /**
     * Attempt to consume one token. Returns true if the request is allowed.
     * This is the hot path — designed to be as fast as possible.
     */
    public boolean allowRequest() {
        lock.lock();
        try {
            refill();

            totalRequests++;

            if (currentTokens >= 1.0) {
                currentTokens -= 1.0;
                allowedRequests++;
                return true;
            } else {
                deniedRequests++;
                return false;
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * Attempt to consume a specified number of tokens (for weighted requests).
     * Returns true if enough tokens are available.
     */
    public boolean allowRequest(int tokensRequired) {
        if (tokensRequired <= 0) throw new IllegalArgumentException("tokensRequired must be > 0");

        lock.lock();
        try {
            refill();

            totalRequests++;

            if (currentTokens >= tokensRequired) {
                currentTokens -= tokensRequired;
                allowedRequests++;
                return true;
            } else {
                deniedRequests++;
                return false;
            }
        } finally {
            lock.unlock();
        }
    }

    /**
     * Returns the current token count (snapshot — may be stale by the time you use it).
     */
    public double getCurrentTokens() {
        lock.lock();
        try {
            refill();
            return currentTokens;
        } finally {
            lock.unlock();
        }
    }

    /**
     * Returns metrics snapshot: [totalRequests, allowedRequests, deniedRequests].
     */
    public long[] getMetrics() {
        lock.lock();
        try {
            return new long[]{totalRequests, allowedRequests, deniedRequests};
        } finally {
            lock.unlock();
        }
    }

    // ─── Internal: Lazy Refill ──────────────────────────────────────────────────

    /**
     * Computes tokens earned since the last refill and adds them.
     * MUST be called while holding the lock.
     */
    private void refill() {
        long now = System.nanoTime();
        long elapsedNanos = now - lastRefillNanos;

        if (elapsedNanos <= 0) {
            return; // no time has passed (or clock weirdness on some VMs)
        }

        double tokensToAdd = elapsedNanos * refillRatePerNano;
        currentTokens = Math.min(maxTokens, currentTokens + tokensToAdd);
        lastRefillNanos = now;
    }

    // ─── toString for debugging ─────────────────────────────────────────────────

    @Override
    public String toString() {
        lock.lock();
        try {
            refill();
            return String.format("TokenBucket[tokens=%.2f/%d, rate=%.1f/sec, "
                            + "total=%d, allowed=%d, denied=%d]",
                    currentTokens, maxTokens,
                    refillRatePerNano * 1_000_000_000.0,
                    totalRequests, allowedRequests, deniedRequests);
        } finally {
            lock.unlock();
        }
    }
}