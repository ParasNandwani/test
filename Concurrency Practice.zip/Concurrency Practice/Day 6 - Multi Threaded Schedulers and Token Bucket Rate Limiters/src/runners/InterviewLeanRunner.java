package runners;

import engine.TaskScheduler;
import engine.TokenBucketRateLimiter;

import java.util.concurrent.TimeUnit;

/**
 * Interview-Lean Runner: A hyper-focused, minimal demonstration of the
 * TaskScheduler and TokenBucketRateLimiter.
 *
 * Purpose: This is what you'd write (or explain) in 10-15 minutes during
 * a live coding interview. Clean setup, clear output, no boilerplate.
 */
public class InterviewLeanRunner {

    public static void main(String[] args) throws InterruptedException {

        // ═══════════════════════════════════════════════════════════════════
        // PART 1: Task Scheduler Demo
        // ═══════════════════════════════════════════════════════════════════
        System.out.println("─── Task Scheduler Demo ───");

        TaskScheduler scheduler = new TaskScheduler();

        // One-shot task: fires once after 500ms
        scheduler.schedule("OneShotTask",
                () -> System.out.println("  [" + ms() + "ms] One-shot task executed!"),
                500, TimeUnit.MILLISECONDS);

        // Recurring task: fires every 300ms
        scheduler.scheduleAtFixedRate("HeartbeatPing",
                () -> System.out.println("  [" + ms() + "ms] Heartbeat ping"),
                100, 300, TimeUnit.MILLISECONDS);

        // Urgent task: submitted after the others, but fires first (50ms delay)
        scheduler.schedule("UrgentAlert",
                () -> System.out.println("  [" + ms() + "ms] URGENT alert fired (preempted queue)!"),
                50, TimeUnit.MILLISECONDS);

        // Let tasks run for 2 seconds
        Thread.sleep(2000);
        scheduler.shutdownAndAwait(1, TimeUnit.SECONDS);

        // ═══════════════════════════════════════════════════════════════════
        // PART 2: Token Bucket Rate Limiter Demo
        // ═══════════════════════════════════════════════════════════════════
        System.out.println("\n─── Token Bucket Rate Limiter Demo ───");

        // 5 tokens max, refills at 2 tokens/sec
        TokenBucketRateLimiter limiter = new TokenBucketRateLimiter(5, 2.0);

        // Burst: consume all 5 tokens
        System.out.println("  Sending 7 rapid requests (bucket has 5 tokens):");
        for (int i = 1; i <= 7; i++) {
            boolean allowed = limiter.allowRequest();
            System.out.println("    Request " + i + ": " + (allowed ? "✓ ALLOWED" : "✗ DENIED"));
        }

        // Wait for refill
        System.out.println("\n  Waiting 1 second for refill...");
        Thread.sleep(1000);

        // After refill: ~2 tokens should be available
        System.out.println("  Sending 3 more requests after refill:");
        for (int i = 1; i <= 3; i++) {
            boolean allowed = limiter.allowRequest();
            System.out.println("    Request " + i + ": " + (allowed ? "✓ ALLOWED" : "✗ DENIED"));
        }

        System.out.println("\n  Final state: " + limiter);
        System.out.println("\n─── Demo Complete ───");
    }

    /** Returns milliseconds since JVM start (for readable log timestamps). */
    private static long ms() {
        return TimeUnit.NANOSECONDS.toMillis(System.nanoTime()) % 100_000;
    }
}