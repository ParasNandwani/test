package runners;

import engine.TaskScheduler;
import engine.TokenBucketRateLimiter;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Comprehensive stress test for both the TaskScheduler and TokenBucketRateLimiter.
 *
 * Tests covered:
 * 1. Multi-threaded concurrent task submission to the scheduler
 * 2. Urgent task preemption (new head-of-queue wakes coordinator)
 * 3. Recurring task execution verification
 * 4. Post-shutdown rejection behavior
 * 5. High-contention rate limiter burst test
 * 6. Rate limiter refill accuracy over time
 * 7. Edge case: zero-delay tasks fire immediately
 */
public class ComprehensiveSimulationRunner {

    private static final String SEPARATOR = "═".repeat(70);
    private static final String THIN_SEP = "─".repeat(70);

    public static void main(String[] args) throws InterruptedException {
        System.out.println(SEPARATOR);
        System.out.println("  TRAFFIC COORDINATION MODULE — COMPREHENSIVE SIMULATION");
        System.out.println(SEPARATOR);

        testSchedulerConcurrentSubmission();
        testSchedulerUrgentPreemption();
        testSchedulerRecurringTasks();
        testSchedulerPostShutdownRejection();
        testSchedulerZeroDelayTasks();
        testRateLimiterBurst();
        testRateLimiterRefillAccuracy();
        testRateLimiterHighContention();

        System.out.println("\n" + SEPARATOR);
        System.out.println("  ALL TESTS COMPLETED SUCCESSFULLY");
        System.out.println(SEPARATOR);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // SCHEDULER TESTS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Test 1: Multiple threads submit tasks concurrently.
     * Verifies all tasks execute without loss or corruption.
     */
    private static void testSchedulerConcurrentSubmission() throws InterruptedException {
        printTestHeader("Scheduler: Concurrent Multi-Thread Submission");

        TaskScheduler scheduler = new TaskScheduler();
        int numThreads = 8;
        int tasksPerThread = 50;
        int totalExpected = numThreads * tasksPerThread;

        AtomicInteger executedCount = new AtomicInteger(0);
        CountDownLatch startGate = new CountDownLatch(1);    // synchronized start
        CountDownLatch allSubmitted = new CountDownLatch(numThreads);
        CountDownLatch allExecuted = new CountDownLatch(totalExpected);

        // Spawn submitter threads
        for (int t = 0; t < numThreads; t++) {
            final int threadId = t;
            new Thread(() -> {
                try {
                    startGate.await(); // wait for go signal
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }

                for (int i = 0; i < tasksPerThread; i++) {
                    final int taskId = i;
                    scheduler.schedule(
                            "T" + threadId + "-Task" + taskId,
                            () -> {
                                executedCount.incrementAndGet();
                                allExecuted.countDown();
                            },
                            10 + (taskId % 5) * 10, // staggered delays: 10-50ms
                            TimeUnit.MILLISECONDS
                    );
                }
                allSubmitted.countDown();
            }, "Submitter-" + t).start();
        }

        // Fire!
        long startTime = System.nanoTime();
        startGate.countDown();

        // Wait for all tasks to execute (with timeout)
        boolean completed = allExecuted.await(10, TimeUnit.SECONDS);
        long elapsed = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);

        scheduler.shutdownAndAwait(2, TimeUnit.SECONDS);

        // Validate
        assert completed : "TIMEOUT: Not all tasks executed within 10 seconds";
        assert executedCount.get() == totalExpected :
                "MISMATCH: Expected " + totalExpected + " but got " + executedCount.get();

        System.out.println("  ✓ " + totalExpected + " tasks submitted by " + numThreads
                + " threads — all executed in " + elapsed + "ms");
        System.out.println("  ✓ Zero task loss under concurrent submission");
    }

    /**
     * Test 2: A task with a very short delay is submitted AFTER a long-delay task.
     * The coordinator must wake up early to handle the urgent task first.
     */
    private static void testSchedulerUrgentPreemption() throws InterruptedException {
        printTestHeader("Scheduler: Urgent Task Preemption");

        TaskScheduler scheduler = new TaskScheduler();
        AtomicLong firstFired = new AtomicLong(0);
        AtomicLong secondFired = new AtomicLong(0);
        CountDownLatch urgentDone = new CountDownLatch(1);

        // Schedule a far-future task first
        scheduler.schedule("SlowTask", () -> {
            firstFired.set(System.nanoTime());
        }, 5, TimeUnit.SECONDS);

        // Now schedule an urgent task — should preempt the wait
        Thread.sleep(50); // small gap to ensure ordering
        scheduler.schedule("UrgentTask", () -> {
            secondFired.set(System.nanoTime());
            urgentDone.countDown();
        }, 50, TimeUnit.MILLISECONDS);

        // Urgent task should fire within ~100ms, NOT wait 5 seconds
        boolean fired = urgentDone.await(500, TimeUnit.MILLISECONDS);
        scheduler.shutdownAndAwait(1, TimeUnit.SECONDS);

        assert fired : "FAIL: Urgent task did not fire within 500ms (preemption broken)";
        assert firstFired.get() == 0 : "FAIL: Slow task fired before urgent task";

        System.out.println("  ✓ Urgent task preempted the 5-second wait");
        System.out.println("  ✓ Coordinator correctly re-evaluated queue head on signal()");
    }

    /**
     * Test 3: Verify a recurring task fires multiple times at the expected interval.
     */
    private static void testSchedulerRecurringTasks() throws InterruptedException {
        printTestHeader("Scheduler: Recurring Task Execution");

        TaskScheduler scheduler = new TaskScheduler();
        AtomicInteger fireCount = new AtomicInteger(0);
        int expectedFires = 5;
        CountDownLatch done = new CountDownLatch(expectedFires);

        scheduler.scheduleAtFixedRate("RecurringPing", () -> {
            fireCount.incrementAndGet();
            done.countDown();
        }, 0, 100, TimeUnit.MILLISECONDS); // fires every 100ms

        boolean completed = done.await(3, TimeUnit.SECONDS);
        scheduler.shutdownAndAwait(1, TimeUnit.SECONDS);

        assert completed : "TIMEOUT: Recurring task did not fire " + expectedFires + " times";
        assert fireCount.get() >= expectedFires :
                "MISMATCH: Expected >= " + expectedFires + " fires, got " + fireCount.get();

        System.out.println("  ✓ Recurring task fired " + fireCount.get()
                + " times (expected >= " + expectedFires + ")");
        System.out.println("  ✓ Fixed-rate re-enqueue verified");
    }

    /**
     * Test 4: Tasks submitted after shutdown() are rejected gracefully.
     */
    private static void testSchedulerPostShutdownRejection() throws InterruptedException {
        printTestHeader("Scheduler: Post-Shutdown Rejection");

        TaskScheduler scheduler = new TaskScheduler();
        AtomicInteger executedAfterShutdown = new AtomicInteger(0);

        scheduler.shutdown();
        Thread.sleep(100); // give coordinator time to process shutdown

        // This task should be rejected
        scheduler.schedule("RejectedTask", executedAfterShutdown::incrementAndGet,
                0, TimeUnit.MILLISECONDS);

        Thread.sleep(200); // wait to see if it fires (it shouldn't)

        assert executedAfterShutdown.get() == 0 :
                "FAIL: Task executed after shutdown — should have been rejected";

        System.out.println("  ✓ Task submitted after shutdown() was rejected");
        System.out.println("  ✓ Graceful shutdown semantics verified");
    }

    /**
     * Test 5: Zero-delay tasks fire immediately (or near-immediately).
     */
    private static void testSchedulerZeroDelayTasks() throws InterruptedException {
        printTestHeader("Scheduler: Zero-Delay Immediate Execution");

        TaskScheduler scheduler = new TaskScheduler();
        CountDownLatch done = new CountDownLatch(1);
        long submitTime = System.nanoTime();
        AtomicLong executeTime = new AtomicLong(0);

        scheduler.schedule("Immediate", () -> {
            executeTime.set(System.nanoTime());
            done.countDown();
        }, 0, TimeUnit.MILLISECONDS);

        done.await(1, TimeUnit.SECONDS);
        scheduler.shutdownAndAwait(1, TimeUnit.SECONDS);

        long latencyMs = TimeUnit.NANOSECONDS.toMillis(executeTime.get() - submitTime);

        assert latencyMs < 50 : "FAIL: Zero-delay task took " + latencyMs + "ms to fire";

        System.out.println("  ✓ Zero-delay task fired in " + latencyMs + "ms");
        System.out.println("  ✓ Near-immediate execution confirmed");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // RATE LIMITER TESTS
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Test 6: Burst test — exhaust all tokens rapidly, then verify denial.
     */
    private static void testRateLimiterBurst() throws InterruptedException {
        printTestHeader("RateLimiter: Burst Exhaustion & Denial");

        // 10 tokens max, refill at 2/sec
        TokenBucketRateLimiter limiter = new TokenBucketRateLimiter(10, 2.0);

        // Exhaust all 10 tokens immediately
        int allowed = 0;
        for (int i = 0; i < 10; i++) {
            if (limiter.allowRequest()) allowed++;
        }

        assert allowed == 10 : "FAIL: Expected 10 allowed, got " + allowed;

        // Next request should be denied (no time for refill)
        boolean denied = !limiter.allowRequest();
        assert denied : "FAIL: Request allowed when bucket should be empty";

        // Wait 1 second — should refill ~2 tokens
        Thread.sleep(1000);
        boolean afterRefill = limiter.allowRequest();
        assert afterRefill : "FAIL: Request denied after 1-second refill window";

        System.out.println("  ✓ 10/10 burst requests allowed");
        System.out.println("  ✓ 11th request correctly denied (bucket empty)");
        System.out.println("  ✓ Request allowed after refill interval");
        System.out.println("  ✓ Bucket state: " + limiter);
    }

    /**
     * Test 7: Verify refill accuracy — tokens accumulate at the correct rate.
     */
    private static void testRateLimiterRefillAccuracy() throws InterruptedException {
        printTestHeader("RateLimiter: Refill Accuracy Over Time");

        // 100 tokens max, refill at 50/sec
        TokenBucketRateLimiter limiter = new TokenBucketRateLimiter(100, 50.0);

        // Drain completely
        while (limiter.allowRequest()) { /* drain */ }

        // Wait exactly 1 second — should have ~50 tokens
        Thread.sleep(1000);

        double tokens = limiter.getCurrentTokens();
        // Allow ±5 tolerance for scheduling jitter
        assert tokens >= 45 && tokens <= 55 :
                "FAIL: Expected ~50 tokens after 1s refill, got " + tokens;

        System.out.println("  ✓ After draining and waiting 1s: " + String.format("%.1f", tokens)
                + " tokens (expected ~50)");
        System.out.println("  ✓ Lazy refill rate accuracy confirmed (±5 tolerance)");
    }

    /**
     * Test 8: High-contention multi-threaded rate limiter access.
     * Verifies no data corruption under heavy concurrent usage.
     */
    private static void testRateLimiterHighContention() throws InterruptedException {
        printTestHeader("RateLimiter: High-Contention Multi-Thread Stress");

        // 100 tokens max, refill at 1000/sec (generous refill for throughput)
        TokenBucketRateLimiter limiter = new TokenBucketRateLimiter(100, 1000.0);

        int numThreads = 16;
        int requestsPerThread = 1000;
        CountDownLatch startGate = new CountDownLatch(1);
        CountDownLatch allDone = new CountDownLatch(numThreads);

        AtomicInteger totalAllowed = new AtomicInteger(0);
        AtomicInteger totalDenied = new AtomicInteger(0);

        for (int t = 0; t < numThreads; t++) {
            new Thread(() -> {
                try {
                    startGate.await();
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }

                int localAllowed = 0;
                int localDenied = 0;

                for (int i = 0; i < requestsPerThread; i++) {
                    if (limiter.allowRequest()) {
                        localAllowed++;
                    } else {
                        localDenied++;
                    }
                }

                totalAllowed.addAndGet(localAllowed);
                totalDenied.addAndGet(localDenied);
                allDone.countDown();
            }, "RateLimitWorker-" + t).start();
        }

        startGate.countDown(); // unleash all threads simultaneously
        allDone.await(10, TimeUnit.SECONDS);

        int totalProcessed = totalAllowed.get() + totalDenied.get();
        int expectedTotal = numThreads * requestsPerThread;

        assert totalProcessed == expectedTotal :
                "FAIL: Lost requests! Processed " + totalProcessed + " vs expected " + expectedTotal;

        long[] metrics = limiter.getMetrics();

        System.out.println("  ✓ " + numThreads + " threads × " + requestsPerThread
                + " requests = " + expectedTotal + " total");
        System.out.println("  ✓ Allowed: " + totalAllowed.get()
                + " | Denied: " + totalDenied.get());
        System.out.println("  ✓ Internal metrics match: total=" + metrics[0]
                + ", allowed=" + metrics[1] + ", denied=" + metrics[2]);
        System.out.println("  ✓ Zero request loss under 16-thread contention");

        // Verify internal consistency
        assert metrics[0] == expectedTotal : "Internal metric mismatch: totalRequests";
        assert metrics[1] == totalAllowed.get() : "Internal metric mismatch: allowedRequests";
        assert metrics[2] == totalDenied.get() : "Internal metric mismatch: deniedRequests";
    }

    // ─── Utility ────────────────────────────────────────────────────────────────

    private static void printTestHeader(String testName) {
        System.out.println("\n" + THIN_SEP);
        System.out.println("  TEST: " + testName);
        System.out.println(THIN_SEP);
    }
}