# Day 6: Multi-Threaded Schedulers and Token Bucket Rate Limiters

---

## The Interview Question

> *"Implement a task scheduler that can sleep efficiently until the next task is due, but wake instantly if a more urgent task arrives. Also implement a rate limiter that allows bursts but enforces a sustained cap — with zero background threads."*

**What the interviewer is testing:**
- Can you use Condition variables with `awaitNanos` for precise timed coordination?
- Do you know why `nanoTime()` is correct for intervals but `currentTimeMillis()` is not?
- Can you implement a token bucket with lazy refill (pure math, no timer threads)?
- Do you understand PriorityQueue-based scheduling with preemptive signal?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: What We're Building and Why](#part-1-what-were-building-and-why)
2. [Part 2: The Task Scheduling Problem](#part-2-the-task-scheduling-problem)
3. [Part 3: The Rate Limiting Problem](#part-3-the-rate-limiting-problem)
4. [Part 4: End-to-End Walkthrough](#part-4-end-to-end-walkthrough)
5. [Part 5: Concurrency Primitives Reference](#part-5-concurrency-primitives-reference)
6. [Part 5b: Semaphores — Bounded Parallelism](#part-5b-semaphores--bounded-parallelism)
7. [Part 6: Common Interview Questions](#part-6-common-interview-questions)
8. [Part 7: Architecture Diagram](#part-7-architecture-diagram)
9. [How to Run](#how-to-run)
10. [Practice Yourself — Production Evolution](#practice-yourself--production-evolution)

---

## Part 1: What We're Building and Why

Imagine you're building a distributed backend — a job processing service, a messaging platform, or an API gateway. Two problems show up immediately:

1. **Timed Background Work**: You need tasks that fire in the future — retry a failed RPC in 500ms, send a heartbeat every 2 seconds, expire a session after 30 minutes. You need a **Task Scheduler**.

2. **Traffic Shaping**: One rogue client shouldn't be able to send 10,000 requests/second and starve everyone else. You need a **Rate Limiter** that allows bursts but enforces a sustained cap.

Both are **coordination problems**. Threads must communicate about *time* (when should this run?) and *capacity* (are there tokens left?). The naive solutions burn CPU or lose precision. The elegant solutions use condition variables and lazy math.

This module implements both from scratch — no external libraries, no `ScheduledExecutorService`, no Guava `RateLimiter`. Just raw concurrency primitives, designed to be explained in a 45-minute interview.

---

## Part 2: The Task Scheduling Problem

### The Core Challenge

A scheduler has a single background "coordinator" thread. Its job:
- Sleep efficiently until the next task is due
- Wake up **instantly** if a more urgent task arrives (one with an earlier deadline)
- Execute due tasks and optionally re-enqueue recurring ones

This sounds simple, but the "sleep efficiently yet wake instantly" requirement eliminates most naive approaches.

---

### Approach 1: Busy-Spin (Polling)

```java
while (true) {
    if (!queue.isEmpty() && queue.peek().isDue()) {
        execute(queue.poll());
    }
    // else: loop again immediately
}
```

**How it works**: The coordinator never sleeps. It checks the queue in a tight loop millions of times per second.

**Pros**:
- Simple to implement
- Reacts instantly to due tasks (zero latency)

**Cons**:
- 🔥 Burns 100% of a CPU core doing nothing useful
- Wastes power, generates heat, steals cycles from real work
- Completely unacceptable in production

**Verdict**: Never do this in a system that runs longer than a toy benchmark.

---

### Approach 2: Fixed `Thread.sleep()`

```java
while (true) {
    if (!queue.isEmpty() && queue.peek().isDue()) {
        execute(queue.poll());
    } else {
        Thread.sleep(50); // check every 50ms
    }
}
```

**How it works**: Sleep for a fixed duration between checks. Reduces CPU usage dramatically.

**Pros**:
- CPU usage drops from 100% to near-zero
- Easy to understand

**Cons**:
- ⏱️ **Latency**: If a task is due in 5ms but we just started a 50ms sleep, we're 45ms late.
- 🚨 **No preemption**: If a new urgent task arrives while we're sleeping, we can't wake up early.
- Choosing the sleep interval is a lose-lose tradeoff: too short = wasted CPU, too long = missed deadlines.

**Verdict**: Better than spinning, but still broken for any system that needs precision or urgency.

---

### Approach 3: Condition Variable with `awaitNanos` ✅ (Our Solution)

```java
lock.lock();
try {
    while (true) {
        if (queue.isEmpty()) {
            condition.await();              // sleep forever until signaled
        } else {
            long delay = queue.peek().executionTime - System.nanoTime();
            if (delay > 0) {
                condition.awaitNanos(delay); // sleep EXACTLY until next task is due
            } else {
                execute(queue.poll());       // task is due — run it
            }
        }
    }
} finally {
    lock.unlock();
}
```

**How it works**:
1. The coordinator computes *exactly* how long until the next task fires
2. It sleeps for that precise duration using `condition.awaitNanos(delay)`
3. If a client submits a more urgent task, the client calls `condition.signal()`, which **wakes the coordinator immediately**
4. The coordinator re-checks the queue head, sees the new urgent task, and adjusts its wait

**Pros**:
- ⚡ **Zero CPU usage while waiting** — the thread is parked in the OS kernel's wait queue
- ⚡ **Precise timing** — wakes up exactly when the next task is due (nanosecond granularity)
- ⚡ **Instant preemption** — if something more urgent arrives, `signal()` wakes us in O(1)
- No polling, no fixed intervals, no tradeoffs

**Cons**:
- Slightly more complex to implement (need lock + condition + signal protocol)
- Must handle spurious wakeups (the `while` loop re-checks the condition)

**Verdict**: This is the production pattern. Java's `ScheduledThreadPoolExecutor` uses exactly this internally.

---

### Why `Condition` Variables Beat Everything Else

A `Condition` (from `java.util.concurrent.locks`) provides two operations:

| Operation | What it does |
|-----------|-------------|
| `await()` | Parks the current thread — zero CPU. Releases the associated lock. Thread sleeps until `signal()` is called. |
| `awaitNanos(n)` | Same as `await()`, but automatically wakes up after `n` nanoseconds if nobody signals first. |
| `signal()` | Wakes exactly one thread waiting on this condition. That thread re-acquires the lock and resumes. |

The key insight: **`awaitNanos` gives you a timer AND an interrupt in one primitive.** The coordinator says "wake me in 500ms OR sooner if something changes." No other approach gives you both.

💡 **Insight #1**: The coordinator thread spends 99.9% of its life parked in `awaitNanos`. It only wakes to (a) fire a due task, or (b) re-evaluate after a new submission. This is maximally efficient.

---

### The `nanoTime` vs `currentTimeMillis` Decision

Since our scheduler measures "time until next task fires," we need a clock. Java offers two:

| Property | `System.currentTimeMillis()` | `System.nanoTime()` |
|----------|-------------------------------|---------------------|
| What it measures | Wall-clock time (Unix epoch) | Elapsed time from an arbitrary origin |
| Monotonic? | **NO** — NTP can jump backward or forward | **YES** — always moves forward |
| Resolution | ~1-15ms (OS-dependent) | ~1ns (hardware TSC counter) |
| Good for | Logging, human-readable timestamps | Measuring intervals, scheduling |

> **What is NTP?** NTP (Network Time Protocol) is a background daemon that synchronizes your machine's wall-clock with global time servers (e.g., `time.google.com`). Your hardware clock drifts naturally, so NTP periodically corrects it — sometimes by gradually slewing the clock, but sometimes by **jumping** it forward or backward by hundreds of milliseconds. `System.currentTimeMillis()` reflects these NTP adjustments. `System.nanoTime()` reads a hardware counter (CPU's TSC) that NTP never touches.

**The Pitfall**: If you use `currentTimeMillis()` to compute delays:
- **NTP backward jump**: You scheduled a task for "now + 500ms." NTP pushes the clock back 200ms. Suddenly your task appears to be 700ms in the future. It fires 200ms late.
- **NTP forward jump**: Clock jumps forward. Your task fires prematurely.

**The Rule**: Use `System.nanoTime()` for all internal timing. It's monotonic — it only ever moves forward, immune to NTP adjustments. Use `currentTimeMillis()` only at the boundary where you need to print a human-readable timestamp in logs.

💡 **Insight #2**: In our `TaskScheduler`, every `executionTimeNanos` field stores a `nanoTime()` value. The coordinator computes `delay = task.executionTimeNanos - System.nanoTime()`. This subtraction is always correct because `nanoTime` never jumps.

---

## Part 3: The Rate Limiting Problem

### The Core Challenge

You want to allow at most N requests per second from a client, but:
- Allow **bursts** (a client can send 10 requests instantly if they've been idle)
- Enforce a **sustained rate** (over time, they can't exceed N/sec on average)
- Use **zero resources when idle** (no background threads ticking away for inactive clients)
- Be **thread-safe** (hundreds of goroutines/threads may call `allowRequest()` simultaneously)

---

### Approach 1: Fixed-Window Counter

```java
// Reset counter every second
if (currentSecond != lastSecond) { counter = 0; lastSecond = currentSecond; }
if (counter < maxPerSecond) { counter++; return ALLOW; }
return DENY;
```

**How it works**: Divide time into 1-second windows. Count requests in each window. Deny if over limit.

**Pros**:
- Dead simple. One integer, one timestamp.

**Cons**:
- 💥 **Boundary burst problem**: A client sends 100 requests at second 0.99, then 100 more at second 1.01. In two adjacent windows they're "within limit" (100 each), but in a 200ms real window they sent 200. The actual rate is 1000/sec!
- No concept of "burst budget" — can't distinguish a truly bursty client from a steady one.

**Verdict**: Too imprecise for serious rate limiting. Fine for rough counting.

---

### Approach 2: Sliding-Window Log

```java
// Store timestamp of every request
requestLog.add(now);
// Remove entries older than 1 second
requestLog.removeIf(ts -> now - ts > 1_000_000_000);
if (requestLog.size() <= maxPerSecond) return ALLOW;
return DENY;
```

**How it works**: Keep a log of every request timestamp. Count how many fall in the last 1-second window.

**Pros**:
- Perfectly accurate — no boundary problems

**Cons**:
- 📦 **O(N) memory per client** — if a client sends 10,000 requests/sec, you store 10,000 timestamps
- 🐢 **O(N) cleanup** on every request
- Unacceptable at scale with millions of clients

**Verdict**: Correct but doesn't scale.

---

### Approach 3: Token Bucket ✅ (Our Solution)

**Concept**: Imagine a bucket that holds at most `maxTokens` tokens. Tokens drip in at a steady rate (`refillRate` per second). Each request consumes one token. If the bucket is empty, deny.

```
Bucket: [●●●●●○○○○○]   (5 tokens remaining out of 10 max)
         ↑ refills over time
```

**Pros**:
- ⚡ **Allows bursts**: If a client was idle, the bucket fills up. They can send `maxTokens` requests instantly.
- ⚡ **Enforces sustained rate**: Over time, throughput can't exceed `refillRate` per second.
- ⚡ **O(1) space**: Just two numbers (current tokens + last refill time) per client.
- ⚡ **No boundary problems**: Continuous, not windowed.

**Cons**:
- Need to decide: how do we refill tokens?

---

### Token Bucket: Background Refill Thread vs. Lazy Refill

#### Sub-option A: Background Refill Thread

```java
scheduler.scheduleAtFixedRate(() -> {
    bucket.addTokens(refillRate / 10); // add tokens every 100ms
}, 0, 100, MILLISECONDS);
```

**How it works**: A dedicated thread wakes up periodically and adds tokens.

**Pros**:
- Tokens are always "physically" up-to-date

**Cons**:
- 🔥 Wastes a thread per rate limiter (or a shared scheduler — adds complexity)
- ⏱️ Timer granularity: if refill tick is every 100ms, a request at 50ms sees stale state
- GC pauses can delay refill ticks
- Resource waste when the client is idle — the thread keeps ticking for nothing

---

#### Sub-option B: Lazy Refill (Math On-Demand) ✅ (Our Solution)

```java
boolean allowRequest() {
    lock.lock();
    try {
        long now = System.nanoTime();
        long elapsed = now - lastRefillTime;
        
        // Mathematically compute how many tokens WOULD have been added
        double newTokens = elapsed * tokensPerNanosecond;
        currentTokens = Math.min(maxTokens, currentTokens + newTokens);
        lastRefillTime = now;
        
        if (currentTokens >= 1.0) {
            currentTokens -= 1.0;
            return true;  // ALLOWED
        }
        return false;     // DENIED
    } finally {
        lock.unlock();
    }
}
```

**How it works**: We never *actually* refill tokens in real-time. Instead, when a request arrives, we compute "how much time has passed since last check?" and mathematically add the proportional tokens. The bucket's state is always *logically* current, even though it's only *physically* updated on-demand.

**Pros**:
- ⚡ **Zero background threads** — no CPU cost when client is idle
- ⚡ **Mathematically precise** — no timer granularity issues
- ⚡ **Atomic** — the entire refill + check + deduct happens in one locked section
- ⚡ **Scales to millions of clients** — each is just 2 numbers, updated only when accessed

**Cons**:
- Slightly more math in the hot path (but it's just multiplication and min — trivial)

**Verdict**: This is the industry standard. Stripe, Cloudflare, and AWS all use lazy-refill token buckets.

💡 **Insight #3**: The Lazy Refill is a general principle — *don't maintain state eagerly if you can compute it on-demand.* It's the same philosophy as lazy evaluation in functional programming, applied to systems engineering.

---

## Part 4: End-to-End Walkthrough

Now that you understand *why* we made these choices, let's trace complete lifecycles through our implementations.

---

### TaskScheduler: Complete Request Lifecycle

```
Client Thread                          Coordinator Thread
─────────────                          ──────────────────
                                       [PARKED in awaitNanos — sleeping until task T1 at +5sec]
                                       
schedule("Urgent", action, 50ms)
  │
  ├─ lock.lock()
  ├─ compute executionTime = nanoTime() + 50ms
  ├─ add to PriorityQueue
  ├─ Is this the new HEAD? YES (50ms < 5sec)
  ├─ condition.signal() ──────────────→ [WAKES UP]
  ├─ lock.unlock()                       │
                                         ├─ re-acquire lock
                                         ├─ peek queue → "Urgent" at +50ms
                                         ├─ compute delay = 50ms - elapsed ≈ 49ms
                                         ├─ awaitNanos(49ms)
                                         │
                                         │  ... 49ms passes ...
                                         │
                                         ├─ [WAKES from awaitNanos]
                                         ├─ peek queue → "Urgent" is due!
                                         ├─ poll from queue
                                         ├─ lock.unlock()
                                         ├─ action.run()  ← TASK EXECUTES
                                         ├─ lock.lock()
                                         ├─ if recurring: recompute next time, re-enqueue
                                         ├─ peek queue → T1 at +5sec still there
                                         ├─ awaitNanos(remaining for T1)
                                         └─ [PARKED again]
```

**Key points**:
1. The coordinator is *always* either executing a task or parked in `awaitNanos`
2. Client threads never execute tasks — they only enqueue and signal
3. The signal only fires if the new task is *more urgent* than the current head (optimization: avoids unnecessary wakeups)
4. Recurring tasks re-enqueue themselves with `executionTime = now + period`

---

### TokenBucketRateLimiter: Complete Request Lifecycle

```
Thread A calls allowRequest()
  │
  ├─ lock.lock()
  │
  ├─ REFILL PHASE:
  │   ├─ now = System.nanoTime()
  │   ├─ elapsed = now - lastRefillTime     → e.g., 250,000,000 ns (250ms)
  │   ├─ tokensToAdd = elapsed × rate       → e.g., 250ms × 10/sec = 2.5 tokens
  │   ├─ currentTokens = min(max, current + 2.5)  → e.g., min(10, 0 + 2.5) = 2.5
  │   └─ lastRefillTime = now
  │
  ├─ CONSUME PHASE:
  │   ├─ currentTokens (2.5) >= 1.0?  → YES
  │   ├─ currentTokens -= 1.0         → now 1.5
  │   └─ return TRUE (ALLOWED)
  │
  └─ lock.unlock()


Thread B calls allowRequest() 1 nanosecond later
  │
  ├─ lock.lock()  [waits for Thread A to release]
  │
  ├─ REFILL PHASE:
  │   ├─ elapsed = 1 ns → tokensToAdd ≈ 0.00000001 → negligible
  │   └─ currentTokens stays at 1.5
  │
  ├─ CONSUME PHASE:
  │   ├─ 1.5 >= 1.0? → YES
  │   ├─ currentTokens -= 1.0 → now 0.5
  │   └─ return TRUE (ALLOWED)
  │
  └─ lock.unlock()


Thread C calls allowRequest() immediately after
  │
  ├─ REFILL: negligible time → currentTokens = 0.5
  ├─ CONSUME: 0.5 >= 1.0? → NO
  └─ return FALSE (DENIED) ← rate limit enforced
```

**Key points**:
1. The `ReentrantLock` serializes access — only one thread refills+consumes at a time
2. Refill is proportional to *actual elapsed time* — no approximation, no timer ticks
3. The bucket caps at `maxTokens` — idle clients can't accumulate infinite burst capacity
4. The entire operation (refill + consume) is atomic from the caller's perspective

---

## Part 5: Concurrency Primitives Reference

Quick reference for the building blocks used in this module:

| Primitive | What it does | Where we use it |
|-----------|-------------|-----------------|
| `ReentrantLock` | Mutual exclusion — only one thread holds it at a time. Re-entrant means the same thread can lock it multiple times without deadlock. | Both engines: protects shared state |
| `Condition` | Wait/signal mechanism tied to a lock. `await()` parks the thread. `signal()` wakes one parked thread. | TaskScheduler: coordinator sleeps/wakes |
| `awaitNanos(n)` | Timed wait — parks for at most `n` nanoseconds, or until signaled, whichever comes first. | TaskScheduler: precise sleep until next task |
| `PriorityQueue` | Min-heap — `peek()`/`poll()` always returns the smallest element. O(log n) insert, O(1) peek. | TaskScheduler: tasks sorted by execution time |
| `volatile` | Ensures visibility across threads without a full lock. Writes by one thread are immediately visible to others. | TaskScheduler: `isShutdown` flag |
| `System.nanoTime()` | Monotonic clock — never jumps, nanosecond resolution. Only meaningful for measuring *intervals* (not wall-clock time). | Both engines: all timing decisions |
| `CountDownLatch` | A one-shot barrier — threads wait until the count reaches zero. | Runners: synchronized test starts |
| `AtomicInteger` | Lock-free thread-safe integer — `incrementAndGet()`, `get()`. | Runners: counting task executions |
| `Semaphore` | Counting permit — controls how many threads can access a resource concurrently. `acquire()` blocks if no permits; `release()` returns a permit. | Connection pools, bounded parallelism (see Part 4b below) |

---

## Part 5b: Semaphores — Bounded Parallelism

### What is a Semaphore?

A **Semaphore** is a concurrency primitive that maintains a count of available **permits**. Threads must `acquire()` a permit before proceeding and `release()` it when done. If no permits are available, the thread blocks until one is released.

**Key insight:** A Semaphore with 1 permit behaves like a mutex (lock). A Semaphore with N permits allows up to N threads to access a resource concurrently.

### When to Use Semaphores (vs Locks)

| Use Case | Correct Primitive | Why |
|----------|------------------|-----|
| Mutual exclusion (only 1 thread) | `ReentrantLock` or `synchronized` | Simpler, supports Conditions, reentrant |
| Bounded parallelism (at most N threads) | `Semaphore(N)` | Allows controlled concurrency > 1 |
| Connection pool (max 10 connections) | `Semaphore(10)` | Threads wait when pool is exhausted |
| Rate limiting (N concurrent requests) | `Semaphore(N)` | Natural bounded concurrency |
| Read/write separation | `StampedLock` or `ReadWriteLock` | Optimized for asymmetric access |

### How It Works

```java
Semaphore pool = new Semaphore(5);  // Allow 5 concurrent operations

void useResource() throws InterruptedException {
    pool.acquire();           // Block if all 5 permits are taken
    try {
        // Only 5 threads can be here simultaneously
        doExpensiveWork();
    } finally {
        pool.release();       // Return the permit — MUST be in finally
    }
}
```

### Semaphore vs Lock — The Crucial Difference

```
Lock (ReentrantLock):
  - Thread that locks MUST be the thread that unlocks
  - Reentrant: same thread can lock multiple times
  - Supports Conditions (await/signal)
  - Binary: locked or unlocked

Semaphore:
  - Any thread can release (not just the acquirer)
  - NOT reentrant
  - No Conditions (use Lock + Condition for that)
  - Counting: 0 to N permits
```

### Real-World Example: Database Connection Pool

```java
public class ConnectionPool {
    private final Semaphore permits;
    private final ArrayBlockingQueue<Connection> connections;

    public ConnectionPool(int maxConnections) {
        this.permits = new Semaphore(maxConnections, true); // fair
        this.connections = new ArrayBlockingQueue<>(maxConnections);
        // Pre-create connections
        for (int i = 0; i < maxConnections; i++) {
            connections.add(createConnection());
        }
    }

    public Connection borrow() throws InterruptedException {
        permits.acquire();              // Block if all connections are in use
        return connections.poll();      // Safe — permit guarantees availability
    }

    public void returnConnection(Connection conn) {
        connections.offer(conn);
        permits.release();              // Make a permit available for waiting threads
    }
}
```

### Interview Q&A

**Q: "When would you use a Semaphore over a Lock?"**
> "When I need to allow more than one thread into a critical section simultaneously. A Lock is binary — one thread at a time. A Semaphore with N permits allows up to N concurrent threads. Classic example: a connection pool with 10 connections — you want up to 10 threads to use connections concurrently, but the 11th must wait."

**Q: "Can a Semaphore deadlock?"**
> "A Semaphore itself can't deadlock (it's not reentrant, so there's no lock-ordering issue). But if you `acquire()` without a corresponding `release()` (e.g., exception skips the finally block), you permanently lose a permit — eventually all permits leak and all threads block forever. This is a permit leak, not a deadlock, but the effect is the same."

---

## Part 6: Common Interview Questions

**Q: What happens if two tasks have the same timestamp?**
A: We use a monotonically increasing `sequenceNumber` as a tie-breaker in `compareTo()`. Tasks with equal timestamps execute in FIFO (submission) order.

**Q: Can the token bucket overflow (exceed maxTokens)?**
A: No. The refill uses `Math.min(maxTokens, currentTokens + tokensToAdd)`. The bucket is hard-capped.

**Q: What if `allowRequest()` is called from 100 threads simultaneously?**
A: The `ReentrantLock` serializes access. Only one thread enters the refill+consume section at a time. Others queue on the lock. This guarantees no double-spending of tokens.

**Q: Why not use `synchronized` instead of `ReentrantLock`?**
A: `synchronized` doesn't support `awaitNanos` (timed waiting on a condition). We need `Condition.awaitNanos()` for the scheduler, which requires a `ReentrantLock`. We use `ReentrantLock` in both engines for consistency.

**Q: What's the time complexity of the scheduler?**
A: Submit: O(log n) — PriorityQueue insertion. Wake/fire: O(log n) — PriorityQueue poll. Waiting: O(1) — parked thread costs nothing.

**Q: Why a single coordinator thread instead of a thread pool?**
A: One thread is sufficient because it only does scheduling logic (peek, poll, compute delay). Actual task execution is fast (or should be — long-running tasks should delegate to a separate pool). One thread eliminates contention on the queue from the execution side.

---

## Part 7: Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                    Traffic Coordination Module                    │
├──────────────────────────────────┬──────────────────────────────┤
│         TaskScheduler            │     TokenBucketRateLimiter    │
│                                  │                              │
│  Client threads                  │  Client threads              │
│       │                          │       │                      │
│       ▼ schedule() / signal()    │       ▼ allowRequest()       │
│  ┌─────────────────────────┐     │  ┌──────────────────────┐    │
│  │   PriorityQueue<Task>   │     │  │   Lazy Refill State  │    │
│  │   (min-heap by time)    │     │  │   currentTokens      │    │
│  └────────────┬────────────┘     │  │   lastRefillNanos    │    │
│               │                  │  └──────────┬───────────┘    │
│  ┌────────────▼────────────┐     │             │               │
│  │  Coordinator Thread     │     │     lock → refill() →       │
│  │  awaitNanos(delay)      │     │     consume/deny → unlock   │
│  │  fires task, re-enqueues│     │                              │
│  └─────────────────────────┘     │  No background threads.     │
│                                  │  Pure math on access.        │
└──────────────────────────────────┴──────────────────────────────┘
```

---

## How to Run

### Directory Layout

```
src/
├── engine/
│   ├── TaskScheduler.java              ← Core scheduling: PriorityQueue + awaitNanos
│   └── TokenBucketRateLimiter.java     ← Core rate-limiting: Lazy Refill
└── runners/
    ├── ComprehensiveSimulationRunner.java  ← 8 stress tests with assertions
    └── InterviewLeanRunner.java            ← Minimal demo (~70 lines)
```

### Compile & Run

#### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day6:run                                                  # Runs ComprehensiveSimulationRunner
./gradlew :day6:run -PmainClass=runners.InterviewLeanRunner          # Quick interview demo
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on any `main()` method directly.

#### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out runners.InterviewLeanRunner
java -ea -cp out runners.ComprehensiveSimulationRunner
```

### Design Principles

1. **Zero Monolithic Files** — Each concern in its own file
2. **Code Reuse** — Runners only instantiate engines; zero duplicated logic
3. **Monotonic Time** — All scheduling uses `nanoTime()` internally
4. **Condition-Based Coordination** — No polling, no busy-waiting, no `Thread.sleep` hacks
5. **Lazy Computation** — Rate limiter state computed on-demand, not maintained eagerly
6. **Graceful Lifecycle** — Both engines support clean `shutdown()` semantics

---

## Practice Yourself — Production Evolution

### The Limitation of Our Current Design

In our `TaskScheduler`, the single coordinator thread is both the **scheduler** (decides *when* to fire tasks) and the **executor** (actually *runs* them):

```
Submitters ──→ [PriorityQueue] ──→ Coordinator Thread
                                         │
                                         ├─ awaitNanos (scheduling)
                                         ├─ task.action.run() ← BLOCKS here
                                         └─ re-enqueue if recurring
```

**The problem**: If a task's `run()` takes 2 seconds, the coordinator is blocked for 2 seconds. All other due tasks queue up behind it. Scheduling precision collapses under heavy or slow workloads.

This is fine for an interview demo (lightweight tasks, clean explanation), but unacceptable in production.

---

### The Evolved Architecture: Scheduling Engine + Task Consumer Pool

Separate the two concerns:

```
Submitters ──→ [PriorityQueue] ──→ Scheduling Engine (single thread)
                                         │
                                         │ task is due → dispatch (non-blocking)
                                         ▼
                                   ┌─────────────────────┐
                                   │  Task Consumer Pool │
                                   │                     │
                                   │  Consumer-1 (thread)│
                                   │  Consumer-2 (thread)│
                                   │  Consumer-N (thread)│
                                   └─────────────────────┘
```

**Scheduling Engine** — Owns the PriorityQueue, lock, Condition, `awaitNanos` loop. When a task is due, it **dispatches** it to a consumer and immediately returns to checking the next task. It never blocks on execution.

**Task Consumer** — Receives dispatched tasks and executes them. Can be a thread pool, a single-thread queue, a priority executor, or even a rate-limited executor.

---

### Why This Separation Matters

| Concern | Monolithic (current) | Separated (production) |
|---------|---------------------|------------------------|
| Scheduling precision | Degrades with slow tasks | Always precise — scheduler never blocks |
| Parallelism | Tasks run sequentially | Tasks run concurrently across N consumers |
| Backpressure | None — queue grows unbounded | Can add bounded queues, rejection policies |
| Extensibility | One execution strategy | Plug in any consumer: thread pool, async, rate-limited |
| Testability | Hard to test scheduling vs execution independently | Each concern is independently unit-testable |
| Single Responsibility | Violated — one class does two jobs | Clean SRP — scheduling ≠ execution |

---

### Boilerplate Code to Get You Started

#### Step 1: Define the TaskConsumer Interface

```java
package engine.v2;

/**
 * Defines how dispatched tasks are consumed/executed.
 * The Scheduling Engine dispatches to this; it never executes tasks itself.
 */
public interface TaskConsumer {

    /**
     * Called by the Scheduling Engine when a task is due.
     * Implementations decide HOW to execute (thread pool, single thread, async, etc.)
     * This method MUST return quickly — it should not block on task execution.
     */
    void consume(Runnable task, String taskName);

    /**
     * Graceful shutdown — stop accepting new tasks, finish in-flight ones.
     */
    void shutdown();
}
```

#### Step 2: Implement a Thread-Pool Consumer

```java
package engine.v2;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Executes dispatched tasks on a fixed thread pool.
 * Non-blocking dispatch — tasks are submitted to the pool and return immediately.
 */
public class ThreadPoolConsumer implements TaskConsumer {

    private final ExecutorService pool;

    public ThreadPoolConsumer(int numThreads) {
        this.pool = Executors.newFixedThreadPool(numThreads, r -> {
            Thread t = new Thread(r);
            t.setDaemon(true);
            t.setName("TaskConsumer-" + t.getId());
            return t;
        });
    }

    @Override
    public void consume(Runnable task, String taskName) {
        pool.submit(() -> {
            try {
                task.run();
            } catch (Exception e) {
                System.err.println("[Consumer] Task '" + taskName + "' failed: " + e.getMessage());
            }
        });
    }

    @Override
    public void shutdown() {
        pool.shutdown();
        try {
            pool.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            pool.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
```

#### Step 3: Implement a Rate-Limited Consumer (Combines Both Engines!)

```java
package engine.v2;

import engine.TokenBucketRateLimiter;

/**
 * Wraps another consumer with rate-limiting.
 * Tasks that exceed the rate are logged and dropped (or could be queued).
 * 
 * This demonstrates composability — consumers can wrap other consumers.
 */
public class RateLimitedConsumer implements TaskConsumer {

    private final TaskConsumer delegate;
    private final TokenBucketRateLimiter rateLimiter;

    public RateLimitedConsumer(TaskConsumer delegate, long maxBurst, double ratePerSecond) {
        this.delegate = delegate;
        this.rateLimiter = new TokenBucketRateLimiter(maxBurst, ratePerSecond);
    }

    @Override
    public void consume(Runnable task, String taskName) {
        if (rateLimiter.allowRequest()) {
            delegate.consume(task, taskName);
        } else {
            System.err.println("[RateLimited] Task '" + taskName + "' dropped — rate limit exceeded");
        }
    }

    @Override
    public void shutdown() {
        delegate.shutdown();
    }
}
```

#### Step 4: Modify the Scheduling Engine to Use a Consumer

```java
package engine.v2;

import java.util.PriorityQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * The Scheduling Engine — ONLY responsible for timing decisions.
 * When a task is due, it dispatches to the injected TaskConsumer.
 * It NEVER executes tasks itself.
 */
public class SchedulingEngine {

    private final PriorityQueue<ScheduledTask> taskQueue = new PriorityQueue<>();
    private final ReentrantLock lock = new ReentrantLock();
    private final Condition taskAvailable = lock.newCondition();
    private final TaskConsumer consumer;  // ← injected dependency

    private volatile boolean isShutdown = false;
    private long sequenceCounter = 0;
    private final Thread coordinatorThread;

    public SchedulingEngine(TaskConsumer consumer) {
        this.consumer = consumer;
        this.coordinatorThread = new Thread(this::coordinatorLoop, "SchedulingEngine-Coordinator");
        this.coordinatorThread.setDaemon(true);
        this.coordinatorThread.start();
    }

    public void schedule(String name, Runnable action, long delay, TimeUnit unit) {
        long executeAt = System.nanoTime() + unit.toNanos(delay);
        enqueue(new ScheduledTask(name, action, executeAt, 0, nextSequence()));
    }

    public void scheduleAtFixedRate(String name, Runnable action,
                                    long initialDelay, long period, TimeUnit unit) {
        long executeAt = System.nanoTime() + unit.toNanos(initialDelay);
        enqueue(new ScheduledTask(name, action, executeAt, unit.toNanos(period), nextSequence()));
    }

    public void shutdown() {
        lock.lock();
        try {
            isShutdown = true;
            taskAvailable.signal();
        } finally {
            lock.unlock();
        }
        consumer.shutdown();
    }

    // ─── The critical difference is in the coordinator loop ─────────────────

    private void coordinatorLoop() {
        lock.lock();
        try {
            while (!isShutdown || !taskQueue.isEmpty()) {
                if (taskQueue.isEmpty()) {
                    if (isShutdown) break;
                    taskAvailable.await();
                    continue;
                }

                long now = System.nanoTime();
                ScheduledTask head = taskQueue.peek();
                long delay = head.executionTimeNanos - now;

                if (delay > 0) {
                    taskAvailable.awaitNanos(delay);
                    continue;
                }

                taskQueue.poll();

                // ══════════════════════════════════════════════════════════════
                // KEY DIFFERENCE: Dispatch to consumer instead of running inline
                // The coordinator does NOT release its lock for execution.
                // It dispatches and IMMEDIATELY moves to the next task.
                // ══════════════════════════════════════════════════════════════
                consumer.consume(head.action, head.name);

                // Re-enqueue recurring tasks
                if (head.isRecurring() && !isShutdown) {
                    head.executionTimeNanos = System.nanoTime() + head.periodNanos;
                    taskQueue.offer(head);
                }
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }

    // ─── Helper methods (same as before) ────────────────────────────────────

    private long nextSequence() {
        lock.lock();
        try { return sequenceCounter++; }
        finally { lock.unlock(); }
    }

    private void enqueue(ScheduledTask task) {
        lock.lock();
        try {
            if (isShutdown) return;
            boolean isNewHead = taskQueue.isEmpty() || task.compareTo(taskQueue.peek()) < 0;
            taskQueue.offer(task);
            if (isNewHead) taskAvailable.signal();
        } finally {
            lock.unlock();
        }
    }

    // ─── Inner class (same structure) ───────────────────────────────────────

    public static class ScheduledTask implements Comparable<ScheduledTask> {
        final String name;
        final Runnable action;
        long executionTimeNanos;
        final long periodNanos;
        final long sequenceNumber;

        ScheduledTask(String name, Runnable action, long executionTimeNanos,
                      long periodNanos, long sequenceNumber) {
            this.name = name;
            this.action = action;
            this.executionTimeNanos = executionTimeNanos;
            this.periodNanos = periodNanos;
            this.sequenceNumber = sequenceNumber;
        }

        boolean isRecurring() { return periodNanos > 0; }

        @Override
        public int compareTo(ScheduledTask other) {
            int cmp = Long.compare(this.executionTimeNanos, other.executionTimeNanos);
            return cmp != 0 ? cmp : Long.compare(this.sequenceNumber, other.sequenceNumber);
        }
    }
}
```

#### Step 5: Usage Example — Composing the Pieces

```java
// Create a consumer: 4-thread pool, rate-limited to 100 tasks/sec with burst of 20
TaskConsumer pool = new ThreadPoolConsumer(4);
TaskConsumer rateLimited = new RateLimitedConsumer(pool, 20, 100.0);

// Create scheduling engine with the rate-limited consumer
SchedulingEngine engine = new SchedulingEngine(rateLimited);

// Schedule tasks — they'll be dispatched to the pool, rate-limited
engine.schedule("Task-A", () -> heavyWork(), 100, TimeUnit.MILLISECONDS);
engine.scheduleAtFixedRate("Heartbeat", () -> ping(), 0, 1, TimeUnit.SECONDS);

// Later...
engine.shutdown();
```

---

### Design Patterns at Play

1. **Strategy Pattern** — `TaskConsumer` is a strategy for execution. The engine doesn't know or care *how* tasks are executed.
2. **Decorator Pattern** — `RateLimitedConsumer` wraps another consumer, adding behavior without modifying the original.
3. **Dependency Injection** — The engine receives its consumer at construction time. Easy to swap, easy to test.
4. **Single Responsibility** — Scheduling engine: *when*. Consumer: *how*. Neither knows the other's details.

---

### Challenge Exercises

If you want to practice this architecture further:

1. **Implement a `BoundedQueueConsumer`** that has a max capacity. If the queue is full, it rejects new tasks and logs a warning (backpressure).

2. **Implement a `PriorityConsumer`** that has its own internal priority queue — so even after dispatch, tasks execute in priority order (not just FIFO within the thread pool).

3. **Implement a `RetryConsumer`** that catches exceptions from task execution and re-schedules the task with exponential backoff (feeding back into the scheduling engine).

4. **Write a stress test** that dispatches 10,000 tasks where each takes 100ms to execute. Compare behavior with:
   - A single-thread consumer (sequential, takes 1000 seconds)
   - A 100-thread pool consumer (parallel, takes ~10 seconds)
   - Show that the scheduling engine's timing is precise in both cases (it never blocks)

5. **Add metrics** to the scheduling engine: track dispatch latency (time between "task was due" and "consumer.consume() was called"). It should be < 1ms even under load.

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
