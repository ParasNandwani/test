package util;

import java.util.Random;

/**
 * Generates deterministic test data and random offset sequences for benchmarks.
 *
 * Design decisions:
 * - Uses a fixed seed for reproducibility across runs
 * - Generates pseudo-random byte content (not zeros) to avoid filesystem
 *   optimizations that detect and compress zero-filled blocks
 * - Random offsets are pre-computed and shuffled using Fisher-Yates to ensure
 *   every chunk position is written exactly once (complete file coverage)
 */
public final class DataGenerator {

    private static final long SEED = 0xDEADBEEF_CAFEBABEL;

    private DataGenerator() {
        // Utility class — no instantiation
    }

    /**
     * Generate a byte array of the given size filled with pseudo-random data.
     *
     * Why not zeros?
     * - Many filesystems (ZFS, APFS, Btrfs) detect zero-filled blocks and use
     *   sparse file optimization or inline compression, which would skew benchmarks.
     * - Random data ensures the full write path is exercised.
     *
     * @param sizeBytes total size of the generated data
     * @return byte array filled with pseudo-random content
     */
    public static byte[] generate(int sizeBytes) {
        byte[] data = new byte[sizeBytes];
        Random rng = new Random(SEED);
        rng.nextBytes(data);
        return data;
    }

    /**
     * Generate a shuffled array of file offsets for random-access writes.
     *
     * The array contains every valid chunk-aligned offset in [0, fileSize),
     * shuffled using Fisher-Yates algorithm for uniform distribution.
     *
     * This ensures:
     * - Every chunk is written exactly once (no gaps, no overlaps)
     * - Access order is uniformly random (worst-case for caching)
     *
     * @param fileSize   total file size in bytes
     * @param chunkSize  size of each write chunk
     * @return shuffled array of offsets
     */
    public static int[] generateRandomOffsets(int fileSize, int chunkSize) {
        int numChunks = fileSize / chunkSize;
        int[] offsets = new int[numChunks];

        // Initialize with sequential offsets
        for (int i = 0; i < numChunks; i++) {
            offsets[i] = i * chunkSize;
        }

        // Fisher-Yates shuffle with deterministic seed
        Random rng = new Random(SEED + 1); // Different seed from data to avoid correlation
        for (int i = numChunks - 1; i > 0; i--) {
            int j = rng.nextInt(i + 1);
            int temp = offsets[i];
            offsets[i] = offsets[j];
            offsets[j] = temp;
        }

        return offsets;
    }
}