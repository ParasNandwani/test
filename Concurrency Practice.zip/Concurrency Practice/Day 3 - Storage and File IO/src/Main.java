import benchmark.AccessPattern;
import benchmark.BenchmarkResult;
import benchmark.BenchmarkRunner;
import engine.BufferedSequentialEngine;
import engine.MemoryMappedEngine;
import engine.UnbufferedEngine;
import engine.WriteEngine;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * I/O Performance Evaluation Engine — Entry Point.
 *
 * Demonstrates the performance impact of different I/O strategies:
 *   Engine A: Unbuffered writes + fsync per chunk (worst case)
 *   Engine B: Application-buffered writes + single fsync (balanced)
 *   Engine C: Memory-mapped I/O via MappedByteBuffer (best case)
 *
 * Usage:
 *   java Main                          → Default: 8MB file, all engines, both patterns
 *   java Main --size 64                → 64MB file size
 *   java Main --engines A,B,C          → Select specific engines
 *   java Main --patterns SEQ,RAND      → Select specific patterns
 *   java Main --iterations 5           → Number of measured iterations (best-of-N)
 *
 * NOTE: Engine A with large files (>16MB) will be extremely slow due to per-chunk fsync.
 *       Default file size is 8MB to keep total benchmark time reasonable (~30-60s).
 */
public class Main {

    private static final int DEFAULT_FILE_SIZE_MB = 8;
    private static final int DEFAULT_ITERATIONS = 3;

    public static void main(String[] args) {
        int fileSizeMB = DEFAULT_FILE_SIZE_MB;
        int iterations = DEFAULT_ITERATIONS;
        List<String> engineSelection = Arrays.asList("A", "B", "C");
        List<String> patternSelection = Arrays.asList("SEQ", "RAND");

        // Parse CLI arguments
        for (int i = 0; i < args.length; i++) {
            switch (args[i]) {
                case "--size":
                    fileSizeMB = Integer.parseInt(args[++i]);
                    break;
                case "--engines":
                    engineSelection = Arrays.asList(args[++i].split(","));
                    break;
                case "--patterns":
                    patternSelection = Arrays.asList(args[++i].split(","));
                    break;
                case "--iterations":
                    iterations = Integer.parseInt(args[++i]);
                    break;
                case "--help":
                    printUsage();
                    return;
                default:
                    System.err.println("Unknown argument: " + args[i]);
                    printUsage();
                    return;
            }
        }

        // Build engine list
        List<WriteEngine> engines = new ArrayList<>();
        for (String sel : engineSelection) {
            switch (sel.trim().toUpperCase()) {
                case "A":
                    engines.add(new UnbufferedEngine());
                    break;
                case "B":
                    engines.add(new BufferedSequentialEngine());
                    break;
                case "C":
                    engines.add(new MemoryMappedEngine());
                    break;
                default:
                    System.err.println("Unknown engine: " + sel + " (valid: A, B, C)");
                    return;
            }
        }

        // Build pattern list
        List<AccessPattern> patterns = new ArrayList<>();
        for (String sel : patternSelection) {
            switch (sel.trim().toUpperCase()) {
                case "SEQ":
                case "SEQUENTIAL":
                    patterns.add(AccessPattern.SEQUENTIAL);
                    break;
                case "RAND":
                case "RANDOM":
                    patterns.add(AccessPattern.RANDOM);
                    break;
                default:
                    System.err.println("Unknown pattern: " + sel + " (valid: SEQ, RAND)");
                    return;
            }
        }

        // Print header
        System.out.println();
        System.out.println("══════════════════════════════════════════════════════════════════════════");
        System.out.println("  I/O PERFORMANCE EVALUATION ENGINE");
        System.out.println("══════════════════════════════════════════════════════════════════════════");
        System.out.printf("  Configuration: %d MB file | %d iterations | Engines: %s | Patterns: %s%n",
                fileSizeMB, iterations, engineSelection, patternSelection);
        System.out.println("──────────────────────────────────────────────────────────────────────────");
        System.out.printf("  JVM: %s %s | OS: %s %s (%s)%n",
                System.getProperty("java.vm.name"),
                System.getProperty("java.version"),
                System.getProperty("os.name"),
                System.getProperty("os.version"),
                System.getProperty("os.arch"));
        System.out.println("──────────────────────────────────────────────────────────────────────────");

        // Run benchmarks
        BenchmarkRunner runner = new BenchmarkRunner(fileSizeMB, iterations, engines, patterns);
        try {
            List<BenchmarkResult> results = runner.runAll();
            BenchmarkRunner.printResults(results, fileSizeMB);
        } catch (IOException e) {
            System.err.println("Benchmark failed with I/O error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    private static void printUsage() {
        System.out.println("Usage: java Main [options]");
        System.out.println("Options:");
        System.out.println("  --size <MB>          File size in megabytes (default: 8)");
        System.out.println("  --engines <A,B,C>    Comma-separated engine list (default: A,B,C)");
        System.out.println("  --patterns <SEQ,RAND> Comma-separated patterns (default: SEQ,RAND)");
        System.out.println("  --iterations <N>     Number of measured runs per benchmark (default: 3)");
        System.out.println("  --help               Show this help message");
        System.out.println();
        System.out.println("Engines:");
        System.out.println("  A = Unbuffered + fsync per chunk (slow, durable)");
        System.out.println("  B = Buffered 8KB + single fsync (balanced)");
        System.out.println("  C = Memory-Mapped via MappedByteBuffer (fastest)");
    }
}