package engine;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Path;

/**
 * Engine C: Memory-Mapped (mmap) Writer.
 *
 * Uses FileChannel.map() to create a MappedByteBuffer that maps the file's
 * pages directly into the process's virtual address space.
 *
 * How it works at the OS level:
 * 1. FileChannel.map() calls the mmap() system call ONCE.
 * 2. The kernel sets up page table entries mapping virtual addresses → file pages in the Page Cache.
 * 3. Writing to the MappedByteBuffer is a simple memory store instruction — NO system call.
 * 4. When a page is first accessed, the MMU triggers a page fault; the kernel loads the page from disk.
 * 5. Modified (dirty) pages are flushed to disk by the kernel's writeback daemon asynchronously.
 * 6. Calling force() explicitly flushes dirty pages (equivalent to msync/fsync).
 *
 * Key advantages:
 * - Zero-copy: data goes directly from JVM memory to Page Cache (they're the same physical pages)
 * - No per-write system call overhead
 * - OS handles prefetching for sequential patterns automatically
 * - Ideal for large files with known sizes
 *
 * Expected throughput: ~500-2000 MB/s sequential on SSD (limited by memory bandwidth, not I/O).
 */
public class MemoryMappedEngine implements WriteEngine {

    @Override
    public String name() {
        return "C (Memory-Mapped)";
    }

    @Override
    public void writeSequential(Path filePath, byte[] data) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(filePath.toFile(), "rw");
             FileChannel channel = raf.getChannel()) {

            // Map the entire file region into virtual memory.
            // This is the ONE system call — everything after is just memory operations.
            MappedByteBuffer buffer = channel.map(
                    FileChannel.MapMode.READ_WRITE,
                    0,
                    data.length
            );

            // Sequential write: put() advances the buffer position automatically.
            // Each put() is a memory store to the Page Cache — no syscall, no copy.
            buffer.put(data);

            // Force dirty pages to stable storage (equivalent to msync + fsync).
            // Without this, data is only in the Page Cache (volatile).
            buffer.force();
        }
    }

    @Override
    public void writeRandom(Path filePath, byte[] data, int chunkSize, int[] offsets) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(filePath.toFile(), "rw");
             FileChannel channel = raf.getChannel()) {

            // Map the full file region
            MappedByteBuffer buffer = channel.map(
                    FileChannel.MapMode.READ_WRITE,
                    0,
                    data.length
            );

            // Random access: use absolute put at each offset.
            // Each first-access to a new page triggers a page fault (kernel loads the page),
            // but subsequent accesses to the same page are pure memory operations.
            for (int offset : offsets) {
                int length = Math.min(chunkSize, data.length - offset);
                // Position the buffer and write the chunk
                buffer.position(offset);
                buffer.put(data, offset, length);
            }

            // Single force() at the end — flush all dirty mapped pages to disk
            buffer.force();
        }
    }
}