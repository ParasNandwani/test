package engine;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.file.Path;

/**
 * Engine B: Buffered Sequential Writer.
 *
 * Uses an application-level buffer (default 8KB) to aggregate small writes
 * into optimal block-sized I/O operations before hitting the kernel.
 *
 * Key performance characteristics:
 * 1. Reduces system calls by factor of (bufferSize / writeSize)
 *    - For 512-byte logical writes with 8KB buffer: 16x fewer syscalls
 * 2. Aligns writes to filesystem block boundaries (typically 4KB)
 *    - Avoids read-modify-write cycles at the block layer
 * 3. Lets the OS Page Cache coalesce writes and flush them optimally
 * 4. Only one fsync at the end — amortizes the hardware flush cost
 *
 * Expected throughput: ~200-500 MB/s sequential on SSD.
 */
public class BufferedSequentialEngine implements WriteEngine {

    private static final int DEFAULT_BUFFER_SIZE = 8 * 1024; // 8KB — matches common filesystem block size

    private final int bufferSize;

    public BufferedSequentialEngine() {
        this(DEFAULT_BUFFER_SIZE);
    }

    public BufferedSequentialEngine(int bufferSize) {
        this.bufferSize = bufferSize;
    }

    @Override
    public String name() {
        return "B (Buffered " + (bufferSize / 1024) + "KB)";
    }

    @Override
    public void writeSequential(Path filePath, byte[] data) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(filePath.toFile())) {
            // Application-level buffering: we batch writes into bufferSize chunks.
            // Each fos.write() of bufferSize bytes = 1 system call to the kernel.
            // The kernel then places data in the Page Cache (no immediate disk I/O).
            int offset = 0;
            while (offset < data.length) {
                int length = Math.min(bufferSize, data.length - offset);
                fos.write(data, offset, length);
                offset += length;
            }
            // Single fsync at the end: flush all dirty Page Cache pages to disk.
            // This is the "one trip to the vault" approach — amortized over the entire file.
            fos.getFD().sync();
        }
    }

    @Override
    public void writeRandom(Path filePath, byte[] data, int chunkSize, int[] offsets) throws IOException {
        // Pre-allocate the file to full size
        try (FileOutputStream fos = new FileOutputStream(filePath.toFile())) {
            fos.write(new byte[data.length]);
        }

        try (RandomAccessFile raf = new RandomAccessFile(filePath.toFile(), "rw")) {
            // For random writes, we still use our buffer strategy:
            // We write chunkSize bytes at each random offset.
            // No fsync per-write — we batch the durability guarantee.
            for (int offset : offsets) {
                int length = Math.min(chunkSize, data.length - offset);
                raf.seek(offset);
                raf.write(data, offset, length);
            }
            // Single fsync after all random writes are complete
            raf.getFD().sync();
        }
    }
}