package engine;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;

/**
 * Engine A: Unbuffered / Naive Writer.
 *
 * Writes data in small chunks (512 bytes) using a raw FileOutputStream,
 * issuing an fsync after every chunk to force durability.
 *
 * This demonstrates the catastrophic performance cost of:
 * 1. Frequent user-space → kernel-space context switches (one per write call)
 * 2. Forcing the hardware to confirm each write (fsync blocks until stable storage)
 *
 * Expected throughput: ~1-5 MB/s on SSD due to fsync latency dominating.
 */
public class UnbufferedEngine implements WriteEngine {

    private static final int CHUNK_SIZE = 512; // Small chunk to maximize syscall overhead

    @Override
    public String name() {
        return "A (Unbuffered + fsync)";
    }

    @Override
    public void writeSequential(Path filePath, byte[] data) throws IOException {
        try (FileOutputStream fos = new FileOutputStream(filePath.toFile())) {
            int offset = 0;
            while (offset < data.length) {
                int length = Math.min(CHUNK_SIZE, data.length - offset);
                fos.write(data, offset, length);
                // Force data to stable storage after every chunk.
                // This is the "bank vault receipt" — we wait for hardware confirmation.
                fos.getFD().sync();
                offset += length;
            }
        }
    }

    @Override
    public void writeRandom(Path filePath, byte[] data, int chunkSize, int[] offsets) throws IOException {
        // Pre-create the file at full size so random seeks are valid
        try (FileOutputStream fos = new FileOutputStream(filePath.toFile())) {
            fos.write(new byte[data.length]);
        }

        // Use RandomAccessFile for seeking to arbitrary offsets
        try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(filePath.toFile(), "rw")) {
            for (int offset : offsets) {
                int length = Math.min(chunkSize, data.length - offset);
                raf.seek(offset);
                raf.write(data, offset, length);
                // fsync after every random write — simulates worst-case durability requirement
                raf.getFD().sync();
            }
        }
    }
}