package engine;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Common interface for all file-writing engines.
 * Each engine implements a different I/O strategy to demonstrate
 * the performance impact of buffering and system call patterns.
 */
public interface WriteEngine {

    /**
     * @return Human-readable name of this engine (e.g., "A (Unbuffered + fsync)")
     */
    String name();

    /**
     * Write data sequentially from offset 0 to the end of the file.
     *
     * @param filePath   target file path
     * @param data       the complete data payload to write
     * @throws IOException if any I/O error occurs
     */
    void writeSequential(Path filePath, byte[] data) throws IOException;

    /**
     * Write data in random-offset chunks to simulate random access patterns.
     * The engine writes the full payload but in a shuffled order of chunks.
     *
     * @param filePath   target file path
     * @param data       the complete data payload to write
     * @param chunkSize  size of each random-positioned write (e.g., 512 bytes)
     * @param offsets    pre-shuffled array of offsets to write to
     * @throws IOException if any I/O error occurs
     */
    void writeRandom(Path filePath, byte[] data, int chunkSize, int[] offsets) throws IOException;
}