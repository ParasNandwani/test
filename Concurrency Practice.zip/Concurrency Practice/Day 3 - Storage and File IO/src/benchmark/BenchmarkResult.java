package benchmark;

/**
 * Immutable data class capturing the results of a single benchmark run.
 *
 * Stores the raw timing data and computes derived metrics like throughput.
 */
public final class BenchmarkResult {

    private final String engineName;
    private final AccessPattern pattern;
    private final long totalBytes;
    private final long durationNanos;

    public BenchmarkResult(String engineName, AccessPattern pattern, long totalBytes, long durationNanos) {
        this.engineName = engineName;
        this.pattern = pattern;
        this.totalBytes = totalBytes;
        this.durationNanos = durationNanos;
    }

    public String engineName() {
        return engineName;
    }

    public AccessPattern pattern() {
        return pattern;
    }

    public long totalBytes() {
        return totalBytes;
    }

    public long durationNanos() {
        return durationNanos;
    }

    /**
     * Computes throughput in megabytes per second.
     * MB/s = (totalBytes / 1_000_000) / (durationNanos / 1_000_000_000)
     *       = totalBytes * 1000 / durationNanos
     */
    public double throughputMBps() {
        if (durationNanos == 0) return 0.0;
        return (totalBytes / 1_000_000.0) / (durationNanos / 1_000_000_000.0);
    }

    /**
     * Duration in milliseconds for display purposes.
     */
    public double durationMs() {
        return durationNanos / 1_000_000.0;
    }

    @Override
    public String toString() {
        return String.format("%-28s | %-10s | %8.1f MB/s | %,.0f ms",
                engineName, pattern.displayName(), throughputMBps(), durationMs());
    }
}