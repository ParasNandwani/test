package benchmark;

/**
 * Defines the two fundamental disk access patterns being evaluated.
 *
 * SEQUENTIAL: Writes proceed linearly from offset 0 → end of file.
 *   - Maximizes Page Cache prefetch effectiveness
 *   - Aligns with disk read-ahead algorithms
 *   - Minimizes HDD seek time (head stays in position)
 *   - Minimizes SSD write amplification (fills flash pages sequentially)
 *
 * RANDOM: Writes jump to arbitrary offsets throughout the file.
 *   - Defeats Page Cache prefetching (every access may be a cache miss)
 *   - Maximizes HDD seek latency (constant head repositioning)
 *   - Increases SSD write amplification (partial flash page writes)
 *   - Still benefits from mmap's zero-copy vs traditional I/O's double-copy
 */
public enum AccessPattern {
    SEQUENTIAL("Sequential"),
    RANDOM("Random");

    private final String displayName;

    AccessPattern(String displayName) {
        this.displayName = displayName;
    }

    public String displayName() {
        return displayName;
    }
}