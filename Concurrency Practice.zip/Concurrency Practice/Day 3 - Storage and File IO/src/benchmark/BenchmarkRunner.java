package benchmark;

import engine.WriteEngine;
import util.DataGenerator;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * Orchestrates benchmark execution across all engines and access patterns.
 *
 * Responsibilities:
 * 1. Generate test data payload
 * 2. Create/clean temporary files for each run
 * 3. Warm up the JVM (first run is discarded to account for JIT compilation)
 * 4. Execute multiple iterations and report median throughput
 * 5. Format and display results in a comparison table
 */
public class BenchmarkRunner {

    private final int fileSizeMB;
    private final int iterations;
    private final int randomChunkSize;
    private final List<WriteEngine> engines;
    private final List<AccessPattern> patterns;

    public BenchmarkRunner(int fileSizeMB, int iterations, List<WriteEngine> engines, List<AccessPattern> patterns) {
        this.fileSizeMB = fileSizeMB;
        this.iterations = iterations;
        this.randomChunkSize = 512; // 512-byte chunks for random access
        this.engines = engines;
        this.patterns = patterns;
    }

    /**
     * Execute all benchmarks and return results.
     */
    public List<BenchmarkResult> runAll() throws IOException {
        int fileSize = fileSizeMB * 1024 * 1024;
        byte[] data = DataGenerator.generate(fileSize);
        int[] randomOffsets = DataGenerator.generateRandomOffsets(fileSize, randomChunkSize);

        List<BenchmarkResult> results = new ArrayList<>();
        Path tempDir = Files.createTempDirectory("io-bench-");

        System.out.println("\n  Warming up JVM (1 iteration discarded per engine)...\n");

        for (WriteEngine engine : engines) {
            for (AccessPattern pattern : patterns) {
                // Warm-up run: let JIT compile hot paths
                Path warmupFile = tempDir.resolve("warmup_" + engine.name().charAt(0) + "_" + pattern.name());
                runSingle(engine, pattern, warmupFile, data, randomOffsets);
                Files.deleteIfExists(warmupFile);

                // Measured runs
                long bestNanos = Long.MAX_VALUE;
                for (int i = 0; i < iterations; i++) {
                    Path benchFile = tempDir.resolve("bench_" + engine.name().charAt(0) + "_" + pattern.name() + "_" + i);
                    long nanos = runSingle(engine, pattern, benchFile, data, randomOffsets);
                    bestNanos = Math.min(bestNanos, nanos);
                    Files.deleteIfExists(benchFile);
                }

                results.add(new BenchmarkResult(engine.name(), pattern, fileSize, bestNanos));
            }
        }

        // Clean up temp directory
        Files.deleteIfExists(tempDir);

        return results;
    }

    /**
     * Execute a single benchmark run and return elapsed time in nanoseconds.
     */
    private long runSingle(WriteEngine engine, AccessPattern pattern, Path filePath,
                           byte[] data, int[] randomOffsets) throws IOException {
        long startNanos = System.nanoTime();

        switch (pattern) {
            case SEQUENTIAL:
                engine.writeSequential(filePath, data);
                break;
            case RANDOM:
                engine.writeRandom(filePath, data, randomChunkSize, randomOffsets);
                break;
        }

        long endNanos = System.nanoTime();
        return endNanos - startNanos;
    }

    /**
     * Print formatted results table to stdout.
     */
    public static void printResults(List<BenchmarkResult> results, int fileSizeMB) {
        System.out.println();
        System.out.println("══════════════════════════════════════════════════════════════════════════");
        System.out.println("  I/O PERFORMANCE EVALUATION ENGINE — Benchmark Results");
        System.out.println("══════════════════════════════════════════════════════════════════════════");
        System.out.printf("  File Size: %d MB | OS: %s | Arch: %s%n",
                fileSizeMB,
                System.getProperty("os.name"),
                System.getProperty("os.arch"));
        System.out.println("──────────────────────────────────────────────────────────────────────────");
        System.out.printf("  %-28s │ %17s │ %13s%n", "Engine", "Sequential (MB/s)", "Random (MB/s)");
        System.out.println("  ────────────────────────────┼───────────────────┼───────────────");

        // Group results by engine
        List<String> printedEngines = new ArrayList<>();
        for (BenchmarkResult r : results) {
            if (!printedEngines.contains(r.engineName())) {
                printedEngines.add(r.engineName());
            }
        }

        for (String engineName : printedEngines) {
            double seqThroughput = 0;
            double randThroughput = 0;
            for (BenchmarkResult r : results) {
                if (r.engineName().equals(engineName)) {
                    if (r.pattern() == AccessPattern.SEQUENTIAL) {
                        seqThroughput = r.throughputMBps();
                    } else {
                        randThroughput = r.throughputMBps();
                    }
                }
            }
            System.out.printf("  %-28s │ %13.1f     │ %9.1f%n",
                    engineName, seqThroughput, randThroughput);
        }

        System.out.println("══════════════════════════════════════════════════════════════════════════");
        System.out.println();
    }
}