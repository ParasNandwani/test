# Day 3: Storage and File I/O

A modular Java framework that demonstrates the performance characteristics of different file access and buffering strategies at the operating system level.

---

## The Interview Question

> *"You need to write 64MB of data to disk. Compare unbuffered I/O with fsync, buffered I/O, and memory-mapped files. What are the throughput differences and why? When would you choose each?"*

**What the interviewer is testing:**
- Do you understand user space vs kernel space and syscall overhead?
- Can you explain the OS page cache and its role in write performance?
- Do you know what fsync does at the hardware level and its cost?
- Can you articulate sequential vs random I/O performance characteristics?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: OS Kernel & Storage Fundamentals](#part-1-os-kernel--storage-fundamentals)
2. [Part 2: Architecture Overview](#part-2-architecture-overview)
3. [Part 3: Expected Output](#part-3-expected-output)
4. [Part 4: Interview Discussion Points](#part-4-interview-discussion-points)
5. [How to Run](#how-to-run)
6. [Directory Structure](#directory-structure)

---

## Part 1: OS Kernel & Storage Fundamentals

Before diving into the architecture and code, you **must** understand the following foundational concepts. Every design decision in this engine traces back to one of these principles.

---

### 1. User Space vs. Kernel Space

**What it is:**  
Modern operating systems divide memory into two zones:
- **User Space** — where your Java application (JVM) lives. It can only access its own memory.
- **Kernel Space** — where the OS core lives. It has unrestricted access to hardware: disks, network cards, RAM controllers.

**Physical Analogy — The Airport Security Checkpoint:**  
Imagine your application is a passenger in an airport terminal (User Space). The airplane cockpit (disk hardware) is behind a security checkpoint (the kernel boundary). Every time you want to store luggage in the cargo hold (write to disk), you must:
1. Walk to the checkpoint (initiate a **system call**)
2. Show your passport, get scanned (the CPU switches from "user mode" to "kernel mode" — a **context switch**)
3. Hand your luggage to an authorized handler (kernel copies data from user buffers to kernel buffers)
4. Walk back to the terminal (CPU switches back to user mode)

**Why it matters:**  
Each crossing costs ~1–10 microseconds of CPU time. If Engine A writes 1 byte at a time to a 64MB file, that's **67 million boundary crossings**. Engine B batches 8,192 bytes per crossing — reducing crossings to ~8,000. That's a **8,000x reduction in overhead**.

---

### 2. Operating System Page Cache

**What it is:**  
The OS maintains an **invisible RAM buffer** (the Page Cache) between your application and the physical disk. When you call `write()`, data doesn't go directly to the disk platters. Instead:
1. Data lands in the Page Cache (RAM).
2. The OS **lazily** flushes dirty pages to disk in the background (typically every 5–30 seconds).
3. Subsequent `read()` calls for the same data are served from RAM — no disk I/O needed.

**Physical Analogy — The Librarian's Desk:**  
Think of the disk as a massive warehouse of books. The Page Cache is the librarian's desk at the front. When you ask for a book:
- First time: the librarian walks to the warehouse, retrieves it, places a copy on their desk, and hands it to you.
- Second time: the book is already on the desk. Instant access.
- When you return a modified book, the librarian keeps it on the desk and files it back in the warehouse "when they get around to it."

**Why it matters:**  
- Without `fsync`, your "written" data may only exist in volatile RAM. A power failure loses it.
- The Page Cache makes sequential reads blazing fast (prefetching) but doesn't help random reads as much (cache misses).
- Engine B benefits enormously because large sequential writes align with the OS's prefetch and writeback strategies.

---

### 3. The `fsync` System Call

**What it is:**  
`fsync(fd)` is a system call that tells the kernel: *"Flush ALL dirty pages for this file descriptor from the Page Cache to the physical storage medium. Do NOT return until the drive's hardware confirms the bits are on stable storage."*

**Physical Analogy — The Bank Vault Receipt:**  
Imagine depositing cash:
- A normal `write()` is like handing cash to the teller. They put it in a tray on their desk (Page Cache). Fast, but if the building burns down, your money is gone.
- An `fsync()` is like demanding: *"Walk to the vault, deposit it, lock the vault, and bring me back a signed receipt."* You wait at the counter until they return.

**The hardware cost:**
- HDD: The disk must physically rotate platters and position the write head. An `fsync` costs ~5–15ms (mechanical latency).
- SSD: The controller must flush its volatile write buffer to NAND cells. An `fsync` costs ~0.1–2ms.
- NVMe: ~0.02–0.1ms, but still orders of magnitude slower than RAM writes (~100ns).

**Why it matters:**  
Engine A calls `fsync` after every small write. If writing 64MB in 512-byte chunks with `fsync` after each:
- That's 131,072 fsync calls × ~1ms each = **~131 seconds** on an SSD.
- Engine B calls `fsync` once at the end: ~1ms total fsync cost.
- This is the single biggest performance differentiator in the benchmark.

---

### 4. Zero-Copy I/O & Memory-Mapping (mmap)

**What it is:**  
Traditional file I/O involves multiple copies of data:
```
[Your byte array in JVM Heap]  →copy→  [Kernel buffer]  →copy→  [Disk controller DMA buffer]
```
That's 2 copies minimum per write. **Memory-mapping** (`mmap`) eliminates the first copy by mapping the file's kernel page cache pages directly into your process's virtual address space:
```
[Your MappedByteBuffer]  ══is══  [Kernel Page Cache page]  →DMA→  [Disk]
```
When you write to a `MappedByteBuffer`, you're writing directly into the Page Cache. No system call needed for the write itself — it's just a memory store instruction.

**Physical Analogy — The Shared Window:**  
- Traditional I/O: You write a letter (your buffer), slide it through a mail slot (system call) to the post office (kernel), who copies it onto their own paper and files it.
- mmap: The post office installs a glass window between you. You reach through and write directly on their filing paper. No copying, no mail slot, no waiting.

**Why it matters:**  
- Eliminates user→kernel data copying overhead
- No system call overhead for individual reads/writes (the MMU handles page faults transparently)
- The OS can prefetch, writeback, and evict pages using its own sophisticated algorithms
- Engine C exploits this for maximum throughput, especially for large sequential writes

**Caveats:**
- File must be pre-allocated to a known size (you map a fixed region)
- Uncontrolled page faults for random access can stall the thread
- `MappedByteBuffer` is not explicitly unmappable in Java (GC-dependent cleanup)

---

### 5. Sequential vs. Random Disk Access Patterns

**What it is:**  
- **Sequential access**: Reading/writing contiguous bytes in order (offset 0, then 1, then 2, ...).
- **Random access**: Reading/writing at arbitrary offsets (offset 50000, then 12, then 999999, ...).

**Physical Analogy — The Vinyl Record Needle:**

*For HDDs (spinning rust):*
- Sequential = the needle sits in the groove and the record spins underneath. Data flows continuously. Throughput: 100–200 MB/s.
- Random = after every note, you lift the needle, move it to a random groove, wait for the platter to rotate to the right spot (**seek time**: ~5–10ms). Effective throughput drops to ~1–5 MB/s.

*For SSDs (NAND flash):*
- No moving parts, so random reads are ~0.1ms vs. sequential's streaming.
- But SSDs still prefer sequential writes because of **write amplification**: random writes force the SSD controller to read-modify-write entire 4KB–256KB flash pages and trigger garbage collection.
- Sequential write throughput: 500–3000 MB/s. Random write throughput: 50–500 MB/s (depending on queue depth).

**Why it matters in our benchmark:**
- Engine A with random access + fsync = worst possible scenario (every write is a seek + flush)
- Engine B with sequential access = optimal for the Page Cache prefetcher
- Engine C with sequential access = the OS can prefetch mapped pages ahead of your reads
- Engine C with random access = page faults on each access, but no system call overhead, so still faster than Engine A

---

## Part 2: Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                        Main.java                            │
│              (Entry point, CLI configuration)               │
└─────────────────────────┬───────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────┐
│                   BenchmarkRunner.java                      │
│   (Orchestrates engines, patterns, iterations, reporting)   │
└───────┬─────────────────┬─────────────────┬─────────────────┘
        │                 │                 │
        ▼                 ▼                 ▼
┌───────────────────┐ ┌─────────────────┐ ┌───────────────────┐
│ Engine A          │ │ Engine B        │ │ Engine C          │
│ (Unbuffered)      │ │ (Buffered)      │ │ (Memory-Mapped)   │
│                   │ │                 │ │                   │
│ FileOutputStream  │ │ BufferedOutput  │ │ FileChannel +     │
│ + fsync/byte      │ │ Stream (8KB)    │ │ MappedByteBuffer  │
└───────────────────┘ └─────────────────┘ └───────────────────┘
        │                 │                 │
        ▼                 ▼                 ▼
┌─────────────────────────────────────────────────────────────┐
│              Operating System Kernel                        │
│    ┌──────────────────────────────────────────────────┐     │
│    │              Page Cache (RAM)                    │     │
│    └──────────────────────┬───────────────────────────┘     │
│                           │ writeback / fsync               │
│                           ▼                                 │
│    ┌──────────────────────────────────────────────────┐     │
│    │          Block Device Driver → Disk              │     │
│    └──────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

### How Each Engine Maps to the Fundamentals

| Engine | System Calls per 64MB | Data Copies | Page Cache Behavior | fsync Cost |
|--------|----------------------|-------------|--------------------:|------------|
| A (Unbuffered) | ~131K write + ~131K fsync | 2 per write (user→kernel→disk) | Bypassed by frequent fsync | Catastrophic (~131s) |
| B (Buffered 8KB) | ~8K write + 1 fsync | 2 per write but batched | Fully utilized, prefetch-friendly | Minimal (~1ms) |
| C (mmap) | 0 explicit writes (page faults) | 1 (direct to Page Cache) | IS the Page Cache | On-demand via `force()` |

---

## How to Run

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day3:run
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on `Main.java` directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out Main
```

---

## Part 3: Expected Output

```
══════════════════════════════════════════════════════════════════
  I/O PERFORMANCE EVALUATION ENGINE — Benchmark Results
══════════════════════════════════════════════════════════════════
  File Size: 64 MB | Iterations: 3 | OS: macOS | Disk: APFS/SSD
──────────────────────────────────────────────────────────────────
  Engine                       │ Sequential (MB/s) │ Random (MB/s)
  ─────────────────────────────┼───────────────────┼──────────────
  A (Unbuffered + fsync)       │           2.3     │         0.8
  B (Buffered 8KB)             │         312.5     │        45.2
  C (Memory-Mapped)            │         891.0     │       210.4
══════════════════════════════════════════════════════════════════
```

---

## Part 4: Interview Discussion Points

1. **Why is Engine A so slow?** — Each byte triggers a user→kernel context switch AND an fsync forces a hardware flush. The disk can only confirm ~1000 fsyncs/second on SSD.

2. **Why does Engine B outperform A by 100x+?** — Batching amortizes the system call cost AND lets the Page Cache coalesce writes into large sequential disk I/O operations.

3. **Why is Engine C fastest?** — Zero-copy: writes go directly into Page Cache pages. No system calls for data transfer. The OS handles writeback asynchronously.

4. **When would you NOT use mmap?** — When file size is unknown/growing, when you need strict durability guarantees per-write, or when the working set exceeds physical RAM (thrashing).

5. **What happens on power failure for each engine?**
   - A: All data is durable (fsync after every write)
   - B: Up to 8KB of recent writes may be lost (in the application buffer)
   - C: Up to 30 seconds of writes may be lost (kernel writeback timer)

---

## Directory Structure

```
src/
├── Main.java                           # Entry point — configures and runs benchmarks
├── benchmark/
│   ├── AccessPattern.java              # Enum: SEQUENTIAL vs RANDOM
│   ├── BenchmarkResult.java            # Immutable result container
│   └── BenchmarkRunner.java            # Orchestrates engines, patterns, iterations
├── engine/
│   ├── WriteEngine.java                # Interface (contract for all engines)
│   ├── UnbufferedEngine.java           # Engine A: FileOutputStream + fsync/byte
│   ├── BufferedSequentialEngine.java   # Engine B: BufferedOutputStream (8KB)
│   └── MemoryMappedEngine.java         # Engine C: FileChannel + MappedByteBuffer
└── util/
    └── DataGenerator.java              # Generates random byte payloads
```

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
