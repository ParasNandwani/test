package question3_metric_aggregator;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * ╔═════════════════════════════════════════════════════════════════════════════╗
 * ║  QUESTION 3: Time-Series Sliding Window Metric Aggregator                   ║
 * ╠═════════════════════════════════════════════════════════════════════════════╣
 * ║                                                                             ║
 * ║  Design a MetricAggregator that:                                            ║
 * ║                                                                             ║
 * ║  1. Many threads (up to 32) call record(metricName, value) at ~1M/sec.      ║
 * ║     This is the HOT PATH — must be as fast as possible.                     ║
 * ║  2. Maintains SLIDING TIME WINDOWS (1-second buckets). Each bucket          ║
 * ║     accumulates: count, sum, min, max.                                      ║
 * ║  3. A SINGLE BACKGROUND REPORTER wakes every 1 second, "closes" the         ║
 * ║     oldest bucket, computes stats, emits them, and recycles the bucket.     ║
 * ║  4. Supports MULTIPLE NAMED METRICS (e.g., "api.latency", "db.queries").    ║
 * ║  5. ZERO OBJECT ALLOCATION on the hot path (record() must not new).         ║
 * ║                                                                             ║
 * ║  Constraints (clarify these with interviewer!):                             ║
 * ║  - ~50 metric names, known at registration time (not dynamic)               ║
 * ║  - 5 buckets of 1 second each (5-second sliding window)                     ║
 * ║  - Hot path target: record() < 100ns average                                ║
 * ║  - 32 producers, 1 reporter                                                 ║
 * ║  - Values are long (no floating point)                                      ║
 * ║  - Reporter needs consistent snapshot (no torn reads)                       ║
 * ║                                                                             ║
 * ╚═════════════════════════════════════════════════════════════════════════════╝
 *
 * TIME YOURSELF: 35 minutes. Start now.
 */
public class YourSolution {

    // --- Snapshot record (provided) ---
    public record BucketSnapshot(String metricName, long count, long sum, long min, long max, long bucketStartMs) {}

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // YOUR IMPLEMENTATION BELOW
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    // TODO: Define your Stripe class
    //   - AtomicLong count, sum, min, max
    //   - CAS loop for min/max updates
    //   - Padding to avoid false sharing


    // TODO: Define your Bucket class
    //   - Array of Stripe objects
    //   - snapshotAndReset() method


    // TODO: Define your MetricWindow class
    //   - Circular buffer of Bucket objects
    //   - Maps a metric name to its pre-allocated window


    // TODO: Fields — what do you need?
    //   - metricName → index mapping (immutable after construction)
    //   - Array of MetricWindow objects
    //   - Bucket duration in nanos
    //   - Start time reference (for bucket ID calculation)
    //   - Reporter thread
    //   - Shutdown flag


    // TODO: Constructor
    public YourSolution(List<String> metricNames, int windowBuckets, long bucketDurationMs) {
        // TODO:
        // 1. Build metric name → index map
        // 2. Pre-allocate all MetricWindow + Bucket + Stripe objects
        // 3. Start reporter thread
    }

    // TODO: HOT PATH — record a value (ZERO allocation, NO locks)
    public void record(String metricName, long value) {
        // TODO:
        // 1. Map metricName → index (HashMap.get — allocation-free)
        // 2. Determine current bucket index (nanoTime-based circular)
        // 3. Determine stripe index (threadId & mask)
        // 4. Record: atomic increment count, atomic add sum, CAS min, CAS max
    }

    // TODO: Reporter — report completed buckets
    public List<BucketSnapshot> reportAndAdvance() {
        // TODO:
        // 1. Calculate which buckets have completed since last report
        // 2. For each completed bucket: aggregate all stripes, reset, return snapshot
        return List.of();
    }

    // TODO: Shutdown
    public void shutdown() {
        // TODO: Set running=false, interrupt reporter, join
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // TEST HARNESS (run to verify your solution)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    public static void main(String[] args) throws Exception {
        System.out.println("=== Test 1: Throughput — 32 threads, 3 seconds ===");

        List<String> metricNames = List.of("api.latency", "db.queries", "cache.hits");
        YourSolution aggregator = new YourSolution(metricNames, 5, 1000);

        java.util.concurrent.atomic.LongAdder totalRecorded = new java.util.concurrent.atomic.LongAdder();
        Thread[] producers = new Thread[32];
        long testDurationNanos = 3_000_000_000L;

        for (int t = 0; t < producers.length; t++) {
            producers[t] = new Thread(() -> {
                java.util.concurrent.ThreadLocalRandom rng = java.util.concurrent.ThreadLocalRandom.current();
                long start = System.nanoTime();
                int count = 0;

                while (System.nanoTime() - start < testDurationNanos) {
                    aggregator.record("api.latency", rng.nextLong(1, 500));
                    aggregator.record("db.queries", rng.nextLong(10, 100));
                    aggregator.record("cache.hits", 1);
                    count += 3;
                }

                totalRecorded.add(count);
            }, "Producer-" + t);
            producers[t].start();
        }

        for (Thread p : producers) {
            p.join();
        }

        long recorded = totalRecorded.sum();
        double throughput = recorded / (testDurationNanos / 1_000_000_000.0);
        System.out.printf("Total recorded: %,d values in 3 seconds%n", recorded);
        System.out.printf("Throughput: %,.0f ops/sec%n", throughput);

        assert throughput > 1_000_000
                : "FAIL: Expected >1M ops/sec, got " + (long) throughput;
        System.out.println("✓ Throughput exceeds 1M ops/sec");

        // --- Test 2: Correctness with known values ---
        System.out.println("\n=== Test 2: Value correctness ===");
        Thread.sleep(1500);  // Let bucket complete

        YourSolution testAgg = new YourSolution(List.of("test.metric"), 5, 1000);
        testAgg.record("test.metric", 10);
        testAgg.record("test.metric", 20);
        testAgg.record("test.metric", 30);
        testAgg.record("test.metric", 5);
        testAgg.record("test.metric", 50);

        Thread.sleep(1500);
        List<BucketSnapshot> snapshots = testAgg.reportAndAdvance();

        BucketSnapshot snap = null;
        for (BucketSnapshot s : snapshots) {
            if ("test.metric".equals(s.metricName()) && s.count() > 0) {
                snap = s;
                break;
            }
        }

        assert snap != null : "FAIL: No snapshot for test.metric";
        assert snap.count() == 5 : "FAIL: count=" + snap.count();
        assert snap.sum() == 115 : "FAIL: sum=" + snap.sum();
        assert snap.min() == 5 : "FAIL: min=" + snap.min();
        assert snap.max() == 50 : "FAIL: max=" + snap.max();
        System.out.println("✓ Correctness: count=5 sum=115 min=5 max=50");

        aggregator.shutdown();
        testAgg.shutdown();
        System.out.println("\n=== PASSED ===");
    }
}