# Question 3: Time-Series Sliding Window Metric Aggregator

## Problem Statement

Design a Metric Aggregator that:

1. **Many threads** (up to 32) call `record(metricName, value)` at very high frequency (~1M calls/sec total). This is the HOT PATH — it must be as fast as possible.
2. Internally, the system maintains **sliding time windows** (e.g., 1-second buckets). Each bucket accumulates: count, sum, min, max for that second.
3. A **single background reporter thread** wakes up every 1 second, "closes" the oldest bucket, computes the aggregated stats, emits them (e.g., prints or sends to a sink), and recycles the bucket.
4. The system must support **multiple named metrics** (e.g., "api.latency", "db.queries", "cache.hits").
5. **Zero object allocation** on the hot path (the `record()` method must not create any objects).

---

## Assumptions

> ⚠️ **Interview Tip**: These assumptions may or may not be given to you upfront. It is YOUR responsibility to ask clarifying questions and establish these constraints with the interviewer before you start coding. Demonstrating this structured clarification is one of the strongest signals in a systems interview.

- Metric names: ~50 distinct names, known at registration time (not dynamic).
- Window: 5 buckets of 1 second each (total 5-second sliding window).
- Reporting: every 1 second, the oldest completed bucket is reported and recycled.
- Hot path target: `record()` must complete in < 100ns average.
- Threads: 32 producers, 1 reporter.
- Values are `long` (nanoseconds, counts, etc.) — no floating point needed.
- The reporter needs a consistent snapshot of a bucket (no torn reads of count/sum/min/max).

---

## Interface

```java
public class MetricAggregator {
    MetricAggregator(List<String> metricNames, int windowBuckets, long bucketDurationMs);
    
    // HOT PATH — called millions of times per second by many threads
    void record(String metricName, long value);
    
    // Called by reporter thread every bucketDurationMs
    BucketSnapshot reportAndAdvance();
    
    void shutdown();
}

public record BucketSnapshot(String metricName, long count, long sum, long min, long max, long bucketStartMs) {}
```

---

## What You Must Address

1. How do you achieve sub-100ns `record()` with 32 threads? (Hint: per-thread or per-stripe accumulation to avoid contention.)
2. How do you map `metricName` to its bucket without HashMap lookup on the hot path? (Pre-registration → index lookup.)
3. How does the reporter "close" a bucket atomically? (The bucket is being written by 32 threads — how do you get a consistent snapshot?)
4. How do you recycle buckets without GC allocation? (Circular buffer of pre-allocated bucket objects.)
5. What clock do you use for bucket boundaries? (nanoTime vs currentTimeMillis — and why.)
6. What happens if the reporter is slow and doesn't advance in time? (Bucket overflow / data loss policy.)

---

## Follow-Up Deep-Dives (Interviewer would ask)

- "If you use striped accumulators per bucket, how do you sum them for the report without blocking writers?"
- "What's the memory layout? Could false sharing between adjacent buckets' counters be a problem?"
- "How would you add percentile tracking (p50, p99) without allocation on the hot path?" (Hint: HDR Histogram / fixed-size frequency array.)
- "If a metric is registered dynamically at runtime, how does that change the design?"

---

## Hints (Progressive — Try Before Reading)

### Hint 1: Eliminating HashMap on Hot Path
<details>
<summary>Click to reveal</summary>

At registration time, assign each metric name an integer index (0, 1, 2, ...). Store this mapping in a `HashMap<String, Integer>` that is built ONCE at construction and never modified. On the hot path, `record()` converts the name to its index — this is a single HashMap.get() which is O(1) and allocation-free.

Even better: if callers can be given a `MetricHandle` (an int or object wrapping the index) at registration time, the hot path avoids even the HashMap lookup.

</details>

### Hint 2: Per-Stripe Accumulation
<details>
<summary>Click to reveal</summary>

For each metric, for each bucket, maintain an array of `Stripe` objects (e.g., 8 stripes). Each recording thread picks a stripe via `Thread.currentThread().getId() % NUM_STRIPES` and updates ONLY that stripe. This eliminates cross-thread contention on the hot path.

Each stripe holds: `long count, sum, min, max` — updated with simple volatile writes or atomic operations.

</details>

### Hint 3: Circular Buffer for Buckets
<details>
<summary>Click to reveal</summary>

Pre-allocate `windowBuckets` bucket objects in a circular array. Use a `writeIndex` (which bucket is currently active) that advances every `bucketDurationMs`. The reporter reads from `(writeIndex + 1) % windowBuckets` — the oldest completed bucket.

`writeIndex` is determined by: `(System.nanoTime() / bucketDurationNanos) % windowBuckets`.

This means NO object is ever created during recording — you just index into the pre-allocated array.

</details>

### Hint 4: Consistent Snapshot Without Blocking Writers
<details>
<summary>Click to reveal</summary>

The key insight: once the reporter "advances" the window, the old bucket is no longer being written to (writers have moved to the next bucket based on the current time). So the reporter can safely read and reset it.

If there's a small race window (a writer determined the bucket index but hasn't written yet when the reporter reads), you can tolerate this as "best effort" — or use a small delay (e.g., report the bucket from 2 seconds ago instead of 1).

Alternatively: each stripe uses `AtomicLong` for count/sum and the reporter sums all stripes. The individual atomic reads are consistent per-stripe.

</details>

### Hint 5: Clock Choice
<details>
<summary>Click to reveal</summary>

Use `System.nanoTime()` for bucket boundary calculations. It's monotonic (never jumps backwards due to NTP), has nanosecond precision, and is cheap (~25ns per call).

Do NOT use `System.currentTimeMillis()` — it can jump backwards on NTP sync, which would cause bucket misassignment.

For the `bucketStartMs` in the snapshot (human-readable reporting), convert using `currentTimeMillis` only at report time (not on the hot path).

</details>

### Hint 6: Handling Min/Max Atomically
<details>
<summary>Click to reveal</summary>

Use CAS loops for min and max:

```java
void updateMin(AtomicLong minHolder, long value) {
    long current;
    do {
        current = minHolder.get();
        if (value >= current) return;  // Not a new minimum
    } while (!minHolder.compareAndSet(current, value));
}
```

This is lock-free, allocation-free, and correct under concurrency. Initialize min to `Long.MAX_VALUE` and max to `Long.MIN_VALUE` when recycling a bucket.

</details>

### Hint 7: Memory Layout and False Sharing
<details>
<summary>Click to reveal</summary>

Each stripe should be padded to its own cache line (128 bytes on Apple Silicon, 64 bytes on x86). If stripes are adjacent in memory without padding, two threads writing to adjacent stripes will cause cache-line bouncing.

Layout: `[64B padding] [count|sum|min|max = 32B] [64B padding]` per stripe.

Alternatively, use `@Contended` annotation (JDK internal) or manual long padding fields.

</details>