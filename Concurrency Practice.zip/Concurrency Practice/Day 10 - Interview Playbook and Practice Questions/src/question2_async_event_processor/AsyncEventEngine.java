package question2_async_event_processor;

import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;

/**
 * Bounded Async Event Processor with Dead Letter Queue
 *
 * Key Design Decisions:
 * - ArrayBlockingQueue for bounded main queue (built-in blocking for backpressure)
 * - DelayQueue for retry scheduling (exponential backoff without a timer thread)
 * - Dedicated retry dispatcher thread feeds retries back to main queue
 * - LongAdder for contention-free metrics
 * - Graceful shutdown: drain main queue → drain retries → join all threads
 *
 * Primitives Used:
 * - ArrayBlockingQueue.put() for BLOCK backpressure
 * - DelayQueue + Delayed interface for timed retry scheduling
 * - volatile boolean for shutdown gate
 * - LongAdder for lock-free metrics counters
 */
public class AsyncEventEngine {

    // --- Event record ---
    public record Event(String id, String payload, int attemptCount) {
        public Event withIncrementedAttempt() {
            return new Event(id, payload, attemptCount + 1);
        }
    }

    // --- Backpressure policy ---
    public enum BackpressurePolicy { BLOCK, REJECT }

    // --- Custom exceptions ---
    public static class RejectedEventException extends Exception {
        public RejectedEventException(String message) { super(message); }
    }

    // --- Processor contract ---
    public interface EventProcessor {
        boolean process(Event event) throws Exception;
    }

    // --- Delayed wrapper for retry scheduling ---
    private static class DelayedEvent implements Delayed {
        final Event event;
        final long executeAtNanos;

        DelayedEvent(Event event, long delayMs) {
            this.event = event;
            this.executeAtNanos = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(delayMs);
        }

        @Override
        public long getDelay(TimeUnit unit) {
            return unit.convert(executeAtNanos - System.nanoTime(), TimeUnit.NANOSECONDS);
        }

        @Override
        public int compareTo(Delayed other) {
            return Long.compare(this.executeAtNanos, ((DelayedEvent) other).executeAtNanos);
        }
    }

    // --- Configuration ---
    private static final int MAX_RETRIES = 3;
    private static final long[] RETRY_DELAYS_MS = {1000, 2000, 4000};  // exponential backoff

    // --- State ---
    private final EventProcessor processor;
    private final BackpressurePolicy policy;
    private final ArrayBlockingQueue<Event> mainQueue;
    private final DelayQueue<DelayedEvent> retryQueue = new DelayQueue<>();
    private final Thread[] workers;
    private final Thread retryDispatcher;
    private volatile boolean running = true;

    // --- Metrics (lock-free) ---
    private final LongAdder totalProcessed = new LongAdder();
    private final LongAdder totalFailed = new LongAdder();
    private final LongAdder totalDropped = new LongAdder();

    // --- Constructor ---
    public AsyncEventEngine(EventProcessor processor, int queueCapacity, int workerCount, BackpressurePolicy policy) {
        this.processor = processor;
        this.policy = policy;
        this.mainQueue = new ArrayBlockingQueue<>(queueCapacity);

        // Start worker threads
        this.workers = new Thread[workerCount];
        for (int i = 0; i < workerCount; i++) {
            workers[i] = new Thread(this::workerLoop, "EventWorker-" + i);
            workers[i].start();
        }

        // Start retry dispatcher thread
        this.retryDispatcher = new Thread(this::retryDispatcherLoop, "RetryDispatcher");
        this.retryDispatcher.start();
    }

    // --- Submit: called by producers ---
    public void submit(Event event) throws InterruptedException, RejectedEventException {
        if (!running) {
            throw new RejectedEventException("Engine is shut down — not accepting new events");
        }

        switch (policy) {
            case BLOCK -> mainQueue.put(event);       // Blocks when full — built-in backpressure
            case REJECT -> {
                if (!mainQueue.offer(event)) {
                    throw new RejectedEventException("Queue full — event rejected: " + event.id());
                }
            }
        }
    }

    // --- Worker loop: pull from main queue, process, handle failure ---
    private void workerLoop() {
        while (running || !mainQueue.isEmpty()) {
            try {
                // Poll with timeout so we can check running flag periodically
                Event event = mainQueue.poll(100, TimeUnit.MILLISECONDS);
                if (event == null) continue;

                try {
                    boolean success = processor.process(event);
                    if (success) {
                        totalProcessed.increment();
                    } else {
                        handleFailure(event);
                    }
                } catch (Exception e) {
                    handleFailure(event);
                }

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                // On interrupt, drain remaining items before exiting
                drainMainQueue();
                return;
            }
        }
        // Final drain after running=false
        drainMainQueue();
    }

    // --- Handle failed event: retry or drop ---
    private void handleFailure(Event event) {
        int attempt = event.attemptCount();
        if (attempt < MAX_RETRIES) {
            // Schedule retry with exponential backoff
            long delay = RETRY_DELAYS_MS[attempt];
            Event retryEvent = event.withIncrementedAttempt();
            retryQueue.offer(new DelayedEvent(retryEvent, delay));
            totalFailed.increment();
        } else {
            // Max retries exhausted — permanently drop
            totalDropped.increment();
            System.err.println("[DROPPED] Event permanently failed after " + MAX_RETRIES
                    + " retries: " + event.id());
        }
    }

    // --- Retry dispatcher: takes from DelayQueue, feeds back to main queue ---
    private void retryDispatcherLoop() {
        while (running || !retryQueue.isEmpty()) {
            try {
                // Poll with timeout so we can check running flag
                DelayedEvent delayed = retryQueue.poll(200, TimeUnit.MILLISECONDS);
                if (delayed == null) continue;

                // Try to feed back into main queue (non-blocking to avoid deadlock)
                if (!mainQueue.offer(delayed.event, 500, TimeUnit.MILLISECONDS)) {
                    // Main queue is full — re-enqueue with same delay (don't lose the event)
                    retryQueue.offer(new DelayedEvent(delayed.event, 500));
                }

            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                // Drain remaining retries synchronously
                drainRetryQueue();
                return;
            }
        }
        // Final drain after running=false
        drainRetryQueue();
    }

    // --- Drain helpers for shutdown ---
    private void drainMainQueue() {
        Event event;
        while ((event = mainQueue.poll()) != null) {
            try {
                boolean success = processor.process(event);
                if (success) {
                    totalProcessed.increment();
                } else {
                    handleFailure(event);
                }
            } catch (Exception e) {
                handleFailure(event);
            }
        }
    }

    private void drainRetryQueue() {
        DelayedEvent delayed;
        while ((delayed = retryQueue.poll()) != null) {
            // Process immediately (ignore remaining delay during shutdown)
            try {
                boolean success = processor.process(delayed.event);
                if (success) {
                    totalProcessed.increment();
                } else {
                    if (delayed.event.attemptCount() >= MAX_RETRIES) {
                        totalDropped.increment();
                    } else {
                        // During shutdown, just try once more — don't re-enqueue
                        totalDropped.increment();
                    }
                }
            } catch (Exception e) {
                totalDropped.increment();
            }
        }
    }

    // --- Graceful shutdown ---
    public void shutdown() throws InterruptedException {
        System.out.println("[SHUTDOWN] Initiating graceful shutdown...");

        // Step 1: Close the gate — no new events accepted
        running = false;

        // Step 2: Wait for workers to drain the main queue
        for (Thread worker : workers) {
            worker.join(10_000);  // 10 second timeout per worker
            if (worker.isAlive()) {
                worker.interrupt();
                worker.join(2_000);
            }
        }

        // Step 3: Interrupt and join the retry dispatcher
        retryDispatcher.interrupt();
        retryDispatcher.join(5_000);

        System.out.println("[SHUTDOWN] Complete. Processed=" + getTotalProcessed()
                + " Failed=" + getTotalFailed()
                + " Dropped=" + getTotalDropped());
    }

    // --- Observability ---
    public long getTotalProcessed() { return totalProcessed.sum(); }
    public long getTotalFailed() { return totalFailed.sum(); }
    public long getTotalDropped() { return totalDropped.sum(); }

    // --- Demo / Test with Assertions ---
    public static void main(String[] args) throws Exception {
        System.out.println("=== Test 1: Event processing with retries — 5000 events, ~5% failure rate ===");

        // Simulated processor: 5% failure rate
        EventProcessor flakeyProcessor = event -> {
            Thread.sleep(ThreadLocalRandom.current().nextInt(1, 10));
            return ThreadLocalRandom.current().nextDouble() > 0.05;  // 95% success
        };

        AsyncEventEngine engine = new AsyncEventEngine(flakeyProcessor, 1024, 4, BackpressurePolicy.BLOCK);

        // 8 producer threads submitting events
        ExecutorService producers = Executors.newFixedThreadPool(8);
        int totalEvents = 5000;
        CountDownLatch latch = new CountDownLatch(totalEvents);

        for (int i = 0; i < totalEvents; i++) {
            final int eventId = i;
            producers.submit(() -> {
                try {
                    engine.submit(new Event("evt-" + eventId, "payload-" + eventId, 0));
                } catch (Exception e) {
                    System.err.println("Submit failed: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await();
        System.out.println("All " + totalEvents + " events submitted. Waiting for processing...");

        // Give workers time to process (including retries at 1s + 2s + 4s = 7s max)
        Thread.sleep(8000);

        // Shutdown gracefully
        engine.shutdown();
        producers.shutdown();

        long processed = engine.getTotalProcessed();
        long failed = engine.getTotalFailed();
        long dropped = engine.getTotalDropped();

        System.out.println("\nFinal metrics:");
        System.out.println("  Processed: " + processed);
        System.out.println("  Failed (retried): " + failed);
        System.out.println("  Dropped (permanently): " + dropped);

        // Assertion 1: No silent event loss — every event is accounted for
        // processed + dropped must equal totalEvents (failed are retries, not final outcomes)
        assert processed + dropped == totalEvents
                : "FAIL: processed(" + processed + ") + dropped(" + dropped + ") != totalEvents(" + totalEvents + ")";
        System.out.println("✓ Zero silent loss: processed + dropped == " + totalEvents);

        // Assertion 2: Most events should succeed (~95% success rate, with retries even more)
        assert processed > totalEvents * 0.90
                : "FAIL: Expected >90% processed, got " + processed + "/" + totalEvents;
        System.out.println("✓ High success rate: " + (processed * 100 / totalEvents) + "% processed");

        // Assertion 3: Dropped count should be very small (only events that failed 3+ times)
        assert dropped < totalEvents * 0.05
                : "FAIL: Too many dropped events: " + dropped;
        System.out.println("✓ Low drop rate: " + dropped + " events permanently dropped");

        // --- Test 2: Shutdown rejects new events ---
        System.out.println("\n=== Test 2: Shutdown rejects new events ===");
        try {
            engine.submit(new Event("after-shutdown", "payload", 0));
            assert false : "FAIL: Should have thrown RejectedEventException after shutdown";
        } catch (RejectedEventException e) {
            System.out.println("✓ Shutdown rejection: " + e.getMessage());
        }

        System.out.println("\n=== ALL ASSERTIONS PASSED ===");
    }
}