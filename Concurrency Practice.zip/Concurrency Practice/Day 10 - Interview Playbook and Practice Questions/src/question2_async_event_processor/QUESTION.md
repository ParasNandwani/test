# Question 2: Bounded Async Event Processor with Dead Letter Queue

## Problem Statement

Design an event processing system where:

1. **Multiple producer threads** submit events to the system.
2. A **bounded internal queue** (capacity C) holds pending events. When full, producers must be told (configurable: block or reject).
3. A **worker pool** of W threads pulls events and processes them. Processing may fail.
4. **Failed events** are routed to a **Dead Letter Queue (DLQ)** with exponential backoff retry: retry after 1s, then 2s, then 4s, max 3 retries. After max retries, the event is permanently dropped and logged.
5. **Graceful shutdown**: Stop accepting new events. Drain all in-flight events (including pending retries). Only then exit.

---

## Assumptions

> ⚠️ **Interview Tip**: These assumptions may or may not be given to you upfront. It is YOUR responsibility to ask clarifying questions and establish these constraints with the interviewer before you start coding. Demonstrating this structured clarification is one of the strongest signals in a systems interview.

- Producers: 8 threads, submitting at ~10K events/sec total.
- Worker pool: 4 threads.
- Queue capacity: 1024 events.
- Backpressure policy: BLOCK (producers wait when queue is full).
- Processing time: 1–50ms per event (varies). Failure rate: ~5%.
- Retry schedule: [1s, 2s, 4s] — 3 attempts max.
- DLQ is in-memory (bounded at 256 entries). If DLQ is also full, drop and log.
- Events are `record Event(String id, String payload, int attemptCount)`.

---

## Interface

```java
public interface EventProcessor {
    // Returns true if processed successfully, false on failure
    boolean process(Event event) throws Exception;
}

public class AsyncEventEngine {
    AsyncEventEngine(EventProcessor processor, int queueCapacity, int workerCount, BackpressurePolicy policy);
    
    // Called by producers
    void submit(Event event) throws InterruptedException, RejectedEventException;
    
    // Graceful lifecycle
    void shutdown() throws InterruptedException;
    
    // Observability
    long getTotalProcessed();
    long getTotalFailed();
    long getTotalDropped();
}
```

---

## What You Must Address

1. Main queue: what data structure? How do workers pull from it?
2. DLQ/retry: how do you schedule retries at increasing delays? (You need some timer mechanism.)
3. How does the retry feed back into the worker pool? (Does it go to the main queue? A separate structure?)
4. Backpressure: how exactly does BLOCK work? Which condition do producers await on?
5. Shutdown sequence: How do you drain (a) the main queue, (b) the retry queue, (c) in-flight processing?
6. Thread safety of the attempt counter and metrics.

---

## Follow-Up Deep-Dives (Interviewer would ask)

- "What if a worker thread dies (uncaught exception)? How do you keep the pool alive?"
- "If you're using a DelayQueue for retries, what's the shutdown implication? (DelayQueue.take() blocks forever if empty.)"
- "How do you prevent retry storms from starving fresh events?"
- "Write a test case that verifies zero event loss during shutdown with pending retries."

---

## Hints (Progressive — Try Before Reading)

### Hint 1: Main Queue
<details>
<summary>Click to reveal</summary>

Use `ArrayBlockingQueue<Event>` with capacity C. For BLOCK policy, producers call `queue.put(event)` which blocks when full. For REJECT policy, use `queue.offer(event)` and throw `RejectedEventException` if it returns false.

</details>

### Hint 2: Retry Mechanism
<details>
<summary>Click to reveal</summary>

Use a `DelayQueue<DelayedEvent>` where `DelayedEvent implements Delayed`. The `getDelay()` method returns the remaining time before this retry is eligible. A dedicated retry thread calls `delayQueue.take()` and re-submits to the main queue (or directly to workers).

</details>

### Hint 3: Retry Feed-Back
<details>
<summary>Click to reveal</summary>

When a worker encounters a failed event with `attemptCount < MAX_RETRIES`, it creates a new `DelayedEvent` with the incremented attempt count and appropriate delay (1s, 2s, 4s), then puts it into the DelayQueue. A single "retry dispatcher" thread takes from the DelayQueue and feeds back into the main work queue.

</details>

### Hint 4: Preventing Retry Storms
<details>
<summary>Click to reveal</summary>

Use `offer()` (non-blocking) when the retry dispatcher feeds back into the main queue. If the main queue is full (fresh events have priority), the retry goes back into the DelayQueue with its next delay. Alternatively, reserve a small portion of queue capacity for retries using a separate bounded queue.

</details>

### Hint 5: Worker Thread Resilience
<details>
<summary>Click to reveal</summary>

Don't use raw `Thread` for workers. Use a `ThreadPoolExecutor` with an `uncaughtExceptionHandler` or wrap the worker loop in `while(running) { try { ... } catch (Throwable t) { log(t); } }`. This ensures one bad event doesn't kill the worker permanently.

</details>

### Hint 6: Shutdown Sequence
<details>
<summary>Click to reveal</summary>

```
1. running = false                  → Gate closed to new submits
2. Poison-pill or interrupt workers → Workers drain remaining queue items  
3. Wait for main queue to empty     → All fresh events processed
4. Signal retry dispatcher          → It stops waiting on DelayQueue
5. Drain DelayQueue manually        → Process remaining retries synchronously
6. Join all threads                 → Everything is done
7. Log final metrics                → totalProcessed + totalFailed + totalDropped == totalSubmitted
```

Key insight: `DelayQueue.take()` blocks forever on empty queue. You need to either interrupt the retry thread or use `poll(timeout)` in a loop checking `running`.

</details>

### Hint 7: Metrics Thread Safety
<details>
<summary>Click to reveal</summary>

Use `LongAdder` for metrics counters (totalProcessed, totalFailed, totalDropped). Multiple worker threads increment these concurrently — `LongAdder` avoids contention. For the final report, call `sum()` after all threads have joined.

</details>