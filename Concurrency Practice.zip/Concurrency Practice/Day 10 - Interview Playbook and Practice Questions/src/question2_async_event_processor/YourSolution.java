package question2_async_event_processor;

import java.util.concurrent.*;
import java.util.concurrent.atomic.LongAdder;

/**
 * ╔════════════════════════════════════════════════════════════════════════════╗
 * ║  QUESTION 2: Bounded Async Event Processor with Dead Letter Queue          ║
 * ╠════════════════════════════════════════════════════════════════════════════╣
 * ║                                                                            ║
 * ║  Design an event processing system where:                                  ║
 * ║                                                                            ║
 * ║  1. Multiple PRODUCER threads submit events to the system.                 ║
 * ║  2. A BOUNDED INTERNAL QUEUE (capacity C) holds pending events.            ║
 * ║     When full, producers block (or reject — configurable).                 ║
 * ║  3. A WORKER POOL of W threads pulls events and processes them.            ║
 * ║     Processing may fail.                                                   ║
 * ║  4. FAILED EVENTS are routed to a Dead Letter Queue (DLQ) with             ║
 * ║     exponential backoff retry: 1s, 2s, 4s, max 3 retries.                  ║
 * ║     After max retries → permanently dropped and logged.                    ║
 * ║  5. GRACEFUL SHUTDOWN: Stop accepting new events. Drain all in-flight      ║
 * ║     events (including pending retries). Only then exit.                    ║
 * ║                                                                            ║
 * ║  Constraints (clarify these with interviewer!):                            ║
 * ║  - 8 producer threads, ~10K events/sec total                               ║
 * ║  - 4 worker threads                                                        ║
 * ║  - Queue capacity: 1024                                                    ║
 * ║  - Backpressure: BLOCK                                                     ║
 * ║  - Processing time: 1-50ms, ~5% failure rate                               ║
 * ║  - Retry schedule: [1s, 2s, 4s]                                            ║
 * ║  - Events: record Event(String id, String payload, int attemptCount)       ║
 * ║                                                                            ║
 * ╚════════════════════════════════════════════════════════════════════════════╝
 *
 * TIME YOURSELF: 35 minutes. Start now.
 */
public class YourSolution {

    // --- Event record (provided) ---
    public record Event(String id, String payload, int attemptCount) {
        public Event withIncrementedAttempt() {
            return new Event(id, payload, attemptCount + 1);
        }
    }

    // --- Backpressure policy (provided) ---
    public enum BackpressurePolicy { BLOCK, REJECT }

    // --- Custom exceptions (provided) ---
    public static class RejectedEventException extends Exception {
        public RejectedEventException(String message) { super(message); }
    }

    // --- Processor contract (provided) ---
    public interface EventProcessor {
        boolean process(Event event) throws Exception;
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // YOUR IMPLEMENTATION BELOW
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    // TODO: Define your DelayedEvent class (implements Delayed for retry scheduling)


    // TODO: Configuration constants
    //   - MAX_RETRIES = 3
    //   - RETRY_DELAYS_MS = {1000, 2000, 4000}


    // TODO: Fields — what data structures do you need?
    //   - Main queue (bounded)?
    //   - Retry queue (DelayQueue)?
    //   - Worker threads?
    //   - Retry dispatcher thread?
    //   - Metrics counters?
    //   - Shutdown flag?


    // TODO: Constructor
    public YourSolution(EventProcessor processor, int queueCapacity, int workerCount, BackpressurePolicy policy) {
        // TODO: Initialize queues, start worker threads, start retry dispatcher
    }

    // TODO: Submit — called by producers
    public void submit(Event event) throws InterruptedException, RejectedEventException {
        // TODO:
        // 1. Check if shut down → reject
        // 2. BLOCK policy: queue.put(event)
        // 3. REJECT policy: queue.offer(event) → throw if false
        throw new UnsupportedOperationException("Implement me!");
    }

    // TODO: Worker loop
    //   - Poll from main queue (with timeout to check running flag)
    //   - Process event
    //   - On success: increment processed counter
    //   - On failure: schedule retry or drop


    // TODO: Handle failure
    //   - If attemptCount < MAX_RETRIES: enqueue to DelayQueue with backoff
    //   - Else: increment dropped counter, log


    // TODO: Retry dispatcher loop
    //   - Poll from DelayQueue (with timeout to check running flag)
    //   - Feed back into main queue


    // TODO: Graceful shutdown
    public void shutdown() throws InterruptedException {
        // TODO:
        // 1. running = false
        // 2. Join workers (they drain main queue)
        // 3. Interrupt retry dispatcher (DelayQueue.take blocks forever)
        // 4. Join retry dispatcher
    }

    // TODO: Observability
    public long getTotalProcessed() { return 0; /* TODO */ }
    public long getTotalFailed() { return 0; /* TODO */ }
    public long getTotalDropped() { return 0; /* TODO */ }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // TEST HARNESS (run to verify your solution)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    public static void main(String[] args) throws Exception {
        System.out.println("=== Test: Event processing with retries — 1000 events, ~5% failure ===");

        // Processor with 5% failure rate
        EventProcessor flakeyProcessor = event -> {
            Thread.sleep(ThreadLocalRandom.current().nextInt(1, 5));
            return ThreadLocalRandom.current().nextDouble() > 0.05;
        };

        YourSolution engine = new YourSolution(flakeyProcessor, 1024, 4, BackpressurePolicy.BLOCK);

        // Submit 1000 events from 8 producers
        ExecutorService producers = Executors.newFixedThreadPool(8);
        int totalEvents = 1000;
        CountDownLatch latch = new CountDownLatch(totalEvents);

        for (int i = 0; i < totalEvents; i++) {
            final int id = i;
            producers.submit(() -> {
                try {
                    engine.submit(new Event("evt-" + id, "payload-" + id, 0));
                } catch (Exception e) {
                    System.err.println("Submit failed: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await();
        System.out.println("All events submitted. Waiting for processing + retries...");

        // Wait for retries to complete (max 7s for 3 retries)
        Thread.sleep(8000);

        engine.shutdown();
        producers.shutdown();

        long processed = engine.getTotalProcessed();
        long dropped = engine.getTotalDropped();

        System.out.println("Processed: " + processed + ", Dropped: " + dropped);

        // Verify no silent loss
        assert processed + dropped == totalEvents
                : "FAIL: processed(" + processed + ") + dropped(" + dropped + ") != " + totalEvents;
        System.out.println("✓ Zero silent loss: processed + dropped == " + totalEvents);

        // Verify high success rate
        assert processed > totalEvents * 0.90
                : "FAIL: Expected >90% processed, got " + processed;
        System.out.println("✓ High success rate: " + (processed * 100 / totalEvents) + "%");

        System.out.println("\n=== PASSED ===");
    }
}