# Question 1: Concurrent Request Coalescer with Rate Limiting

## Problem Statement

Design a `RequestCoalescer` that sits between your application and an expensive external service (e.g., a database or remote API). Multiple threads in your application may request the same key simultaneously. The coalescer must ensure:

1. **Coalescing (Singleflight)**: If 10 threads request key `"user:42"` within the same flight window, only ONE actual call is made to the external service. All 10 threads receive the same result.
2. **Rate Limiting**: Outbound calls to the external service are limited to at most R calls per second (token bucket).
3. **Timeout**: If the external call doesn't complete within T milliseconds, all waiting threads receive a timeout error.
4. **Concurrent independent keys**: Requests for different keys proceed independently and in parallel.

---

## Assumptions

> ⚠️ **Interview Tip**: These assumptions may or may not be given to you upfront. It is YOUR responsibility to ask clarifying questions and establish these constraints with the interviewer before you start coding. Demonstrating this structured clarification is one of the strongest signals in a systems interview.

- Thread count: Up to 64 concurrent application threads calling `get(key)`.
- Key space: Thousands of distinct keys, but "hot keys" are common (10% of keys get 90% of traffic).
- External service latency: 50–500ms per call.
- Rate limit: 100 calls/second, burst capacity of 20.
- Timeout: 300ms per call.
- The coalescer does NOT cache results long-term (no TTL cache — it's purely "in-flight deduplication").
- Once a flight completes (success or failure), subsequent requests for the same key start a new flight.

---

## Interface

```java
public interface ExternalService {
    String fetch(String key) throws IOException, TimeoutException;
}

public class RequestCoalescer {
    RequestCoalescer(ExternalService service, int maxRate, int burstCapacity, long timeoutMs);
    
    // Called by many threads concurrently
    String get(String key) throws TimeoutException, ServiceException;
    
    void shutdown();
}
```

---

## What You Must Address

1. How do you track "in-flight" requests per key? (data structure + synchronization)
2. How do waiting threads block until the flight completes? (coordination primitive)
3. How do you integrate rate limiting without blocking all threads? (token acquisition)
4. How do you handle timeout — both for the external call and for threads waiting on an in-flight result?
5. What happens if the external call throws an exception? (error propagation to all waiters)
6. Shutdown: how do you reject new requests and unblock all waiting threads?

---

## Follow-Up Deep-Dives (Interviewer would ask)

- "What lock granularity do you use? Why?"
- "What happens if a thread is interrupted while waiting for an in-flight result?"
- "Can you have a memory leak if flights are never cleaned up?"
- "What's the worst-case latency for a request that arrives just after the rate limit is exhausted?"

---

## Hints (Progressive — Try Before Reading)

### Hint 1: Flight Tracking
<details>
<summary>Click to reveal</summary>

Use a `ConcurrentHashMap<String, Flight>` where `Flight` wraps a `CompletableFuture<String>`. The first thread to `putIfAbsent` a new Flight "wins" and becomes the executor. All others just attach to the same future.

</details>

### Hint 2: Coordination Primitive
<details>
<summary>Click to reveal</summary>

`CompletableFuture<String>` is perfect here. The executor thread calls `complete(result)` or `completeExceptionally(error)`. All waiting threads call `future.get(timeoutMs, MILLISECONDS)`.

</details>

### Hint 3: Rate Limiting Integration
<details>
<summary>Click to reveal</summary>

The executor thread must acquire a token from the token bucket BEFORE making the external call. Use `tryAcquire(timeout)` so it doesn't block forever. If token acquisition times out, complete the future exceptionally.

</details>

### Hint 4: Cleanup
<details>
<summary>Click to reveal</summary>

After the future completes (success or failure), remove the key from the ConcurrentHashMap. This ensures the next request starts a fresh flight. Use `computeIfAbsent` for atomic insertion and `remove(key, flight)` for conditional removal (only remove if it's still our flight).

</details>

### Hint 5: Token Bucket Design
<details>
<summary>Click to reveal</summary>

Lazy refill: store `lastRefillNanos` and `availableTokens`. On each `tryAcquire`, compute elapsed time, add `elapsed * rate` tokens (capped at burst), then try to consume one. Protect with a `ReentrantLock`.

</details>

### Hint 6: Shutdown
<details>
<summary>Click to reveal</summary>

Set `volatile running = false`. Reject new `get()` calls with an exception. For in-flight futures, you can either let them complete naturally or cancel them. The executor thread pool should be shut down with `shutdownNow()` + `awaitTermination()`.

</details>