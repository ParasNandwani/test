package question1_request_coalescer;

import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ╔════════════════════════════════════════════════════════════════════════════╗
 * ║  QUESTION 1: Concurrent Request Coalescer with Rate Limiting               ║
 * ╠════════════════════════════════════════════════════════════════════════════╣
 * ║                                                                            ║
 * ║  Design a RequestCoalescer that sits between your application and an       ║
 * ║  expensive external service. Multiple threads may request the same key     ║
 * ║  simultaneously. The coalescer must ensure:                                ║
 * ║                                                                            ║
 * ║  1. COALESCING: If 10 threads request key "user:42" within the same        ║
 * ║     flight window, only ONE actual call is made. All 10 get the result.    ║
 * ║  2. RATE LIMITING: Outbound calls limited to R calls/sec (token bucket).   ║
 * ║  3. TIMEOUT: If external call doesn't complete in T ms, all waiters        ║
 * ║     receive a timeout error.                                               ║
 * ║  4. INDEPENDENT KEYS: Different keys proceed in parallel.                  ║
 * ║                                                                            ║
 * ║  Constraints (clarify these with interviewer!):                            ║
 * ║  - Up to 64 concurrent threads calling get(key)                            ║
 * ║  - Hot keys common (10% of keys get 90% traffic)                           ║
 * ║  - External service latency: 50-500ms                                      ║
 * ║  - Rate limit: 100 calls/sec, burst capacity 20                            ║
 * ║  - Timeout: 300ms per call                                                 ║
 * ║  - No long-term caching — purely in-flight deduplication                   ║
 * ║                                                                            ║
 * ╚════════════════════════════════════════════════════════════════════════════╝
 *
 * TIME YOURSELF: 35 minutes. Start now.
 */
public class YourSolution {

    // --- External Service Contract (provided) ---
    public interface ExternalService {
        String fetch(String key) throws IOException, TimeoutException, InterruptedException;
    }

    public static class ServiceException extends Exception {
        public ServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // YOUR IMPLEMENTATION BELOW
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    // TODO: Define your Flight class (what coordination primitive will waiting threads use?)


    // TODO: Define your Token Bucket (lazy refill, ReentrantLock-protected)


    // TODO: Fields — what data structures do you need?
    //   - In-flight map?
    //   - Executor for async calls?
    //   - Shutdown flag?


    // TODO: Constructor
    public YourSolution(ExternalService service, int maxRate, int burstCapacity, long timeoutMs) {
        // TODO: Initialize token bucket, executor, etc.
    }

    // TODO: Core method — get() with coalescing
    public String get(String key) throws TimeoutException, ServiceException, InterruptedException {
        // TODO:
        // 1. Check if shut down
        // 2. Atomically insert or retrieve existing flight for this key
        // 3. If we're the first (executor) → launch async external call
        // 4. Wait on the flight's future with timeout
        throw new UnsupportedOperationException("Implement me!");
    }

    // TODO: Shutdown
    public void shutdown() {
        // TODO:
        // 1. Set running = false
        // 2. Shutdown executor
        // 3. Complete remaining futures exceptionally
    }

    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    // TEST HARNESS (run to verify your solution)
    // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

    public static void main(String[] args) throws Exception {
        System.out.println("=== Test: Coalescing — 10 threads, same key, expect 1 external call ===");

        java.util.concurrent.atomic.AtomicInteger externalCalls = new java.util.concurrent.atomic.AtomicInteger(0);

        ExternalService countingService = key -> {
            externalCalls.incrementAndGet();
            Thread.sleep(100);
            return "result-for-" + key;
        };

        YourSolution coalescer = new YourSolution(countingService, 100, 20, 300);
        ExecutorService testPool = Executors.newFixedThreadPool(10);
        CountDownLatch latch = new CountDownLatch(10);
        CopyOnWriteArrayList<String> results = new CopyOnWriteArrayList<>();

        for (int i = 0; i < 10; i++) {
            testPool.submit(() -> {
                try {
                    String result = coalescer.get("hot-key");
                    results.add(result);
                } catch (Exception e) {
                    System.err.println("Error: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await();

        // Verify coalescing
        assert externalCalls.get() == 1
                : "FAIL: Expected 1 external call, got " + externalCalls.get();
        System.out.println("✓ Only " + externalCalls.get() + " external call made");

        assert results.size() == 10
                : "FAIL: Expected 10 results, got " + results.size();
        System.out.println("✓ All 10 threads received a result");

        for (String r : results) {
            assert "result-for-hot-key".equals(r)
                    : "FAIL: Unexpected result: " + r;
        }
        System.out.println("✓ All results are identical and correct");

        coalescer.shutdown();
        testPool.shutdown();
        System.out.println("\n=== PASSED ===");
    }
}