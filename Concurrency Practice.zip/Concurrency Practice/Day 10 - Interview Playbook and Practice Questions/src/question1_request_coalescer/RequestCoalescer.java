package question1_request_coalescer;

import java.io.IOException;
import java.util.concurrent.*;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Concurrent Request Coalescer with Rate Limiting
 *
 * Key Design Decisions:
 * - ConcurrentHashMap<String, Flight> for lock-free per-key flight tracking
 * - CompletableFuture for multi-waiter coordination (one executor, N waiters)
 * - Token Bucket with lazy refill for rate limiting (no background thread)
 * - ExecutorService for async flight execution (decouples caller from external call)
 *
 * Primitives Used:
 * - ConcurrentHashMap.computeIfAbsent() for atomic flight creation
 * - CompletableFuture.get(timeout) for timed waiting
 * - ReentrantLock for token bucket state
 * - volatile for shutdown flag
 */
public class RequestCoalescer {

    // --- External Service Contract ---
    public interface ExternalService {
        String fetch(String key) throws IOException, TimeoutException, InterruptedException;
    }

    public static class ServiceException extends Exception {
        public ServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }

    // --- Flight: represents a single in-flight request ---
    private static class Flight {
        final CompletableFuture<String> future = new CompletableFuture<>();
    }

    // --- Token Bucket Rate Limiter (lazy refill, no background thread) ---
    private static class TokenBucket {
        private final ReentrantLock lock = new ReentrantLock();
        private final double refillRate;    // tokens per nanosecond
        private final int maxTokens;
        private double availableTokens;
        private long lastRefillNanos;

        TokenBucket(int maxRate, int burstCapacity) {
            this.refillRate = maxRate / 1_000_000_000.0;  // tokens per nano
            this.maxTokens = burstCapacity;
            this.availableTokens = burstCapacity;          // start full
            this.lastRefillNanos = System.nanoTime();
        }

        /**
         * Try to acquire one token within the given timeout.
         * Returns true if acquired, false if timed out.
         */
        boolean tryAcquire(long timeoutMs) throws InterruptedException {
            long deadlineNanos = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(timeoutMs);

            while (true) {
                lock.lockInterruptibly();
                try {
                    refill();
                    if (availableTokens >= 1.0) {
                        availableTokens -= 1.0;
                        return true;
                    }
                    // Calculate wait time for next token
                    double deficit = 1.0 - availableTokens;
                    long waitNanos = (long) (deficit / refillRate);
                    long remaining = deadlineNanos - System.nanoTime();

                    if (remaining <= 0) {
                        return false;  // Timed out
                    }
                    // Sleep for the shorter of: time-to-next-token or remaining timeout
                    long sleepNanos = Math.min(waitNanos, remaining);
                    // Release lock while sleeping
                    lock.unlock();
                    try {
                        TimeUnit.NANOSECONDS.sleep(sleepNanos);
                    } finally {
                        lock.lock();
                    }
                } finally {
                    lock.unlock();
                }
            }
        }

        private void refill() {
            long now = System.nanoTime();
            long elapsed = now - lastRefillNanos;
            if (elapsed > 0) {
                double newTokens = elapsed * refillRate;
                availableTokens = Math.min(maxTokens, availableTokens + newTokens);
                lastRefillNanos = now;
            }
        }
    }

    // --- Fields ---
    private final ExternalService service;
    private final TokenBucket tokenBucket;
    private final long timeoutMs;
    private final ConcurrentHashMap<String, Flight> inFlight = new ConcurrentHashMap<>();
    private final ExecutorService executor;
    private volatile boolean running = true;

    // --- Constructor ---
    public RequestCoalescer(ExternalService service, int maxRate, int burstCapacity, long timeoutMs) {
        this.service = service;
        this.tokenBucket = new TokenBucket(maxRate, burstCapacity);
        this.timeoutMs = timeoutMs;
        // Bounded thread pool — caps concurrent outbound calls
        this.executor = new ThreadPoolExecutor(
                4, 16,
                60L, TimeUnit.SECONDS,
                new LinkedBlockingQueue<>(256),
                r -> {
                    Thread t = new Thread(r);
                    t.setName("Coalescer-Worker-" + t.getId());
                    t.setDaemon(true);
                    return t;
                }
        );
    }

    // --- Core: get() with coalescing ---
    public String get(String key) throws TimeoutException, ServiceException, InterruptedException {
        if (!running) {
            throw new ServiceException("Coalescer is shut down", null);
        }

        // Atomic flight creation: first thread to insert wins and becomes executor
        Flight myFlight = new Flight();
        Flight existing = inFlight.putIfAbsent(key, myFlight);

        if (existing != null) {
            // Another flight is already in progress — just wait on it
            return awaitFlight(existing, key);
        }

        // We are the executor — launch the external call asynchronously
        executor.submit(() -> executeFlight(key, myFlight));

        // Wait on our own flight
        return awaitFlight(myFlight, key);
    }

    // --- Wait for a flight to complete with timeout ---
    private String awaitFlight(Flight flight, String key) throws TimeoutException, ServiceException, InterruptedException {
        try {
            return flight.future.get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            throw new TimeoutException("Request for key '" + key + "' timed out after " + timeoutMs + "ms");
        } catch (ExecutionException e) {
            Throwable cause = e.getCause();
            if (cause instanceof TimeoutException) {
                throw (TimeoutException) cause;
            }
            throw new ServiceException("External call failed for key: " + key, cause);
        }
    }

    // --- Execute the actual external call (runs on executor thread) ---
    private void executeFlight(String key, Flight flight) {
        try {
            // Step 1: Acquire rate limit token (with timeout)
            boolean acquired = tokenBucket.tryAcquire(timeoutMs);
            if (!acquired) {
                flight.future.completeExceptionally(
                        new TimeoutException("Rate limit token acquisition timed out for key: " + key));
                return;
            }

            // Step 2: Make the external call
            String result = service.fetch(key);

            // Step 3: Complete the future — all waiters unblock
            flight.future.complete(result);

        } catch (Exception e) {
            // Propagate error to ALL waiting threads
            flight.future.completeExceptionally(e);
        } finally {
            // Step 4: Remove from in-flight map — next request starts fresh flight
            inFlight.remove(key, flight);  // Conditional remove: only if still our flight
        }
    }

    // --- Shutdown ---
    public void shutdown() {
        running = false;  // 1. Gate closed — reject new requests

        executor.shutdown();  // 2. Stop accepting new tasks
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();  // 3. Force interrupt in-flight
                executor.awaitTermination(2, TimeUnit.SECONDS);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }

        // 4. Complete any remaining futures exceptionally so waiters unblock
        inFlight.forEach((key, flight) -> {
            flight.future.completeExceptionally(
                    new ServiceException("Coalescer shut down while request in flight", null));
        });
        inFlight.clear();
    }

    // --- Demo / Test with Assertions ---
    public static void main(String[] args) throws Exception {
        System.out.println("=== Test 1: Coalescing — 10 threads, same key, expect 1 external call ===");

        java.util.concurrent.atomic.AtomicInteger externalCalls = new java.util.concurrent.atomic.AtomicInteger(0);
        java.util.concurrent.CopyOnWriteArrayList<String> results = new java.util.concurrent.CopyOnWriteArrayList<>();

        ExternalService countingService = key -> {
            externalCalls.incrementAndGet();
            Thread.sleep(100);
            return "result-for-" + key;
        };

        RequestCoalescer coalescer = new RequestCoalescer(countingService, 100, 20, 300);
        ExecutorService testPool = Executors.newFixedThreadPool(10);
        CountDownLatch latch = new CountDownLatch(10);

        for (int i = 0; i < 10; i++) {
            testPool.submit(() -> {
                try {
                    String result = coalescer.get("hot-key");
                    results.add(result);
                } catch (Exception e) {
                    System.err.println(Thread.currentThread().getName() + " error: " + e.getMessage());
                } finally {
                    latch.countDown();
                }
            });
        }

        latch.await();

        // Assertion 1: Only 1 external call was made (coalescing works)
        assert externalCalls.get() == 1
                : "FAIL: Expected 1 external call, got " + externalCalls.get();
        System.out.println("✓ Coalescing: only " + externalCalls.get() + " external call made");

        // Assertion 2: All threads received the same result
        assert results.size() == 10
                : "FAIL: Expected 10 results, got " + results.size();
        for (String r : results) {
            assert "result-for-hot-key".equals(r)
                    : "FAIL: Expected 'result-for-hot-key', got '" + r + "'";
        }
        System.out.println("✓ All 10 threads received identical result: " + results.get(0));

        // --- Test 2: Independent keys proceed in parallel ---
        System.out.println("\n=== Test 2: Independent keys — 5 different keys, expect 5 external calls ===");
        externalCalls.set(0);
        CountDownLatch latch2 = new CountDownLatch(5);

        for (int i = 0; i < 5; i++) {
            final String key = "key-" + i;
            testPool.submit(() -> {
                try {
                    coalescer.get(key);
                } catch (Exception e) {
                    System.err.println("Error for " + key + ": " + e.getMessage());
                } finally {
                    latch2.countDown();
                }
            });
        }

        latch2.await();
        assert externalCalls.get() == 5
                : "FAIL: Expected 5 external calls for 5 keys, got " + externalCalls.get();
        System.out.println("✓ Independent keys: " + externalCalls.get() + " external calls for 5 distinct keys");

        // --- Test 3: Shutdown rejects new requests ---
        System.out.println("\n=== Test 3: Shutdown rejects new requests ===");
        coalescer.shutdown();
        try {
            coalescer.get("after-shutdown");
            assert false : "FAIL: Should have thrown ServiceException after shutdown";
        } catch (ServiceException e) {
            System.out.println("✓ Shutdown: new request correctly rejected with: " + e.getMessage());
        }

        testPool.shutdown();
        System.out.println("\n=== ALL ASSERTIONS PASSED ===");
    }
}