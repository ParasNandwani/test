# Day 10: Interview Playbook and Practice Questions

> **Day 10 Synthesis**: A high-density, rigorous quick-review document for a 45-minute Staff SDE System Programming round.  
> Synthesizes all structural concepts from Days 1–9, plus 3 timed practice questions.

---

## Table of Contents

1. [The 4-Phase Interview Blueprint](#the-4-phase-interview-blueprint)
2. [Systems Primitives Quick-Reference Matrix](#systems-primitives-quick-reference-matrix)
3. [Edge-Case Defense Checklist](#edge-case-defense-checklist)
4. [The "Explain Your Lock" Decision Framework](#the-explain-your-lock-decision-framework)
5. [Code Reading Exercise](#code-reading-exercise)
6. [Java Concurrency API Cheat Sheet](#java-concurrency-api-cheat-sheet)
7. [Practice Questions](#practice-questions)

---

## The 4-Phase Interview Blueprint

### The 45-Minute Clock

```
┌───────────────────────────────────────────────────────────────────────────────┐
│  0 min          7 min          15 min                   35 min         45 min │
│  │──── Phase 1 ──│──── Phase 2 ──│──────── Phase 3 ────────│── Phase 4 ──│    │
│  │ Clarify &     │ Abstract      │ Lean Core               │ Bottleneck  │    │
│  │ Constrain     │ Interfaces    │ Implementation          │ Deep-Dive   │    │
└───────────────────────────────────────────────────────────────────────────────┘
```

---

### Phase 1: Clarification & Constraints (0–7 min)

**Goal:** Scope the problem. Demonstrate you think before you code.

**Signal Questions to Ask:**

| Category | Question | Why It Matters |
|----------|----------|----------------|
| **Concurrency Model** | "How many producer threads? Is this SPSC, MPSC, or MPMC?" | Determines lock-free feasibility (SPSC = ring buffer; MPMC = striped locks) |
| **Throughput Target** | "What's the target event rate — thousands/sec or millions/sec?" | Millions → pre-allocation + zero-GC; thousands → simpler is fine |
| **Durability** | "Must writes survive process crash? Machine crash?" | Process crash → fsync per batch; machine crash → replicated WAL |
| **Failure Semantics** | "On overload: block, drop, or signal the caller?" | Backpressure strategy — affects entire architecture shape |
| **Read/Write Ratio** | "Is this read-heavy, write-heavy, or mixed?" | Read-heavy → StampedLock optimistic; write-heavy → striping/sharding |
| **Ordering** | "Do consumers need strict ordering or is best-effort OK?" | Strict → single-threaded flush; best-effort → parallel fan-out |
| **Memory Budget** | "Bounded memory or unbounded growth acceptable?" | Bounded → ring buffer / double-buffer; unbounded → ConcurrentLinkedQueue |

**What to Write on the Board:**
```
Constraints:
- N producers, 1 consumer (MPSC)
- Target: 1M events/sec
- Bounded memory (pre-allocated)
- At-least-once delivery (no silent drops)
- Graceful shutdown required (drain before exit)
```

---

### Phase 2: Abstract Interfaces (7–15 min)

**Goal:** Define contracts BEFORE implementation. Show you think in terms of dependency injection and testability.

**Template:**
```java
// 1. Define the DATA contract
public record Payload(long timestamp, int routingKey, byte[] data) {}

// 2. Define the SOURCE contract (how data arrives)
public interface PayloadSource {
    Payload poll(long timeoutMs) throws InterruptedException;
}

// 3. Define the SINK contract (where data goes)
public interface BatchSink {
    void flush(List<Payload> batch) throws IOException;
}

// 4. Define the CACHE contract (intermediate state)
public interface MemoryCache<K, V> {
    V get(K key);
    void put(K key, V value);
}
```

**Narrate the Primitive Choices:**
> "I'll use a ReentrantLock with two Conditions here because I need the flusher to await until data is ready, but also wake on a timeout for time-based flushes. A plain synchronized block can't give me multiple conditions."

> "The cache will be striped — each stripe has its own lock. A get() and put() only touch one stripe, so deadlock is structurally impossible."

---

### Phase 3: Lean Core Implementation (15–35 min)

**Goal:** Write clean, correct code. Prioritize:
1. **try-finally lock safety** — every `lock()` has a `finally { unlock() }`
2. **InterruptedException handling** — restore the flag, never swallow
3. **Condition loops** — always `while(predicate)` around `await()`
4. **volatile for shutdown flags** — cheapest visibility guarantee

**The Non-Negotiable Patterns:**

```java
// PATTERN 1: Canonical lock usage
lock.lock();
try {
    // critical section
} finally {
    lock.unlock();  // ALWAYS in finally
}

// PATTERN 2: Condition await with predicate loop
lock.lock();
try {
    while (!condition_met) {         // WHILE, not IF (spurious wakeups)
        dataReady.await();           // releases lock, parks thread
    }
    // condition is met — proceed
} finally {
    lock.unlock();
}

// PATTERN 3: InterruptedException — restore and propagate
try {
    condition.await();
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();  // RESTORE the flag
    throw e;                             // or return gracefully
}

// PATTERN 4: Graceful shutdown sequence
volatile boolean running = true;

void shutdown() {
    running = false;           // 1. Close the gate
    lock.lock();
    try {
        flushReady.signal();   // 2. Wake the flusher for final drain
    } finally {
        lock.unlock();
    }
    flusherThread.join();      // 3. Wait for completion
    sink.close();              // 4. Release resources
}
```

---

### Phase 4: Bottleneck Deep-Dive (35–45 min)

**Goal:** Show you can identify WHERE the system will break under load, and propose trade-offs.

**The Bottleneck Identification Framework:**

| Bottleneck | Symptom | Root Cause | Optimization |
|------------|---------|------------|--------------|
| **Lock contention** | Threads parked, low CPU utilization | Long lock hold time or too many threads on one lock | Stripe the lock; reduce critical section; move I/O outside lock |
| **Cache-line bouncing** | High L1 miss rate, CAS retry storms | Multiple cores writing to same 64-byte block | Pad to cache-line boundaries (128 bytes on ARM); per-thread accumulation |
| **fsync latency** | Throughput drops to disk IOPS | Synchronous durability requirement | Batch writes; group commit; async flush with bounded loss window |
| **GC pauses** | Periodic latency spikes (5–200ms) | Object allocation on hot path | Pre-allocate; reuse via ring buffer; primitive types over boxed |
| **Head-of-line blocking** | Fast consumers starved by slow one | Synchronous fan-out or shared buffer | Per-consumer buffers; async delivery threads |
| **Thread starvation** | Work piles up, no progress | Unbounded queue + fixed pool, or blocking I/O in pool | Bounded queues + rejection policy; separate I/O threads |

**Trade-Off Articulation Template:**
> "The double-buffer swap is O(1) — just two reference assignments — so the lock hold time is nanoseconds regardless of batch size. The trade-off is that we need 2× the buffer memory, and LRU accuracy is per-batch rather than per-entry. For a metrics pipeline, this is acceptable because we optimize for throughput over strict ordering."

---

## Systems Primitives Quick-Reference Matrix

This table maps each concurrency problem archetype to its optimal Java primitive and design pattern.

| Problem Archetype | Optimal Primitive | Pattern Name | Key Insight | Day |
|-------------------|-------------------|--------------|-------------|-----|
| High-write shared counter | `long[]` with padding / `LongAdder` | Per-thread accumulation | Eliminate MESI invalidation by isolating cache lines | 1 |
| Read-heavy shared map | `StampedLock.tryOptimisticRead()` | Optimistic read → validate → fallback | Readers are invisible to writers; no CAS on read path | 2 |
| SPSC high-throughput transfer | `AtomicLong.lazySet()` + pre-allocated array | Ring buffer with sequence coordination | StoreStore barrier (1-2ns) vs volatile write (20-40ns) | 2 |
| Zero-GC event processing | Pre-allocated `T[]` + mutable slots | Object pool / ring buffer reuse | Never `new` on hot path; mutate in-place | 2 |
| Durable sequential writes | `FileChannel.force(true)` | WAL append-only + group commit | Sequential I/O is 100-1000× faster than random | 3, 4 |
| Crash recovery | Newline-terminated records | Torn-write detection + replay | Incomplete line = discard; complete lines = replay into memory | 4 |
| Concurrent key-value cache | `ReentrantLock[]` (stripe array) | Striped/segmented LRU | Hash → stripe; one lock per operation; deadlock impossible | 5 |
| Timed task scheduling | `Condition.awaitNanos(delay)` | Min-heap + preemptive signal | Sleep exactly until next task; wake instantly on new urgent task | 6 |
| Rate limiting | `ReentrantLock` + lazy math | Token bucket (lazy refill) | Compute tokens on-demand; zero background threads; O(1) space | 6 |
| High-throughput batched I/O | `ReentrantLock` + two `Condition`s | Double-buffered appender | Pointer swap is nanoseconds; I/O happens on separate buffer | 7 |
| Async service composition | `CompletableFuture` + `allOf` | Fan-out, per-service timeout, error recovery | Non-blocking pipelines; partial failure = graceful degradation | 8 |
| Backpressure under overload | `ArrayBlockingQueue` (bounded) | BLOCK / DROP / DROP_OLDEST policy | Every bounded buffer MUST define "what happens when full?" | 7 |

---

## Edge-Case Defense Checklist

Production failure modes and the exact defensive pattern. Each item is a potential interview landmine.

---

### 1. Thread Leaks

**Failure mode:** Executor/thread created but never shut down. Threads accumulate across requests. JVM cannot exit cleanly.

**Defense:**
```java
ExecutorService pool = Executors.newFixedThreadPool(N);
try {
    // ... use pool ...
} finally {
    pool.shutdown();                              // Stop accepting new tasks
    if (!pool.awaitTermination(5, SECONDS)) {     // Wait for in-flight
        pool.shutdownNow();                       // Force interrupt
    }
}
```

**Rule:** Every `Executors.new*()` call must have a corresponding `shutdown()` in a finally block or shutdown hook.

---

### 2. Lock Leaks (The #1 Java Concurrency Bug)

**Failure mode:** Exception thrown between `lock()` and `unlock()`. Lock is never released. All other threads deadlock.

**Defense:**
```java
lock.lock();          // OUTSIDE try — if lock() itself throws, we don't unlock something we never locked
try {
    // critical section — may throw
} finally {
    lock.unlock();    // ALWAYS executes
}
```

**Anti-pattern (WRONG):**
```java
try {
    lock.lock();      // ← WRONG POSITION
    // ...
} finally {
    lock.unlock();    // If lock() threw, this unlocks a lock we never acquired → IllegalMonitorStateException
}
```

---

### 3. InterruptedException Mishandling

**Failure mode:** Thread swallows interrupt. Graceful shutdown becomes impossible. Thread runs forever ignoring cancellation.

**Defense — Option A (propagate):**
```java
try {
    condition.await();
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();  // Restore the flag
    return;                              // Exit gracefully
}
```

**Defense — Option B (re-throw):**
```java
try {
    queue.take();
} catch (InterruptedException e) {
    Thread.currentThread().interrupt();
    throw new ServiceShutdownException("Interrupted during take", e);
}
```

**Rule:** NEVER write an empty `catch (InterruptedException e) {}`. Always restore the interrupt flag.

---

### 4. Spurious Wakeups

**Failure mode:** Thread wakes from `await()` without being signaled. Proceeds with stale/invalid state.

**Defense:**
```java
while (!bufferHasData) {           // WHILE loop — re-check predicate after every wakeup
    dataReady.await();
}
// Only reach here when predicate is actually true
```

**Anti-pattern (WRONG):**
```java
if (!bufferHasData) {              // IF — no re-check after spurious wakeup
    dataReady.await();
}
// May proceed with bufferHasData still false!
```

---

### 5. Memory Refill Racing (Double-Buffer Specific)

**Failure mode:** Active buffer fills up. Swap attempted, but flush buffer still contains data from previous cycle. Swap would overwrite un-flushed entries → data loss.

**Defense:**
```java
lock.lock();
try {
    while (activeBuffer.isFull()) {
        if (flushBuffer.isEmpty()) {
            // Safe to swap — flush buffer is drained
            List<T> temp = activeBuffer;
            activeBuffer = flushBuffer;
            flushBuffer = temp;
            flushReady.signal();
            break;
        } else {
            // BOTH full — must wait for flusher to drain
            spaceAvailable.await();  // Backpressure: block until flusher signals
        }
    }
    activeBuffer.add(item);
} finally {
    lock.unlock();
}
```

---

### 6. Partial I/O Writes (Torn Writes)

**Failure mode:** Process crashes mid-write. File contains a half-written record. On recovery, parsing fails or produces garbage data.

**Defense:**
```
Record format: [COMPLETE_LINE]\n

Recovery algorithm:
  for each line in WAL:
      if line ends with \n → valid record → replay
      if line does NOT end with \n → torn write → DISCARD
```

**Rule:** Use a delimiter (newline) or length-prefix + checksum. An incomplete record must be detectable and discardable without corrupting valid data before it.

---

### 7. False Sharing (Silent Performance Killer)

**Failure mode:** Two threads write to independent variables on the same cache line. MESI invalidation traffic causes 4-100× slowdown. Results are still correct — only detectable via profiling.

**Defense:**
```java
// Pad each hot variable to its own cache line (128 bytes on Apple Silicon, 64 on x86)
private long p1, p2, p3, p4, p5, p6, p7;        // 56 bytes padding
private final AtomicLong producerSequence;        // 8 bytes (the hot variable)
private long p8, p9, p10, p11, p12, p13, p14;   // 56 bytes padding
```

**Detection:** `perf c2c` on Linux; Intel VTune "Memory Access Analysis"; suspiciously high L1 miss rates for per-thread data.

---

### 8. GC Pressure on Hot Path

**Failure mode:** Creating objects (`new`) on every event. At 1M events/sec, generates GBs of garbage per second. GC pauses stall all threads for 5-200ms.

**Defense:**
```java
// PRE-ALLOCATE at startup
T[] buffer = new T[CAPACITY];
for (int i = 0; i < CAPACITY; i++) {
    buffer[i] = new T();  // One-time cost
}

// HOT PATH — zero allocation
T slot = buffer[sequence & mask];  // Reuse existing object
slot.set(timestamp, key, value);   // Mutate in place
```

**Rule:** On the hot path, never `new`. Use primitives over boxed types. Use `char[]` over `String`. Use bit-packed flags over `Map<String,String>`.

---

### 9. Head-of-Line Blocking in Fan-Out

**Failure mode:** Synchronous delivery to N subscribers. One slow/blocked subscriber stalls the publisher and all other subscribers.

**Defense:**
```java
// Each subscriber has its own delivery thread
for (Subscriber sub : subscribers) {
    sub.submitAsync(message);  // Enqueues to sub's private executor — returns immediately
}
// Publisher is NEVER blocked by any subscriber
```

**Rule:** In fan-out architectures, the publisher's thread must never call blocking operations on a per-subscriber resource. Decouple via async submission.

---

### 10. Shutdown Data Loss

**Failure mode:** `shutdown()` called. Active buffer has 47 un-flushed entries. Process exits. Data is lost.

**Defense (The Correct Shutdown Sequence):**
```
Step 1: running = false                    → Close the gate to new arrivals
Step 2: Acquire lock, wait for in-flight   → Let current writers finish
Step 3: Wait for flush buffer to drain     → Don't swap over un-flushed data
Step 4: Final swap (active → flush)        → Capture residual entries
Step 5: Signal flusher, join thread        → Wait for final drain to complete
Step 6: Close resources                    → Only after flusher is done
```

**Rule:** Shutdown is NOT "kill everything." It's an ordered drain sequence. Every step depends on the previous step completing.

---

## The "Explain Your Lock" Decision Framework

When the interviewer asks "Why did you choose that synchronization mechanism?", use this decision tree:

```
START: What's the access pattern?
│
├─► Single writer, single reader (SPSC)?
│       → NO LOCK. Use lazySet() + volatile read (memory barriers only).
│       → Cost: ~1-2ns per operation.
│       → Example: Ring buffer producer/consumer sequences.
│
├─► Read-dominated (>90% reads), rare writes?
│       → StampedLock with tryOptimisticRead().
│       → Cost: ~5-10ns per read (just a volatile read + validate).
│       → Example: Metrics registry, configuration cache.
│
├─► Write-dominated, independent keys?
│       → ConcurrentHashMap (internal lock striping) or manual stripe array.
│       → Cost: ~20-50ns per operation (one CAS per stripe).
│       → Example: LRU cache, session store.
│
├─► Need multiple wait conditions (e.g., "space available" + "data ready")?
│       → ReentrantLock + multiple Condition objects.
│       → Cost: ~40-80ns under contention.
│       → Example: Double-buffered logger, task scheduler.
│
├─► Simple mutual exclusion, very short critical section?
│       → ReentrantLock (unfair mode) or even synchronized.
│       → JVM optimizes single hot locks aggressively (thin locks, adaptive spinning).
│       → Example: WAL append serialization.
│
├─► Counter under high write contention?
│       → LongAdder (or manual padded per-thread slots).
│       → Cost: ~1ns per write (each thread writes to its own cache line).
│       → Aggregation on read: sum() iterates all cells.
│       → Example: Request counters, throughput metrics.
│
└─► Need timed waits with preemptive wake?
        → ReentrantLock + Condition.awaitNanos(delay).
        → Sleeps precisely; wakes on signal OR timeout.
        → Example: Task scheduler coordinator, time-window flush trigger.
```

**The Universal Trade-Off Statement:**
> "Every synchronization choice trades off between throughput (how much work per second), latency (how long each operation takes), correctness (whether invariants hold), and complexity (how hard it is to reason about). I chose [X] because in this access pattern, [correctness property] is non-negotiable, and [X]'s overhead of [Y ns] is acceptable given our target of [Z ops/sec]."

---

## Code Reading Exercise

Use this exercise to test your ability to **read and explain** concurrent code — a common Staff interview format. Open the referenced source files and answer the questions WITHOUT running the code.

### Instructions

Refer to the following files from earlier days:
- **Day 5:** [`StripedLRUCache.java`](../Day%205%20-%20High%20Performance%20Concurrent%20Caches%20LRU%20LFU/src/cache/StripedLRUCache.java) (lock striping pattern)
- **Day 7:** [`DoubleBufferedLogger.java`](../Day%207%20-%20Double%20Buffered%20Log%20Aggregator/src/engine/DoubleBufferedLogger.java) (double-buffer + condition coordination)
- **Day 8:** [`Subscriber.java`](../Day%208%20-%20Concurrent%20Pub-Sub%20Queues%20With%20Topics/src/engine/Subscriber.java) and [`Topic.java`](../Day%208%20-%20Concurrent%20Pub-Sub%20Queues%20With%20Topics/src/engine/Topic.java) (async fan-out isolation)

### Questions

**1. Pattern Identification (Day 5: StripedLRUCache)**
- What makes deadlock structurally impossible in the striped cache design?
- If two threads call `get("key-A")` and `put("key-B")` concurrently, under what condition do they contend on the same lock?

**2. Correctness Analysis (Day 7: DoubleBufferedLogger)**
- Why is the backpressure check inside a `while` loop instead of an `if`?
- What happens if `InterruptedException` is thrown during the flusher's `await()`? Trace the code path.
- Why is the shutdown flag declared `volatile` but the buffer references are not?

**3. Shutdown Ordering (Day 7: DoubleBufferedLogger)**
- What would go wrong if you called `flusherThread.join()` BEFORE doing the final buffer swap?
- Why must producers stop BEFORE the logger shuts down?

**4. Performance Reasoning (Day 7: DoubleBufferedLogger)**
- The flusher writes to disk OUTSIDE the lock. Why? What would happen if disk I/O was inside the lock?
- Why use `ReentrantLock` + `Condition` instead of `synchronized` + `wait()`?

**5. Isolation Analysis (Day 8: Subscriber + Topic)**
- In `Topic.publish()`, what happens if a BLOCK subscriber's buffer is full? Trace why the publisher is NOT blocked.
- Why does each Subscriber have its own `SingleThreadExecutor` instead of sharing a global thread pool?

### Expected Answers (Self-Check)

1. Each operation hashes to exactly ONE stripe; since a thread only ever holds one stripe lock at a time, circular wait is impossible. They contend only if `hash("key-A") % stripeCount == hash("key-B") % stripeCount`.
2. `while` loop because of spurious wakeups (Commandment #2). InterruptedException → interrupt flag restored → flusher exits gracefully after final drain.
3. `volatile` is needed because the shutdown flag is read by multiple threads WITHOUT holding the lock (fast-path check). Buffers are only accessed while holding the lock, so volatile is unnecessary for them.
4. Join before swap → residual entries in the active buffer never reach the flusher → data loss. Producers must stop first, otherwise they write to a shutting-down buffer → IllegalStateException or lost data.
5. Disk I/O outside lock: keeps lock-held time at nanoseconds regardless of I/O speed. Inside lock → all producer threads blocked during the entire disk write. `synchronized` doesn't support multiple Conditions or `awaitNanos` for timed flushes.
6. `Topic.publish()` calls `subscriber.submitAsync(message)` which submits a task to the subscriber's private executor and returns immediately. If the buffer is full, `buffer.put()` blocks only on the subscriber's dedicated delivery thread — not the publisher's thread. A shared pool risks exhaustion if many subscribers BLOCK simultaneously.

---

## Java Concurrency API Cheat Sheet

A method-level quick reference for the concurrency primitives used throughout this course. Use this for last-minute review before your interview.

---

### ReentrantLock

```
new ReentrantLock()              → Creates unfair lock (higher throughput)
new ReentrantLock(true)          → Creates fair lock (FIFO ordering, lower throughput)

lock.lock()                      → Acquire (blocks until available)
lock.tryLock()                   → Acquire if free, else return false immediately
lock.tryLock(time, unit)         → Acquire with timeout
lock.unlock()                    → Release (MUST be in finally block)
lock.isHeldByCurrentThread()     → Check if current thread holds it
lock.newCondition()              → Create a Condition variable bound to this lock
```

### Condition

```
condition.await()                → Park thread; releases lock; waits for signal
condition.awaitNanos(nanos)      → Park with timeout; returns remaining nanos (≤0 = timed out)
condition.await(time, unit)      → Park with timeout; returns false if timed out
condition.signal()               → Wake ONE waiting thread
condition.signalAll()            → Wake ALL waiting threads
```

### AtomicLong / AtomicInteger

```
new AtomicLong(initialValue)     → Create with initial value
.get()                           → Read (volatile read semantics)
.set(value)                      → Write (volatile write — StoreStore + StoreLoad)
.lazySet(value)                  → Write (StoreStore only — cheaper, eventually visible)
.incrementAndGet()               → Atomic ++x (CAS loop internally)
.getAndIncrement()               → Atomic x++ (returns old value)
.compareAndSet(expect, update)   → CAS: if current==expect, set to update; returns boolean
.addAndGet(delta)                → Atomic += delta
```

### ConcurrentHashMap

```
new ConcurrentHashMap<>()                → Default 16 segments
.get(key)                                → Lock-free read (volatile + CAS internally)
.put(key, value)                         → Striped lock write
.putIfAbsent(key, value)                 → Atomic "insert if missing"
.computeIfAbsent(key, mappingFunction)   → Atomic "compute if missing" (idempotent creation)
.remove(key)                             → Remove entry
.size()                                  → Approximate count (NOT atomic across segments)
```

### ExecutorService

```
Executors.newFixedThreadPool(n)          → N threads, unbounded queue
Executors.newSingleThreadExecutor()      → 1 thread, FIFO unbounded queue
Executors.newCachedThreadPool()          → Grows on demand, 60s idle timeout
Executors.newScheduledThreadPool(n)      → Supports delay and periodic tasks

pool.submit(Callable<T>)                 → Returns Future<T>
pool.submit(Runnable)                    → Returns Future<?>
pool.execute(Runnable)                   → Fire-and-forget (no Future)
pool.shutdown()                          → Reject new tasks, finish in-flight
pool.shutdownNow()                       → Interrupt all, return pending list
pool.awaitTermination(time, unit)        → Block until all done or timeout
pool.isShutdown()                        → True after shutdown() called
pool.isTerminated()                      → True after all tasks complete
```

### CompletableFuture

```
CompletableFuture.supplyAsync(supplier)          → Run async, return CF<T> (on ForkJoinPool)
CompletableFuture.supplyAsync(supplier, exec)    → Run async on custom executor
CompletableFuture.runAsync(runnable)             → Run async, return CF<Void>

cf.thenApply(fn)                                 → Transform result (like .map())
cf.thenAccept(consumer)                          → Consume result, return CF<Void>
cf.thenRun(runnable)                             → Run after completion (ignores result)
cf.thenCompose(fn)                               → Chain dependent async call (like .flatMap())
cf.thenCombine(other, biFn)                      → Combine two independent CFs when both done

CompletableFuture.allOf(cf1, cf2, ...)           → CF<Void> that completes when ALL complete
CompletableFuture.anyOf(cf1, cf2, ...)           → CF<Object> that completes when FIRST completes

cf.exceptionally(fn)                             → Recover from exception with fallback value
cf.handle((result, ex) -> ...)                   → Access both result and exception
cf.whenComplete((result, ex) -> ...)             → Side effect (doesn't change value)

cf.orTimeout(time, unit)                         → Fail with TimeoutException if not done in time
cf.completeOnTimeout(default, time, unit)        → Use default value if not done in time

cf.join()                                        → Block and get result (throws unchecked)
cf.get()                                         → Block and get result (throws checked)
cf.get(time, unit)                               → Block with timeout

cf.thenApplyAsync(fn)                            → Transform on different thread (guaranteed)
cf.thenApplyAsync(fn, executor)                  → Transform on specified executor
```

### CountDownLatch

```
new CountDownLatch(count)                → One-shot barrier
latch.countDown()                        → Decrement count by 1
latch.await()                            → Block until count reaches 0
latch.await(time, unit)                  → Block with timeout
latch.getCount()                         → Current count
```

### CyclicBarrier

```
new CyclicBarrier(parties)               → Reusable barrier for N threads
new CyclicBarrier(parties, barrierAction) → Runs action when all arrive
barrier.await()                          → Block until all parties arrive
barrier.await(time, unit)                → Block with timeout
barrier.reset()                          → Reset for reuse
```

### Semaphore

```
new Semaphore(permits)                   → Counting semaphore (permits = max concurrent)
new Semaphore(permits, true)             → Fair semaphore (FIFO)
sem.acquire()                            → Block until permit available, then take one
sem.acquire(n)                           → Block until n permits available
sem.tryAcquire()                         → Non-blocking: take permit if available
sem.tryAcquire(time, unit)              → Try with timeout
sem.release()                            → Return one permit
sem.release(n)                           → Return n permits
sem.availablePermits()                   → Current available count
```

### StampedLock

```
new StampedLock()                        → Creates stamped lock (NOT reentrant!)

long stamp = lock.writeLock()            → Exclusive write lock
lock.unlockWrite(stamp)                  → Release write lock

long stamp = lock.readLock()             → Shared read lock (blocks writers)
lock.unlockRead(stamp)                   → Release read lock

long stamp = lock.tryOptimisticRead()    → No lock! Just reads version counter (~5ns)
lock.validate(stamp)                     → Check if any write happened since stamp
```

### ArrayBlockingQueue

```
new ArrayBlockingQueue<>(capacity)       → Bounded, array-backed, FIFO
queue.put(element)                       → Block until space available (BLOCK strategy)
queue.offer(element)                     → Return false if full (DROP strategy)
queue.offer(element, time, unit)         → Try with timeout
queue.take()                             → Block until element available
queue.poll()                             → Return null if empty
queue.poll(time, unit)                   → Poll with timeout
queue.remainingCapacity()                → Space left before full
queue.size()                             → Current element count
```

### volatile (keyword)

```
private volatile boolean flag;           → Guarantees visibility + ordering
                                         → Write: StoreStore + StoreLoad fence
                                         → Read: LoadLoad + LoadStore fence
                                         → Use for: shutdown flags, publication flags
                                         → NOT for: compound operations (i++ is NOT atomic)
```

### System Timing

```
System.nanoTime()                        → Monotonic clock (NTP-immune), nanosecond resolution
                                         → Use for: measuring intervals, scheduling, benchmarks
                                         → NOT for: wall-clock time or logging timestamps

System.currentTimeMillis()               → Wall-clock time (Unix epoch)
                                         → Can jump backward/forward (NTP adjustments)
                                         → Use for: logging, human-readable timestamps only
```

---

## Quick-Reference: The 10 Commandments

1. **`lock()` outside try, `unlock()` in finally.** Always.
2. **`await()` inside `while(predicate)`.** Never bare `if`.
3. **Restore interrupt flag.** `Thread.currentThread().interrupt()` before return/throw.
4. **Bound your buffers.** Every queue must answer "what happens when full?"
5. **Move I/O outside the lock.** Lock protects pointer swap, not the flush.
6. **Pad hot variables.** 128 bytes apart on Apple Silicon, 64 on x86.
7. **Pre-allocate on startup.** Zero `new` on the hot path.
8. **Use `nanoTime()` for intervals.** `currentTimeMillis()` is not monotonic (NTP jumps).
9. **Shutdown is a drain sequence.** Gate → drain in-flight → final flush → join → close.
10. **Name your threads.** `Thread.setName("Flusher-1")` — invaluable in thread dumps.

---

## Practice Questions

Three timed interview simulations to build muscle memory. Each question has a problem statement, a reference solution, and a blank `YourSolution.java` file for you to implement from scratch.

**How to use:** Set a 45-minute timer. Open only the `QUESTION.md`. Write your solution without looking at the reference. Then compare.

| # | Question | Key Concepts Tested |
|---|----------|-------------------|
| 1 | [Request Coalescer](./src/question1_request_coalescer/QUESTION.md) | ConcurrentHashMap, CompletableFuture, deduplication under concurrency |
| 2 | [Async Event Processor](./src/question2_async_event_processor/QUESTION.md) | Bounded queue, backpressure, graceful shutdown, thread coordination |
| 3 | [Metric Aggregator](./src/question3_metric_aggregator/QUESTION.md) | Lock striping, time-window bucketing, concurrent reads during flush |

### How to Run

```bash
# From the course root directory:
./gradlew :day10:run                                                              # Runs Question 1 reference
./gradlew :day10:run -PmainClass=question2_async_event_processor.AsyncEventEngine  # Runs Question 2
./gradlew :day10:run -PmainClass=question3_metric_aggregator.MetricAggregator      # Runs Question 3
```

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
