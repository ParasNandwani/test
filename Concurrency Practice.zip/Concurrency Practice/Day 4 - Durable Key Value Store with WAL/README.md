# Day 4: Durable Key-Value Store with WAL

A production-grade, highly concurrent, durable Key-Value Store implemented in Java.  
Designed as a systems programming exercise demonstrating WAL-based durability, crash recovery, and lock-free concurrent reads.

---

## The Interview Question

> *"Design a durable key-value store that supports concurrent reads and writes. Writes must survive process crashes. Reads must never block writers. Walk me through your architecture, durability guarantees, and concurrency model."*

**What the interviewer is testing:**
- Can you articulate WAL-based durability and why writes go to disk BEFORE memory?
- Do you understand fsync trade-offs (sync vs async) and their throughput implications?
- Can you design lock-free reads alongside locked writes?
- Do you know how to handle crash recovery with torn-write detection?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: Revise from Day 3 — Assumed Knowledge](#part-1-revise-from-day-3--assumed-knowledge)
2. [Part 2: Storage Engine Architecture](#part-2-storage-engine-architecture)
3. [Part 3: System Architecture](#part-3-system-architecture)
4. [Part 4: Concurrency Model](#part-4-concurrency-model)
5. [Part 5: WAL Record Format](#part-5-wal-record-format)
6. [Part 6: Recovery Protocol](#part-6-recovery-protocol)
7. [Part 7: Design Decisions Summary](#part-7-design-decisions-summary)
8. [How to Run](#how-to-run)
9. [Directory Structure](#directory-structure)

---

## Part 1: Revise from Day 3 — Assumed Knowledge

This day builds directly on Day 3's I/O fundamentals. Ensure you're comfortable with these concepts:

| # | Concept | One-Line Refresher | Day 3 Section |
|---|---------|-------------------|---------------|
| 1 | **User Space vs Kernel Space** | Every `write()` crosses the kernel boundary; costs ~1-10µs per crossing | Section 1 |
| 2 | **OS Page Cache** | Writes land in RAM first, not disk; the OS flushes lazily in the background | Section 2 |
| 3 | **fsync** | Forces data from page cache to stable storage; costs ~0.1-10ms depending on hardware | Section 3 |
| 4 | **Sequential vs Random I/O** | Sequential append is 100-1000× faster than random writes (HDD seek, SSD write amplification) | Section 5 |

**How Day 3 concepts connect to Day 4:**

```
Day 3 Foundation                          Day 4 Builds On It
═══════════════                          ═══════════════════

Page Cache behavior ─────────────────►  Why async WAL writes go to page cache (fast but lossy)
                                         vs sync WAL calling fsync (slow but durable)

fsync cost + semantics ──────────────►  The core trade-off: sync vs async flushing
                                         (100 writes/sec vs 1M writes/sec)

Sequential I/O advantage ────────────►  Why WAL is append-only (never random updates)
                                         Sequential append = fast + crash-safe

User/kernel boundary cost ───────────►  Why we use BufferedWriter (batch syscalls)
                                         instead of write() per record
```

---

## Part 2: Storage Engine Architecture

Before diving into the code, you must understand four foundational concepts. Each one answers a specific "why" behind the design decisions in this system.

---

### 1. What is a Write-Ahead Log (WAL) and Why Must It Be Written BEFORE Memory?

**Plain Language:**  
A Write-Ahead Log is a simple append-only file on disk where every mutation (put or delete) is recorded *before* it is applied to the in-memory data structure.

**Analogy — The Accountant's Ledger:**  
Imagine you run a bank. You have a whiteboard in your office (fast, easy to read — this is your in-memory map) and a bound ledger book in a fireproof safe (slow to write in, but survives disasters — this is your WAL on disk).

If a customer deposits $500:
1. You first write "$500 deposit, Account #1234" in the **ledger** (WAL).
2. *Then* you update the whiteboard total (MemTable).

Why this order? If the building loses power after step 1 but before step 2, you can re-read the ledger and reconstruct the whiteboard perfectly. But if you updated the whiteboard first and crashed before writing the ledger, you'd have a corrupted view with no way to verify what happened.

**The Rule:** Disk-before-memory guarantees that no acknowledged write can ever be lost. The WAL *is* the source of truth; the in-memory map is merely a fast cache of that truth.

---

### 2. Why Sequential Append-Only Operations Instead of Random Updates?

**Plain Language:**  
We only ever *append* new records to the end of the WAL file. We never go back and modify earlier bytes. This is dramatically faster and safer than updating records in-place.

**Analogy — Writing in a Notebook vs. Erasing & Rewriting:**  
Think of two strategies for note-taking:
- **Strategy A (Append-Only):** You write each new fact on the next blank line. The notebook grows linearly. If you drop the notebook, every page is still intact and readable from start to finish.
- **Strategy B (In-Place Update):** You erase old facts and overwrite them. If you drop the notebook mid-erase, some entries are half-erased — corrupted and unrecoverable.

**Why it's faster:**  
Hard disks (HDD) have a physical read/write head. Sequential writes let the head move in one continuous sweep. Random writes force the head to jump around (seek), which is 100–1000× slower. Even on SSDs, sequential writes reduce write amplification and are friendlier to the flash translation layer.

**Why it's safer:**  
An append operation either completes fully (the bytes land at the end of the file) or it doesn't (the file length doesn't advance). There is no intermediate "half-overwritten" state of existing data. Your old data is never at risk.

---

### 3. Synchronous Flushing vs. Asynchronous Flushing — The Core Trade-Off

When you call `write()` on a file, the data typically lands in the **OS page cache** (a RAM buffer managed by the kernel), NOT on the physical disk platter/flash cell. The OS will eventually flush it to disk — but "eventually" might be seconds later.

| Mode | What Happens | Durability Guarantee | Throughput |
|------|-------------|---------------------|------------|
| **Synchronous** (`fsync` per write) | After each append, we call `fsync()` / `FileChannel.force(true)` which blocks until the hardware confirms the bytes are on stable storage. | **Full.** If the process/machine crashes 1 nanosecond after `put()` returns, the data is safe on disk. | **Low.** Each write incurs a full disk round-trip (~0.1–10ms depending on hardware). Typical throughput: 100–10,000 writes/sec. |
| **Asynchronous** (buffered) | Writes go to the OS page cache and return immediately. The OS flushes lazily, or we flush periodically (e.g., every 100ms). | **Partial.** A crash can lose the last few milliseconds of writes that were acknowledged but not yet flushed. | **High.** Writes complete in microseconds (RAM speed). Typical throughput: 100,000–1,000,000+ writes/sec. |

**Analogy — Saving a Document:**  
- **Sync mode** = pressing Ctrl+S after every single keystroke. You'll never lose work, but typing feels sluggish.
- **Async mode** = auto-save every 5 seconds. Typing is fluid, but if your laptop dies mid-sentence, you lose the last few keystrokes.

**Real-world choice:**  
- Financial transactions, metadata operations → Synchronous (cannot afford any data loss).
- Metrics, logging, caches → Asynchronous (can tolerate small windows of loss for massive throughput gains).

---

### 4. How Atomicity Is Guaranteed (The "All-or-Nothing" Contract)

**The Problem:**  
A `put(key, value)` involves TWO steps: (1) append to WAL, (2) update MemTable. What if the process crashes between steps 1 and 2? Or during step 1 itself?

**The Solution — The WAL Append Is the Commit Point:**

```
Timeline of a successful write:
┌─────────────────────────────────────────────────────────┐
│  1. Acquire WAL lock                                     │
│  2. Append full record to WAL file                       │
│  3. [Sync mode: fsync() — data is now on stable storage] │
│  4. Release WAL lock                                     │
│  5. Update MemTable (ConcurrentHashMap.put)              │
│  6. Return success to caller                             │
└─────────────────────────────────────────────────────────┘
```

**Failure scenarios and their outcomes:**

| Crash Point | WAL State | MemTable State | Recovery Outcome |
|-------------|-----------|----------------|-----------------|
| During step 2 (partial write) | Incomplete record on disk | Not updated | Recovery detects incomplete record (wrong length/checksum), **discards it**. Effect: write never happened. ✓ |
| After step 3, before step 5 | Complete record on disk | Not updated | Recovery **replays** the record into MemTable. Effect: write is restored. ✓ |
| After step 5 | Complete record on disk | Updated | No recovery needed. ✓ |

**Key insight:** We never have a state where the MemTable is updated but the WAL is not. The ordering (WAL first) plus recovery replay guarantees that the system is always consistent — either both reflect the write, or neither does.

**Analogy — Two-Phase Commit for One Person:**  
Think of mailing a letter. You write the letter (WAL append), then put it in the mailbox (MemTable update). If you collapse after writing but before mailing, the letter exists — someone can find it and mail it for you (recovery). If you collapse while writing, the incomplete letter is discarded. You never have a situation where the letter is mailed but doesn't exist.

---

## Part 3: System Architecture

```
                    ┌──────────────────────────────────────────┐
                    │            StorageEngine                 │
                    │           (Orchestrator)                 │
                    │                                          │
   put(k,v) ──────► │  1. WAL.append(PUT, k, v)                │
                    │  2. MemTable.put(k, v)                   │
                    │                                          │
   get(k) ────────► │  MemTable.get(k)  [lock-free read]       │
                    │                                          │
   delete(k) ─────► │  1. WAL.append(DELETE, k)                │
                    │  2. MemTable.delete(k)                   │
                    │                                          │
   recover() ─────► │  Read WAL sequentially → rebuild MemTable│
                    └──────────┬──────────────┬────────────────┘
                               │              │
                    ┌──────────▼───────┐  ┌───▼──────────────┐
                    │  WriteAheadLog   │  │    MemTable      │
                    │  (Disk Module)   │  │  (Memory Module) │
                    │                  │  │                  │
                    │ • SyncWAL        │  │ ConcurrentHashMap│
                    │ • AsyncWAL       │  │ (lock-striped)   │
                    │                  │  │                  │
                    │ Append-only file │  │ O(1) get/put     │
                    └──────────────────┘  └──────────────────┘
```

---

## Part 4: Concurrency Model

| Operation | Lock Scope | Reasoning |
|-----------|-----------|-----------|
| `put` / `delete` (write path) | `ReentrantLock` inside WAL (serializes appends to maintain sequential ordering) | WAL records must be sequential — interleaved bytes would corrupt the file. |
| `get` (read path) | **None** (lock-free) | `ConcurrentHashMap.get()` uses volatile reads and CAS internally — safe without external locking. |
| MemTable update after WAL | **None** (lock-free) | `ConcurrentHashMap.put()` is thread-safe via internal lock striping. |

**Result:** Readers never block. Writers only contend at the WAL append (a fast sequential I/O operation), not at a global engine lock.

---

## Part 5: WAL Record Format

Each record is a single UTF-8 line:

```
PUT\tkey\tvalue\n
DELETE\tkey\n
```

- Tab-delimited for simplicity and fast parsing.
- Newline-terminated — an incomplete line (no trailing `\n`) during recovery indicates a torn write and is discarded.
- This format is intentionally simple for an interview setting. Production systems would add CRC32 checksums and length prefixes.

---

## Part 6: Recovery Protocol

```
1. Open WAL file for reading.
2. For each complete line (terminated by \n):
   a. Parse operation type (PUT or DELETE).
   b. Apply to MemTable:
      - PUT → memTable.put(key, value)
      - DELETE → memTable.delete(key)
3. Discard any trailing incomplete line (torn write from crash).
4. MemTable now reflects the exact state at the last successful write.
5. Reopen WAL in append mode for new operations.
```

---

## Directory Structure

```
src/
├── Main.java                           Demo: concurrent writers/readers + crash recovery
├── wal/
│   ├── WriteAheadLog.java              Interface (append, close, getPath)
│   ├── SyncWriteAheadLog.java          fsync after every append
│   └── AsyncWriteAheadLog.java         Buffered writes, optional periodic flush
├── memtable/
│   └── MemTable.java                   Thread-safe in-memory key-value map
└── engine/
    └── StorageEngine.java              Orchestrator: WAL → MemTable, recovery
```

---

## How to Run

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day4:run
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on `Main.java` directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out Main
```

---

## Part 7: Design Decisions Summary

| Decision | Rationale |
|----------|-----------|
| WAL before MemTable | Guarantees durability — acknowledged writes survive crashes |
| Append-only WAL | Sequential I/O is fast + never corrupts existing data |
| ConcurrentHashMap for MemTable | Lock-free reads, lock-striped writes — minimal contention |
| ReentrantLock in WAL (not synchronized) | Explicit lock control, interruptibility, fairness options |
| Newline as record terminator | Enables simple torn-write detection on recovery |
| Interface for WAL | Allows swapping Sync/Async strategies without changing engine code |

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
