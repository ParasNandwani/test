import engine.StorageEngine;
import memtable.MemTable;
import wal.SyncWriteAheadLog;
import wal.WriteAheadLog;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Minimal interview-friendly demo (~50 lines).
 * Demonstrates: concurrent reads + writes, crash simulation, WAL recovery.
 */
public class InterviewDemo {
    public static void main(String[] args) throws Exception {
        Path walPath = Path.of("data", "store.wal");
        Files.createDirectories(walPath.getParent());
        Files.deleteIfExists(walPath);

        // ─── Phase 1: Concurrent reads + writes ────────────────────────
        WriteAheadLog wal = new SyncWriteAheadLog(walPath);
        StorageEngine engine = new StorageEngine(wal, new MemTable());

        ExecutorService pool = Executors.newFixedThreadPool(6);

        // 4 writer threads
        for (int t = 0; t < 4; t++) {
            final int id = t;
            pool.submit(() -> {
                for (int i = 0; i < 100; i++) {
                    try {
                        engine.put("k-" + id + "-" + i, "v-" + id + "-" + i);
                    } catch (Exception e) { e.printStackTrace(); }
                }
            });
        }

        // 2 reader threads (reading while writes are in progress)
        for (int t = 0; t < 2; t++) {
            pool.submit(() -> {
                for (int i = 0; i < 200; i++) {
                    engine.get("k-0-" + (i % 100)).ifPresent(v ->
                        System.out.println("[READ] " + v)
                    );
                }
            });
        }

        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);
        System.out.println("MemTable size after writes: " + engine.size());
        engine.close();

        // ─── Phase 2: Simulate crash & recovery ────────────────────────
        System.out.println("\n--- Simulating crash (MemTable lost) ---");
        WriteAheadLog wal2 = new SyncWriteAheadLog(walPath);
        StorageEngine recovered = new StorageEngine(wal2, new MemTable());
        recovered.recover();
        System.out.println("MemTable size after recovery: " + recovered.size());
        System.out.println("Sample get: k-2-50 = " + recovered.get("k-2-50").orElse("NOT FOUND"));
        recovered.close();

        // Cleanup
        Files.deleteIfExists(walPath);
    }
}