import engine.StorageEngine;
import memtable.MemTable;
import wal.AsyncWriteAheadLog;
import wal.SyncWriteAheadLog;
import wal.WriteAheadLog;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Demo harness for the Durable Key-Value Store.
 * <p>
 * Demonstrates:
 * 1. Concurrent writers and readers operating simultaneously.
 * 2. Crash simulation (engine closed abruptly without clean shutdown).
 * 3. Recovery from WAL to rebuild MemTable state.
 * 4. Both Sync and Async WAL modes.
 */
public class Main {

    private static final int NUM_WRITER_THREADS = 4;
    private static final int NUM_READER_THREADS = 2;
    private static final int WRITES_PER_THREAD = 500;
    private static final Path WAL_FILE = Path.of("data", "store.wal");

    public static void main(String[] args) throws Exception {
        System.out.println("═══════════════════════════════════════════════════════════════");
        System.out.println("  DURABLE KEY-VALUE STORE WITH WRITE-AHEAD LOG — DEMO");
        System.out.println("═══════════════════════════════════════════════════════════════");

        // Clean up any previous WAL file
        cleanUp();

        // ─── Phase 1: Sync WAL — Concurrent Writes ─────────────────────────────
        System.out.println("\n▶ PHASE 1: Concurrent writes with SYNCHRONOUS WAL (fsync per write)");
        System.out.println("  Writers: " + NUM_WRITER_THREADS + " threads × " + WRITES_PER_THREAD + " writes each");
        System.out.println("  Readers: " + NUM_READER_THREADS + " threads reading concurrently");

        Files.createDirectories(WAL_FILE.getParent());
        WriteAheadLog syncWal = new SyncWriteAheadLog(WAL_FILE);
        MemTable memTable = new MemTable();
        StorageEngine engine = new StorageEngine(syncWal, memTable);

        long startTime = System.nanoTime();
        runConcurrentWorkload(engine);
        long elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);

        System.out.println("  ✓ Completed in " + elapsedMs + " ms");
        System.out.println("  ✓ MemTable size: " + engine.size() + " entries");

        // ─── Phase 2: Simulate Crash ───────────────────────────────────────────
        System.out.println("\n▶ PHASE 2: Simulating crash (closing engine, discarding MemTable)");
        engine.close();

        // Simulate process restart — MemTable is gone
        MemTable freshMemTable = new MemTable();
        System.out.println("  ✓ MemTable cleared. Size after 'crash': " + freshMemTable.size());

        // ─── Phase 3: Recovery from WAL ────────────────────────────────────────
        System.out.println("\n▶ PHASE 3: Recovery — replaying WAL to rebuild MemTable");

        WriteAheadLog recoveryWal = new SyncWriteAheadLog(WAL_FILE);
        StorageEngine recoveredEngine = new StorageEngine(recoveryWal, freshMemTable);

        long recoveryStart = System.nanoTime();
        int replayedCount = recoveredEngine.recover();
        long recoveryMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - recoveryStart);

        System.out.println("  ✓ Recovery completed in " + recoveryMs + " ms");
        System.out.println("  ✓ Records replayed: " + replayedCount);
        System.out.println("  ✓ MemTable size after recovery: " + recoveredEngine.size());

        // Verify a sample of recovered data
        verifySampleData(recoveredEngine);
        recoveredEngine.close();

        // ─── Phase 4: Async WAL — Throughput Comparison ────────────────────────
        System.out.println("\n▶ PHASE 4: Concurrent writes with ASYNCHRONOUS WAL (buffered, no fsync)");
        cleanUp();
        Files.createDirectories(WAL_FILE.getParent());

        WriteAheadLog asyncWal = new AsyncWriteAheadLog(WAL_FILE);
        MemTable asyncMemTable = new MemTable();
        StorageEngine asyncEngine = new StorageEngine(asyncWal, asyncMemTable);

        startTime = System.nanoTime();
        runConcurrentWorkload(asyncEngine);
        elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);

        System.out.println("  ✓ Completed in " + elapsedMs + " ms");
        System.out.println("  ✓ MemTable size: " + asyncEngine.size() + " entries");
        asyncEngine.close();

        // ─── Summary ───────────────────────────────────────────────────────────
        System.out.println("\n═══════════════════════════════════════════════════════════════");
        System.out.println("  DEMO COMPLETE — All phases passed successfully.");
        System.out.println("═══════════════════════════════════════════════════════════════");

        cleanUp();
    }

    /**
     * Runs a concurrent workload with multiple writer and reader threads.
     */
    private static void runConcurrentWorkload(StorageEngine engine) throws InterruptedException {
        ExecutorService executor = Executors.newFixedThreadPool(NUM_WRITER_THREADS + NUM_READER_THREADS);
        CountDownLatch writersReady = new CountDownLatch(NUM_WRITER_THREADS);
        CountDownLatch startGun = new CountDownLatch(1);
        CountDownLatch allDone = new CountDownLatch(NUM_WRITER_THREADS + NUM_READER_THREADS);
        AtomicInteger writeErrors = new AtomicInteger(0);
        AtomicInteger readCount = new AtomicInteger(0);
        AtomicInteger readHits = new AtomicInteger(0);

        // Spawn writer threads
        for (int t = 0; t < NUM_WRITER_THREADS; t++) {
            final int threadId = t;
            executor.submit(() -> {
                writersReady.countDown();
                try {
                    startGun.await(); // Wait for all threads to be ready
                    for (int i = 0; i < WRITES_PER_THREAD; i++) {
                        String key = "key-" + threadId + "-" + i;
                        String value = "value-" + threadId + "-" + i;
                        try {
                            engine.put(key, value);
                        } catch (IOException e) {
                            writeErrors.incrementAndGet();
                        }

                        // Interleave some deletes (every 10th write)
                        if (i > 0 && i % 10 == 0) {
                            String deleteKey = "key-" + threadId + "-" + (i - 5);
                            try {
                                engine.delete(deleteKey);
                            } catch (IOException e) {
                                writeErrors.incrementAndGet();
                            }
                        }
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    allDone.countDown();
                }
            });
        }

        // Spawn reader threads (read concurrently while writes are happening)
        for (int t = 0; t < NUM_READER_THREADS; t++) {
            final int threadId = t;
            executor.submit(() -> {
                try {
                    startGun.await();
                    // Continuously read while writers are active
                    while (allDone.getCount() > NUM_READER_THREADS) {
                        // Read random keys from different writer threads
                        for (int w = 0; w < NUM_WRITER_THREADS; w++) {
                            int idx = (threadId * 37 + w * 13) % WRITES_PER_THREAD;
                            String key = "key-" + w + "-" + idx;
                            Optional<String> result = engine.get(key);
                            readCount.incrementAndGet();
                            if (result.isPresent()) {
                                readHits.incrementAndGet();
                            }
                        }
                        Thread.sleep(1); // small delay to avoid spin-lock behavior
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    allDone.countDown();
                }
            });
        }

        // Wait for all writers to be ready, then fire the start gun
        writersReady.await();
        startGun.countDown();

        // Wait for all threads to complete
        allDone.await(30, TimeUnit.SECONDS);
        executor.shutdown();
        executor.awaitTermination(5, TimeUnit.SECONDS);

        System.out.println("  ✓ Write errors: " + writeErrors.get());
        System.out.println("  ✓ Read operations: " + readCount.get() + " (hits: " + readHits.get() + ")");
    }

    /**
     * Verifies that a sample of keys can be correctly retrieved after recovery.
     */
    private static void verifySampleData(StorageEngine engine) {
        System.out.println("  Verifying sample recovered data:");
        int verified = 0;
        int mismatches = 0;

        for (int t = 0; t < NUM_WRITER_THREADS; t++) {
            for (int i = 0; i < 5; i++) { // Check first 5 keys per thread
                String key = "key-" + t + "-" + i;
                String expectedValue = "value-" + t + "-" + i;
                Optional<String> actual = engine.get(key);

                if (actual.isPresent() && actual.get().equals(expectedValue)) {
                    verified++;
                } else if (actual.isEmpty()) {
                    // Key might have been deleted — that's valid
                    verified++;
                } else {
                    mismatches++;
                    System.err.println("    MISMATCH: key=" + key
                            + " expected=" + expectedValue
                            + " actual=" + actual.orElse("(empty)"));
                }
            }
        }

        System.out.println("    ✓ Verified: " + verified + " keys, Mismatches: " + mismatches);
    }

    /**
     * Removes the WAL file and data directory for a clean start.
     */
    private static void cleanUp() throws IOException {
        if (Files.exists(WAL_FILE)) {
            Files.delete(WAL_FILE);
        }
        Path dataDir = WAL_FILE.getParent();
        if (dataDir != null && Files.exists(dataDir)) {
            // Only delete if empty
            try {
                Files.delete(dataDir);
            } catch (IOException ignored) {
                // Directory not empty or other issue — fine for demo
            }
        }
    }
}