package engine;

import memtable.MemTable;
import wal.WriteAheadLog;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Optional;

/**
 * StorageEngine — the orchestrator that unifies the WAL and MemTable.
 * <p>
 * Write Contract:
 * <ol>
 *   <li>Append the mutation record to the WAL (disk-first).</li>
 *   <li>Apply the mutation to the MemTable (memory-second).</li>
 * </ol>
 * <p>
 * Read Contract:
 * <ul>
 *   <li>Reads go directly to the MemTable — lock-free, zero disk I/O.</li>
 * </ul>
 * <p>
 * Recovery Contract:
 * <ul>
 *   <li>On startup, replay the WAL sequentially to rebuild the MemTable.</li>
 *   <li>Incomplete (torn) records at the end of the WAL are discarded.</li>
 * </ul>
 * <p>
 * Thread Safety:
 * <ul>
 *   <li>Writers serialize at the WAL level (ReentrantLock inside the WAL implementation).</li>
 *   <li>MemTable operations are internally thread-safe (ConcurrentHashMap).</li>
 *   <li>No global engine-level lock — readers never block writers and vice versa.</li>
 * </ul>
 */
public class StorageEngine {

    private static final String OP_PUT = "PUT";
    private static final String OP_DELETE = "DELETE";
    private static final String FIELD_SEPARATOR = "\t";

    private final WriteAheadLog wal;
    private final MemTable memTable;

    public StorageEngine(WriteAheadLog wal, MemTable memTable) {
        this.wal = wal;
        this.memTable = memTable;
    }

    // ─── Write Operations ───────────────────────────────────────────────────────

    /**
     * Stores a key-value pair durably.
     * <p>
     * Ordering guarantee: WAL append completes before MemTable is updated.
     * If the WAL write fails (IOException), the MemTable is NOT updated,
     * preserving atomicity.
     *
     * @param key   the key (must not contain tab or newline characters)
     * @param value the value (must not contain tab or newline characters)
     * @throws IOException if the WAL append fails
     */
    public void put(String key, String value) throws IOException {
        validateKeyValue(key, value);

        // Step 1: Durable write — disk first
        String record = OP_PUT + FIELD_SEPARATOR + key + FIELD_SEPARATOR + value;
        wal.append(record);

        // Step 2: In-memory update — only reached if WAL append succeeded
        memTable.put(key, value);
    }

    /**
     * Deletes a key durably.
     * <p>
     * A DELETE record is appended to the WAL even if the key doesn't exist in the MemTable.
     * This ensures recovery is deterministic (the WAL is the source of truth).
     *
     * @param key the key to delete
     * @throws IOException if the WAL append fails
     */
    public void delete(String key) throws IOException {
        validateKey(key);

        // Step 1: Durable write
        String record = OP_DELETE + FIELD_SEPARATOR + key;
        wal.append(record);

        // Step 2: In-memory removal
        memTable.delete(key);
    }

    // ─── Read Operations ────────────────────────────────────────────────────────

    /**
     * Retrieves a value by key. Lock-free — goes directly to ConcurrentHashMap.
     *
     * @param key the key to look up
     * @return Optional containing the value, or empty if not found
     */
    public Optional<String> get(String key) {
        return memTable.get(key);
    }

    // ─── Recovery ───────────────────────────────────────────────────────────────

    /**
     * Recovers the MemTable state by replaying the WAL from the beginning.
     * <p>
     * This should be called on startup before accepting new reads/writes.
     * It clears the current MemTable and rebuilds it entirely from the WAL.
     * <p>
     * Incomplete lines (torn writes from a crash) at the end of the file
     * are silently discarded — they represent uncommitted operations.
     *
     * @return the number of records successfully replayed
     * @throws IOException if reading the WAL file fails
     */
    public int recover() throws IOException {
        Path walPath = wal.getPath();

        if (!Files.exists(walPath)) {
            return 0;
        }

        memTable.clear();
        int replayedCount = 0;

        try (BufferedReader reader = Files.newBufferedReader(walPath, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) {
                    continue; // skip blank lines
                }

                String[] parts = line.split(FIELD_SEPARATOR);

                if (parts.length < 2) {
                    // Malformed record — skip (could be a torn write)
                    System.err.println("[RECOVERY] Skipping malformed record: " + line);
                    continue;
                }

                String operation = parts[0];

                switch (operation) {
                    case OP_PUT:
                        if (parts.length >= 3) {
                            memTable.put(parts[1], parts[2]);
                            replayedCount++;
                        } else {
                            System.err.println("[RECOVERY] Skipping incomplete PUT record: " + line);
                        }
                        break;

                    case OP_DELETE:
                        memTable.delete(parts[1]);
                        replayedCount++;
                        break;

                    default:
                        System.err.println("[RECOVERY] Skipping unknown operation: " + operation);
                        break;
                }
            }
        }

        System.out.println("[RECOVERY] Replayed " + replayedCount + " records from WAL.");
        return replayedCount;
    }

    // ─── Lifecycle ──────────────────────────────────────────────────────────────

    /**
     * Gracefully shuts down the storage engine.
     * Flushes and closes the WAL.
     *
     * @throws IOException if closing the WAL fails
     */
    public void close() throws IOException {
        wal.close();
    }

    /**
     * Returns the current number of entries in the MemTable.
     */
    public int size() {
        return memTable.size();
    }

    /**
     * Returns a reference to the underlying MemTable (for testing/debugging).
     */
    public MemTable getMemTable() {
        return memTable;
    }

    // ─── Validation ─────────────────────────────────────────────────────────────

    private void validateKeyValue(String key, String value) {
        validateKey(key);
        if (value == null) {
            throw new IllegalArgumentException("Value must not be null");
        }
        if (value.contains("\t") || value.contains("\n")) {
            throw new IllegalArgumentException("Value must not contain tab or newline characters");
        }
    }

    private void validateKey(String key) {
        if (key == null || key.isEmpty()) {
            throw new IllegalArgumentException("Key must not be null or empty");
        }
        if (key.contains("\t") || key.contains("\n")) {
            throw new IllegalArgumentException("Key must not contain tab or newline characters");
        }
    }
}