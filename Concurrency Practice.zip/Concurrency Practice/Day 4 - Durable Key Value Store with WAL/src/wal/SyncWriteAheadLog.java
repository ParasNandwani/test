package wal;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Synchronous Write-Ahead Log implementation.
 * <p>
 * Every {@link #append(String)} call writes the record directly via an unbuffered
 * {@link FileOutputStream} and then calls {@code getFD().sync()} (fsync) to force
 * the data to stable storage before returning.
 * <p>
 * Trade-off: Maximum durability at the cost of throughput (one disk round-trip per write).
 * <p>
 * Uses the same {@link FileOutputStream} primitive as {@link AsyncWriteAheadLog},
 * but WITHOUT a buffer layer — writes go directly to the kernel, then fsync to disk.
 */
public class SyncWriteAheadLog implements WriteAheadLog {

    private final Path path;
    private final FileOutputStream fos;
    private final ReentrantLock lock = new ReentrantLock();

    public SyncWriteAheadLog(Path path) throws IOException {
        this.path = path;
        // Open in append mode (second arg = true)
        this.fos = new FileOutputStream(path.toFile(), true);
    }

    @Override
    public void append(String record) throws IOException {
        byte[] bytes = (record + "\n").getBytes(StandardCharsets.UTF_8);

        lock.lock();
        try {
            fos.write(bytes);
            // fsync: block until hardware confirms bytes are on stable storage
            fos.getFD().sync();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Path getPath() {
        return path;
    }

    @Override
    public void close() throws IOException {
        lock.lock();
        try {
            fos.getFD().sync();
            fos.close();
        } finally {
            lock.unlock();
        }
    }
}