package wal;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Asynchronous (buffered) Write-Ahead Log implementation.
 * <p>
 * Writes are appended to a {@link BufferedOutputStream} which writes to the OS page cache.
 * No {@code fsync} is called on every write — the OS flushes to disk lazily.
 * <p>
 * Trade-off: Maximum throughput at the cost of durability. A crash may lose
 * the last few writes that were buffered but not yet flushed to stable storage.
 * <p>
 * For a middle ground, callers can invoke {@link #flush()} periodically
 * (e.g., every 100ms) from a background thread to bound the loss window.
 */
public class AsyncWriteAheadLog implements WriteAheadLog {

    private final Path path;
    private final BufferedOutputStream outputStream;
    private final FileOutputStream fileOutputStream;
    private final ReentrantLock lock = new ReentrantLock();

    private static final int BUFFER_SIZE = 64 * 1024; // 64 KB write buffer

    public AsyncWriteAheadLog(Path path) throws IOException {
        this.path = path;
        // Open in append mode
        this.fileOutputStream = new FileOutputStream(path.toFile(), true);
        this.outputStream = new BufferedOutputStream(fileOutputStream, BUFFER_SIZE);
    }

    @Override
    public void append(String record) throws IOException {
        byte[] bytes = (record + "\n").getBytes(StandardCharsets.UTF_8);

        lock.lock();
        try {
            outputStream.write(bytes);
            // No fsync — data sits in OS page cache / user-space buffer
            // The OS will flush to disk eventually, or caller can invoke flush()
        } finally {
            lock.unlock();
        }
    }

    /**
     * Flushes the user-space buffer to the OS page cache.
     * Does NOT call fsync — the data may still be in the OS page cache.
     * For full durability, use {@link SyncWriteAheadLog}.
     *
     * @throws IOException if flush fails
     */
    public void flush() throws IOException {
        lock.lock();
        try {
            outputStream.flush();
        } finally {
            lock.unlock();
        }
    }

    /**
     * Forces all buffered data to stable storage (calls fsync).
     * Use this sparingly — e.g., from a periodic background thread — to bound
     * the durability loss window without paying fsync cost on every write.
     *
     * @throws IOException if sync fails
     */
    public void sync() throws IOException {
        lock.lock();
        try {
            outputStream.flush();
            fileOutputStream.getFD().sync();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public Path getPath() {
        return path;
    }

    @Override
    public void close() throws IOException {
        lock.lock();
        try {
            outputStream.flush();
            fileOutputStream.getFD().sync();
            outputStream.close();
        } finally {
            lock.unlock();
        }
    }
}