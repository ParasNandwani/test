package wal;

import java.io.IOException;
import java.nio.file.Path;

/**
 * Write-Ahead Log interface.
 * <p>
 * Implementations must guarantee that {@link #append(String)} writes a complete
 * record (terminated by newline) to stable or buffered storage before returning.
 * The WAL is append-only — records are never modified or deleted in place.
 */
public interface WriteAheadLog {

    /**
     * Appends a single record (one line) to the WAL.
     * Implementations handle their own thread safety (locking).
     *
     * @param record a tab-delimited record (e.g., "PUT\tkey\tvalue")
     *               The implementation will append a newline terminator.
     * @throws IOException if the write fails
     */
    void append(String record) throws IOException;

    /**
     * Returns the file path of the underlying WAL file.
     */
    Path getPath();

    /**
     * Flushes any buffered data and closes the underlying file resources.
     *
     * @throws IOException if closing fails
     */
    void close() throws IOException;
}