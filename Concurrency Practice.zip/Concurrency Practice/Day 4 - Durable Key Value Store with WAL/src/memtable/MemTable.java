package memtable;

import java.util.Collections;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * In-memory key-value store backed by {@link ConcurrentHashMap}.
 * <p>
 * Thread Safety:
 * <ul>
 *   <li>{@link #get(String)} — lock-free (volatile read + CAS internally)</li>
 *   <li>{@link #put(String, String)} — lock-striped (ConcurrentHashMap segments)</li>
 *   <li>{@link #delete(String)} — lock-striped</li>
 * </ul>
 * <p>
 * This class has a single responsibility: fast, thread-safe in-memory key-value access.
 * It knows nothing about durability, WAL, or disk I/O.
 */
public class MemTable {

    private final ConcurrentHashMap<String, String> map;

    public MemTable() {
        this.map = new ConcurrentHashMap<>();
    }

    /**
     * Retrieves the value associated with the given key.
     *
     * @param key the key to look up
     * @return an Optional containing the value if present, or empty if not found
     */
    public Optional<String> get(String key) {
        return Optional.ofNullable(map.get(key));
    }

    /**
     * Inserts or updates a key-value pair.
     *
     * @param key   the key
     * @param value the value
     */
    public void put(String key, String value) {
        map.put(key, value);
    }

    /**
     * Removes the entry for the given key, if it exists.
     *
     * @param key the key to remove
     * @return true if the key was present and removed, false otherwise
     */
    public boolean delete(String key) {
        return map.remove(key) != null;
    }

    /**
     * Returns the number of entries currently in the MemTable.
     */
    public int size() {
        return map.size();
    }

    /**
     * Returns an unmodifiable view of all keys currently stored.
     * Useful for debugging and testing.
     */
    public Set<String> keys() {
        return Collections.unmodifiableSet(map.keySet());
    }

    /**
     * Returns an unmodifiable view of the entire map.
     * Useful for debugging and testing.
     */
    public Map<String, String> snapshot() {
        return Collections.unmodifiableMap(map);
    }

    /**
     * Clears all entries from the MemTable.
     * Used during recovery to rebuild state from WAL.
     */
    public void clear() {
        map.clear();
    }
}