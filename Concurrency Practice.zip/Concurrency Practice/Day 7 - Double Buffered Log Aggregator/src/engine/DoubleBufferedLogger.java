package engine;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Core logging orchestrator managing pointer swapping and state transitions.
 *
 * Architecture:
 * - Two LogBuffer instances (A and B) alternate roles as Active and Flush buffers.
 * - Producers acquire the lock, write to the Active buffer, and release.
 * - When the Active buffer is full OR 50ms elapses, a pointer swap occurs.
 * - A single dedicated flusher thread drains the Flush buffer to a Writer un-contended.
 * - Backpressure is enforced when BOTH buffers are saturated.
 *
 * Thread Safety:
 * - All buffer access is guarded by a single ReentrantLock.
 * - The flusher thread operates on the flush buffer OUTSIDE the lock (after draining under lock).
 * - Shutdown follows the strict 6-step protocol documented in README.md.
 */
public class DoubleBufferedLogger {

    // ─── Configuration ───────────────────────────────────────────────────────

    /**
     * Backpressure policy when both buffers are full.
     */
    public enum BackpressurePolicy {
        /** Block the producer thread until space is available */
        BLOCK,
        /** Throw LogEngineException immediately */
        THROW
    }

    // ─── State ───────────────────────────────────────────────────────────────

    private LogBuffer activeBuffer;
    private LogBuffer flushBuffer;

    private final ReentrantLock lock = new ReentrantLock();
    private final Condition notFull = lock.newCondition();       // Signaled when flush completes (space available)
    private final Condition swapReady = lock.newCondition();     // Signaled when a swap has occurred (flusher wakes)

    private volatile boolean running = true;
    private volatile boolean flushPending = false;

    private final BackpressurePolicy backpressurePolicy;
    private final Writer writer;
    private final boolean ownsWriter;  // If true, we close the writer on shutdown

    private final Thread flusherThread;
    private final ScheduledExecutorService timerExecutor;
    private final ScheduledFuture<?> timerFuture;

    // ─── Metrics ─────────────────────────────────────────────────────────────

    private final AtomicLong totalEntriesLogged = new AtomicLong(0);
    private final AtomicLong totalEntriesFlushed = new AtomicLong(0);
    private final AtomicLong totalSwaps = new AtomicLong(0);
    private final AtomicLong backpressureEvents = new AtomicLong(0);
    private volatile Throwable lastFlushError = null;

    // ─── Constants ───────────────────────────────────────────────────────────

    private static final int DEFAULT_BUFFER_CAPACITY = 1024;
    private static final long DEFAULT_FLUSH_INTERVAL_MS = 50;

    // ─── Constructors ────────────────────────────────────────────────────────

    /**
     * Creates a DoubleBufferedLogger that writes to the specified file path.
     */
    public DoubleBufferedLogger(String filePath, int bufferCapacity, BackpressurePolicy policy) throws IOException {
        this(new BufferedWriter(new FileWriter(filePath, true)), bufferCapacity, policy, true);
    }

    /**
     * Creates a DoubleBufferedLogger with default buffer capacity (1024) writing to a file.
     */
    public DoubleBufferedLogger(String filePath, BackpressurePolicy policy) throws IOException {
        this(filePath, DEFAULT_BUFFER_CAPACITY, policy);
    }

    /**
     * Creates a DoubleBufferedLogger with a custom Writer (useful for testing).
     *
     * @param writer         the output writer for flushed log entries
     * @param bufferCapacity maximum entries per buffer
     * @param policy         backpressure policy
     * @param ownsWriter     if true, shutdown() will close the writer
     */
    public DoubleBufferedLogger(Writer writer, int bufferCapacity, BackpressurePolicy policy, boolean ownsWriter) {
        this.activeBuffer = new LogBuffer(bufferCapacity);
        this.flushBuffer = new LogBuffer(bufferCapacity);
        this.backpressurePolicy = policy;
        this.writer = writer;
        this.ownsWriter = ownsWriter;

        // Start the dedicated flusher thread
        this.flusherThread = new Thread(this::flusherLoop, "LogFlusher");
        this.flusherThread.setDaemon(true);
        this.flusherThread.start();

        // Start the time-based flush timer (50ms interval)
        this.timerExecutor = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "LogFlushTimer");
            t.setDaemon(true);
            return t;
        });
        this.timerFuture = timerExecutor.scheduleAtFixedRate(
            this::timeBasedSwap,
            DEFAULT_FLUSH_INTERVAL_MS,
            DEFAULT_FLUSH_INTERVAL_MS,
            TimeUnit.MILLISECONDS
        );
    }

    // ─── Public API ──────────────────────────────────────────────────────────

    /**
     * Logs a single entry. This is the hot path called by producer threads.
     *
     * Behavior:
     * 1. Acquire lock
     * 2. Check running state (reject if shutdown)
     * 3. If active buffer is full, attempt swap
     * 4. If both buffers full, apply backpressure policy
     * 5. Add entry to active buffer
     * 6. If buffer now full, trigger swap
     * 7. Release lock
     *
     * @param entry the log entry to write
     * @throws LogEngineException if backpressure or shutdown prevents writing
     */
    public void log(String entry) {
        lock.lock();
        try {
            // Step 1: Reject if shut down
            if (!running) {
                throw LogEngineException.shutdown();
            }

            // Step 2: Handle full active buffer
            if (activeBuffer.isFull()) {
                // Try to swap if flush buffer is available
                if (flushBuffer.isEmpty()) {
                    performSwap();
                } else {
                    // Both buffers occupied — apply backpressure
                    handleBackpressure();
                }
            }

            // Step 3: Write to active buffer
            boolean added = activeBuffer.add(entry);
            if (!added) {
                // Should not happen after backpressure handling, but defensive
                throw LogEngineException.backpressure();
            }
            totalEntriesLogged.incrementAndGet();

            // Step 4: If buffer is now full, trigger swap for eager flushing
            if (activeBuffer.isFull() && flushBuffer.isEmpty()) {
                performSwap();
            }

        } finally {
            lock.unlock();
        }
    }

    /**
     * Graceful shutdown protocol — guarantees zero data loss.
     *
     * Follows the 6-step protocol:
     * 1. Set running = false (reject new entries)
     * 2. Cancel timer
     * 3. Final swap to capture residual entries
     * 4. Signal flusher for final drain
     * 5. Join flusher thread
     * 6. Close writer if owned
     */
    public void shutdown() {
        // Step 1: Stop accepting new entries
        lock.lock();
        try {
            if (!running) {
                return; // Already shut down (idempotent)
            }
            running = false;
        } finally {
            lock.unlock();
        }

        // Step 2: Cancel the time-based flush timer
        timerFuture.cancel(false);
        timerExecutor.shutdown();

        // Step 3: Final swap and signal
        lock.lock();
        try {
            // If active buffer has entries, swap to flush them
            if (!activeBuffer.isEmpty()) {
                // Wait for flush buffer to be available if needed
                // (In shutdown, we do a blocking wait since we must flush everything)
                while (!flushBuffer.isEmpty()) {
                    try {
                        notFull.await(100, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
                performSwap();
            }
        } finally {
            lock.unlock();
        }

        // Step 4: Wait for flusher to complete final drain
        try {
            flusherThread.join(5000); // 5 second timeout
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        // Step 5: If flusher is still alive, interrupt it
        if (flusherThread.isAlive()) {
            flusherThread.interrupt();
            try {
                flusherThread.join(1000);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        // Step 6: Close the writer if we own it
        if (ownsWriter) {
            try {
                writer.flush();
                writer.close();
            } catch (IOException e) {
                lastFlushError = e;
            }
        }
    }

    // ─── Metrics Access ──────────────────────────────────────────────────────

    public long getTotalEntriesLogged() { return totalEntriesLogged.get(); }
    public long getTotalEntriesFlushed() { return totalEntriesFlushed.get(); }
    public long getTotalSwaps() { return totalSwaps.get(); }
    public long getBackpressureEvents() { return backpressureEvents.get(); }
    public Throwable getLastFlushError() { return lastFlushError; }
    public boolean isRunning() { return running; }

    // ─── Internal: Pointer Swap ──────────────────────────────────────────────

    /**
     * Performs the atomic pointer swap. MUST be called while holding the lock.
     *
     * After swap:
     * - activeBuffer points to the (now empty) old flush buffer
     * - flushBuffer points to the (now full) old active buffer
     * - Flusher thread is signaled to wake up
     */
    private void performSwap() {
        LogBuffer temp = activeBuffer;
        activeBuffer = flushBuffer;
        flushBuffer = temp;
        flushPending = true;
        totalSwaps.incrementAndGet();
        swapReady.signal();
    }

    // ─── Internal: Backpressure Handling ─────────────────────────────────────

    /**
     * Applies the configured backpressure policy when both buffers are full.
     * MUST be called while holding the lock.
     */
    private void handleBackpressure() {
        backpressureEvents.incrementAndGet();

        switch (backpressurePolicy) {
            case THROW:
                throw LogEngineException.backpressure();

            case BLOCK:
                // Block until the flusher completes and space is available
                while (activeBuffer.isFull() && !flushBuffer.isEmpty()) {
                    if (!running) {
                        throw LogEngineException.shutdown();
                    }
                    try {
                        // Timed wait to avoid permanent blocking if something goes wrong
                        boolean signaled = notFull.await(100, TimeUnit.MILLISECONDS);
                        if (!signaled && !running) {
                            throw LogEngineException.shutdown();
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw LogEngineException.backpressure();
                    }
                }
                // After wait, try to swap if flush buffer is now empty
                if (activeBuffer.isFull() && flushBuffer.isEmpty()) {
                    performSwap();
                }
                break;
        }
    }

    // ─── Internal: Time-Based Swap ───────────────────────────────────────────

    /**
     * Called by the scheduled timer every 50ms to flush partial buffers.
     * Prevents data staleness during low-throughput periods.
     */
    private void timeBasedSwap() {
        if (!running) return;

        lock.lock();
        try {
            // Only swap if there's data to flush and flush buffer is available
            if (!activeBuffer.isEmpty() && flushBuffer.isEmpty()) {
                performSwap();
            }
        } finally {
            lock.unlock();
        }
    }

    // ─── Internal: Flusher Thread Loop ───────────────────────────────────────

    /**
     * The flusher thread's main loop. Waits for swap signals, then drains
     * the flush buffer to the writer un-contended.
     *
     * Lifecycle:
     * - Runs while (running || flushPending)
     * - On each iteration: wait for signal → drain under lock → write outside lock → signal notFull
     */
    private void flusherLoop() {
        List<String> drainedEntries = new ArrayList<>();

        while (running || flushPending) {
            // Phase 1: Wait for work (under lock)
            lock.lock();
            try {
                while (!flushPending && running) {
                    try {
                        swapReady.await(100, TimeUnit.MILLISECONDS);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        if (!running) return;
                    }
                }

                // Phase 2: Drain the flush buffer (under lock — fast, just ArrayList copy)
                if (!flushBuffer.isEmpty()) {
                    flushBuffer.drainTo(drainedEntries);
                }
                flushPending = false;

            } finally {
                lock.unlock();
            }

            // Phase 3: Write to disk (OUTSIDE the lock — slow I/O, no contention)
            if (!drainedEntries.isEmpty()) {
                try {
                    for (String entry : drainedEntries) {
                        writer.write(entry);
                        writer.write(System.lineSeparator());
                    }
                    writer.flush();
                    totalEntriesFlushed.addAndGet(drainedEntries.size());
                } catch (IOException e) {
                    lastFlushError = e;
                    // In production, you might implement retry logic here
                }
                drainedEntries.clear();
            }

            // Phase 4: Signal producers that space is available
            lock.lock();
            try {
                // Notice the signalAll, this is required to notify all waiting threads.
                notFull.signalAll();
            } finally {
                lock.unlock();
            }
        }

        // Final drain on exit (in case of race between running=false and last swap)
        lock.lock();
        try {
            if (!flushBuffer.isEmpty()) {
                flushBuffer.drainTo(drainedEntries);
            }
            if (!activeBuffer.isEmpty()) {
                activeBuffer.drainTo(drainedEntries);
            }
        } finally {
            lock.unlock();
        }

        if (!drainedEntries.isEmpty()) {
            try {
                for (String entry : drainedEntries) {
                    writer.write(entry);
                    writer.write(System.lineSeparator());
                }
                writer.flush();
                totalEntriesFlushed.addAndGet(drainedEntries.size());
            } catch (IOException e) {
                lastFlushError = e;
            }
            drainedEntries.clear();
        }
    }
}