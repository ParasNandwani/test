package engine;

/**
 * Custom exception for the Double-Buffered Log Aggregation Engine.
 * 
 * Encapsulates three failure modes:
 * - BACKPRESSURE: Both buffers are full; producer cannot write.
 * - SHUTDOWN: The engine has been shut down; no new entries accepted.
 * - FLUSH_FAILURE: The background flusher encountered an I/O error.
 * 
 * Using a typed Reason enum allows callers to programmatically distinguish
 * failure modes without parsing exception messages — critical for retry logic.
 */
public class LogEngineException extends RuntimeException {

    /**
     * Categorizes the type of engine failure.
     */
    public enum Reason {
        /** Both buffers saturated — producer cannot write */
        BACKPRESSURE,
        /** Engine has been shut down — no new entries accepted */
        SHUTDOWN,
        /** Background flush thread encountered an I/O error */
        FLUSH_FAILURE
    }

    private final Reason reason;

    private LogEngineException(Reason reason, String message) {
        super(message);
        this.reason = reason;
    }

    private LogEngineException(Reason reason, String message, Throwable cause) {
        super(message, cause);
        this.reason = reason;
    }

    /**
     * @return the categorized reason for this exception
     */
    public Reason getReason() {
        return reason;
    }

    // ─── Factory Methods ─────────────────────────────────────────────────────

    /**
     * Creates a backpressure exception indicating both buffers are full.
     * 
     * @return a new LogEngineException with reason BACKPRESSURE
     */
    public static LogEngineException backpressure() {
        return new LogEngineException(
            Reason.BACKPRESSURE,
            "Backpressure: both buffers are full. Producer cannot write. " +
            "Consider slowing producers or increasing buffer capacity."
        );
    }

    /**
     * Creates a shutdown exception indicating the engine is no longer accepting entries.
     * 
     * @return a new LogEngineException with reason SHUTDOWN
     */
    public static LogEngineException shutdown() {
        return new LogEngineException(
            Reason.SHUTDOWN,
            "Engine has been shut down. No new log entries are accepted."
        );
    }

    /**
     * Creates a flush failure exception wrapping the underlying I/O cause.
     * 
     * @param cause the underlying exception from the flush operation
     * @return a new LogEngineException with reason FLUSH_FAILURE
     */
    public static LogEngineException flushFailure(Throwable cause) {
        return new LogEngineException(
            Reason.FLUSH_FAILURE,
            "Flush operation failed: " + cause.getMessage(),
            cause
        );
    }

    @Override
    public String toString() {
        return String.format("LogEngineException[%s]: %s", reason, getMessage());
    }
}