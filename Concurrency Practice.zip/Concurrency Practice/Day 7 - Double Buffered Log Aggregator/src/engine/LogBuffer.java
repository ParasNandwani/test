package engine;

import java.util.ArrayList;
import java.util.List;

/**
 * Represents a single bounded memory segment for log entries.
 * 
 * This class is NOT thread-safe by itself — the orchestrator (DoubleBufferedLogger)
 * holds the lock before calling any methods on this buffer. This design avoids
 * double-locking and keeps the buffer's responsibilities minimal.
 * 
 * Capacity is fixed at construction time. Once full, add() returns false,
 * signaling the orchestrator to initiate a pointer swap.
 */
public class LogBuffer {

    private final int capacity;
    private final List<String> entries;

    public LogBuffer(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("Buffer capacity must be positive, got: " + capacity);
        }
        this.capacity = capacity;
        this.entries = new ArrayList<>(capacity);
    }

    /**
     * Attempts to add a log entry to this buffer.
     * 
     * @param entry the log entry to add (must not be null)
     * @return true if the entry was added, false if the buffer is full
     */
    public boolean add(String entry) {
        if (entries.size() >= capacity) {
            return false;
        }
        entries.add(entry);
        return true;
    }

    /**
     * Drains all entries from this buffer into the provided list, then clears the buffer.
     * This is used by the flusher thread after a pointer swap.
     * 
     * @param destination the list to drain entries into
     * @return the number of entries drained
     */
    public int drainTo(List<String> destination) {
        int count = entries.size();
        destination.addAll(entries);
        entries.clear();
        return count;
    }

    /**
     * Returns the current entries as a new list and clears the buffer.
     * Convenience method for the flusher when no external destination list exists.
     * 
     * @return a new list containing all buffered entries
     */
    public List<String> drainAndClear() {
        List<String> drained = new ArrayList<>(entries);
        entries.clear();
        return drained;
    }

    /**
     * @return true if the buffer has reached its maximum capacity
     */
    public boolean isFull() {
        return entries.size() >= capacity;
    }

    /**
     * @return true if the buffer contains no entries
     */
    public boolean isEmpty() {
        return entries.isEmpty();
    }

    /**
     * @return the current number of entries in the buffer
     */
    public int size() {
        return entries.size();
    }

    /**
     * @return the maximum number of entries this buffer can hold
     */
    public int getCapacity() {
        return capacity;
    }

    /**
     * Clears all entries without draining. Used during error recovery.
     */
    public void clear() {
        entries.clear();
    }
}