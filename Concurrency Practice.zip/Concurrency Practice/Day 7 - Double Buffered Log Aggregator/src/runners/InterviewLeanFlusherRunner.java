package runners;

import java.io.Writer;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/**
 * ╔══════════════════════════════════════════════════════════════════════╗
 * ║  INTERVIEW-READY: Double-Buffered Log Flusher (Whiteboard Version) ║
 * ╚══════════════════════════════════════════════════════════════════════╝
 *
 * This is a lean, self-contained implementation of the core swap-and-flush
 * pattern. It fits on a whiteboard and demonstrates:
 *
 *   1. Two buffers (active + flush) with pointer swapping
 *   2. Single flusher thread draining un-contended
 *   3. Backpressure when both buffers full
 *   4. Graceful shutdown with final drain
 *
 * NO external dependencies. NO configuration complexity.
 * Just the core algorithm in ~80 lines of logic.
 *
 * INTERVIEW TALKING POINTS (marked with ★):
 *   ★ Lock-held time is O(1) — just a reference swap
 *   ★ Flusher writes OUTSIDE the lock — zero contention with producers
 *   ★ Backpressure is explicit — caller knows when system is saturated
 *   ★ Shutdown drains residual entries — zero data loss guarantee
 */
public class InterviewLeanFlusherRunner {

    // ─── The Core Data Structure ─────────────────────────────────────────────

    static final int CAPACITY = 8;  // Small for demo visibility

    static List<String> activeBuffer = new ArrayList<>(CAPACITY);   // ★ Producers write here
    static List<String> flushBuffer = new ArrayList<>(CAPACITY);    // ★ Flusher drains here

    static final ReentrantLock lock = new ReentrantLock();
    static final Condition notFull = lock.newCondition();    // Space available after flush
    static final Condition hasData = lock.newCondition();    // Data ready to flush

    static volatile boolean running = true;
    static final StringWriter output = new StringWriter();  // Simulates disk

    // ─── Producer: log(entry) ────────────────────────────────────────────────

    /**
     * ★ HOT PATH: Acquires lock, writes to active buffer, triggers swap if full.
     * Lock-held time = ArrayList.add() + optional pointer swap = O(1)
     */
    static void log(String entry) {
        lock.lock();
        try {
            if (!running) throw new RuntimeException("SHUTDOWN");

            // ★ Backpressure: both buffers full → block until flusher clears space
            while (activeBuffer.size() >= CAPACITY && flushBuffer.size() > 0) {
                notFull.await();
            }

            // ★ Swap if active is full and flush is now empty
            if (activeBuffer.size() >= CAPACITY) {
                swap();
            }

            activeBuffer.add(entry);

            // ★ Eager swap: if buffer just became full, swap immediately
            if (activeBuffer.size() >= CAPACITY && flushBuffer.isEmpty()) {
                swap();
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } finally {
            lock.unlock();
        }
    }

    // ─── The Pointer Swap ────────────────────────────────────────────────────

    /**
     * ★ ATOMIC SWAP: O(1) — just two reference assignments.
     * Must be called while holding the lock.
     */
    static void swap() {
        List<String> temp = activeBuffer;
        activeBuffer = flushBuffer;
        flushBuffer = temp;
        hasData.signal();  // Wake up flusher
    }

    // ─── Consumer: Flusher Thread ────────────────────────────────────────────

    /**
     * ★ FLUSHER LOOP: Wait for data → drain under lock → write OUTSIDE lock → signal producers
     */
    static final Thread flusher = new Thread(() -> {
        List<String> localBatch = new ArrayList<>();

        while (running || !flushBuffer.isEmpty()) {
            // Phase 1: Wait and drain (under lock)
            lock.lock();
            try {
                while (flushBuffer.isEmpty() && running) {
                    boolean signaled = hasData.await(50, java.util.concurrent.TimeUnit.MILLISECONDS);
                    // ★ Time-based swap: if timed out and active buffer has data, force a swap
                    if (!signaled && !activeBuffer.isEmpty()) {
                        swap();  // Prevents data staleness in low-throughput periods
                        break;
                    }
                }
                localBatch.addAll(flushBuffer);
                flushBuffer.clear();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            } finally {
                lock.unlock();
            }

            // Phase 2: Write to "disk" (OUTSIDE lock — ★ zero contention)
            for (String entry : localBatch) {
                output.write(entry + "\n");
            }
            localBatch.clear();

            // Phase 3: Signal producers (space available)
            lock.lock();
            try {
                // Notice the signalAll, this is required to notify all waiting threads.
                notFull.signalAll();
            } finally {
                lock.unlock();
            }
        }
    }, "Flusher");

    // ─── Graceful Shutdown ───────────────────────────────────────────────────

    /**
     * ★ SHUTDOWN PROTOCOL:
     *   1. Set running = false (reject new writes)
     *   2. Final swap (capture residual entries)
     *   3. Join flusher (wait for final drain)
     */
    static void shutdown() throws InterruptedException {
        lock.lock();
        try {
            running = false;
            if (!activeBuffer.isEmpty()) {
                // ★ Wait for flusher to drain flushBuffer before swapping
                while (!flushBuffer.isEmpty()) {
                    notFull.await();
                }
                swap();  // ★ Now safe — flushBuffer was empty, swap residual entries
            }
        } finally {
            lock.unlock();
        }
        flusher.join(5000);
    }

    // ─── Demo Runner ─────────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║  Interview Lean Flusher — Double Buffer Demo                 ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
        System.out.println();

        flusher.setDaemon(true);
        flusher.start();

        // Simulate 4 producer threads writing 20 entries each
        int numProducers = 4;
        int entriesPerProducer = 20;
        Thread[] producers = new Thread[numProducers];

        for (int t = 0; t < numProducers; t++) {
            final int tid = t;
            producers[t] = new Thread(() -> {
                for (int i = 0; i < entriesPerProducer; i++) {
                    log(String.format("[P%d] msg-%02d", tid, i));
                }
            }, "Producer-" + t);
            producers[t].start();
        }

        // Wait for all producers
        for (Thread p : producers) {
            p.join();
        }

        // Graceful shutdown
        shutdown();

        // Print results
        String[] lines = output.toString().split("\n");
        System.out.println("┌─ Results:");
        System.out.printf("│  Total entries flushed: %d (expected: %d)%n",
            lines.length, numProducers * entriesPerProducer);
        System.out.println("│");
        System.out.println("│  Sample output (first 10 lines):");
        for (int i = 0; i < Math.min(10, lines.length); i++) {
            System.out.println("│    " + lines[i]);
        }
        if (lines.length > 10) {
            System.out.printf("│    ... (%d more lines)%n", lines.length - 10);
        }
        System.out.println("│");

        boolean passed = lines.length == numProducers * entriesPerProducer;
        System.out.printf("│  Verification: %s%n", passed ? "PASSED ✓" : "FAILED ✗");
        System.out.println("└─────────────────────────────────────────────");

        System.out.println();
        System.out.println("★ Key Interview Points Demonstrated:");
        System.out.println("  • Lock-held time = O(1) per log() call");
        System.out.println("  • Flusher writes to disk OUTSIDE the lock");
        System.out.println("  • Backpressure blocks producers when both buffers full");
        System.out.println("  • Shutdown performs final swap → guarantees zero data loss");
    }
}