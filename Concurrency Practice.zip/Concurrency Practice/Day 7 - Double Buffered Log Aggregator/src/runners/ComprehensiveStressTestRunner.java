package runners;

import engine.DoubleBufferedLogger;
import engine.LogEngineException;

import java.io.StringWriter;
import java.io.Writer;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Comprehensive stress test for the Double-Buffered Log Aggregation Engine.
 *
 * Simulates:
 * 1. High-concurrency producer load (16 threads, 10K entries each)
 * 2. Forced backpressure scenarios (tiny buffers + artificial flush delays)
 * 3. Shutdown-while-writing edge case
 * 4. Double-shutdown idempotency
 * 5. Post-shutdown rejection verification
 *
 * Outputs timing metrics and correctness assertions to stdout.
 */
public class ComprehensiveStressTestRunner {

    private static final String DIVIDER = "═".repeat(70);
    private static final String THIN_DIVIDER = "─".repeat(70);

    public static void main(String[] args) throws Exception {
        System.out.println(DIVIDER);
        System.out.println("  DOUBLE-BUFFERED LOG AGGREGATOR — COMPREHENSIVE STRESS TEST");
        System.out.println(DIVIDER);
        System.out.println();

        testHighThroughput();
        testBackpressureThrowPolicy();
        testBackpressureBlockPolicy();
        testShutdownWhileWriting();
        testDoubleShutdownIdempotency();
        testPostShutdownRejection();

        System.out.println();
        System.out.println(DIVIDER);
        System.out.println("  ALL TESTS PASSED ✓");
        System.out.println(DIVIDER);
    }

    // ─── Test 1: High Throughput ─────────────────────────────────────────────

    private static void testHighThroughput() throws Exception {
        System.out.println("┌─ TEST 1: High Throughput (16 threads × 10,000 entries)");

        int numThreads = 16;
        int entriesPerThread = 10_000;
        int totalExpected = numThreads * entriesPerThread;

        StringWriter output = new StringWriter();
        DoubleBufferedLogger logger = new DoubleBufferedLogger(
            output, 1024, DoubleBufferedLogger.BackpressurePolicy.BLOCK, false
        );

        CountDownLatch startGate = new CountDownLatch(1);
        CountDownLatch doneGate = new CountDownLatch(numThreads);
        AtomicLong successCount = new AtomicLong(0);

        ExecutorService pool = Executors.newFixedThreadPool(numThreads);

        long startTime = System.nanoTime();

        for (int t = 0; t < numThreads; t++) {
            final int threadId = t;
            pool.submit(() -> {
                try {
                    startGate.await(); // Synchronized start for maximum contention
                    for (int i = 0; i < entriesPerThread; i++) {
                        logger.log(String.format("[T%02d] Entry %05d", threadId, i));
                        successCount.incrementAndGet();
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } finally {
                    doneGate.countDown();
                }
            });
        }

        startGate.countDown(); // Release all threads simultaneously
        doneGate.await(30, TimeUnit.SECONDS);

        logger.shutdown();
        pool.shutdown();

        long elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - startTime);

        // Verify
        long logged = logger.getTotalEntriesLogged();
        long flushed = logger.getTotalEntriesFlushed();
        long swaps = logger.getTotalSwaps();

        System.out.printf("│  Entries logged:    %,d (expected: %,d)%n", logged, totalExpected);
        System.out.printf("│  Entries flushed:   %,d%n", flushed);
        System.out.printf("│  Pointer swaps:     %,d%n", swaps);
        System.out.printf("│  Elapsed time:      %,d ms%n", elapsedMs);
        System.out.printf("│  Throughput:        %,.0f entries/sec%n",
            (double) logged / elapsedMs * 1000);

        assert logged == totalExpected :
            "MISMATCH: logged=" + logged + " expected=" + totalExpected;
        assert flushed == totalExpected :
            "MISMATCH: flushed=" + flushed + " expected=" + totalExpected;

        System.out.println("└─ PASSED ✓");
        System.out.println(THIN_DIVIDER);
    }

    // ─── Test 2: Backpressure THROW Policy ───────────────────────────────────

    private static void testBackpressureThrowPolicy() throws Exception {
        System.out.println("┌─ TEST 2: Backpressure THROW Policy (tiny buffer, slow flush)");

        // Use a writer that intentionally delays to simulate slow disk I/O
        SlowWriter slowWriter = new SlowWriter(20); // 20ms per flush
        DoubleBufferedLogger logger = new DoubleBufferedLogger(
            slowWriter, 4, DoubleBufferedLogger.BackpressurePolicy.THROW, false
        );

        AtomicLong successCount = new AtomicLong(0);
        AtomicLong backpressureCount = new AtomicLong(0);

        // Rapidly write entries — should trigger backpressure
        int attempts = 100;
        for (int i = 0; i < attempts; i++) {
            try {
                logger.log("Entry-" + i);
                successCount.incrementAndGet();
            } catch (LogEngineException e) {
                if (e.getReason() == LogEngineException.Reason.BACKPRESSURE) {
                    backpressureCount.incrementAndGet();
                }
            }
        }

        logger.shutdown();

        System.out.printf("│  Attempts:          %d%n", attempts);
        System.out.printf("│  Successful writes: %d%n", successCount.get());
        System.out.printf("│  Backpressure hits: %d%n", backpressureCount.get());
        System.out.printf("│  Engine BP events:  %d%n", logger.getBackpressureEvents());

        assert backpressureCount.get() > 0 :
            "Expected at least one backpressure event with tiny buffer + slow writer";

        System.out.println("└─ PASSED ✓");
        System.out.println(THIN_DIVIDER);
    }

    // ─── Test 3: Backpressure BLOCK Policy ───────────────────────────────────

    private static void testBackpressureBlockPolicy() throws Exception {
        System.out.println("┌─ TEST 3: Backpressure BLOCK Policy (all entries eventually written)");

        SlowWriter slowWriter = new SlowWriter(5); // 5ms per flush
        DoubleBufferedLogger logger = new DoubleBufferedLogger(
            slowWriter, 8, DoubleBufferedLogger.BackpressurePolicy.BLOCK, false
        );

        int totalEntries = 200;
        CountDownLatch done = new CountDownLatch(1);
        AtomicLong successCount = new AtomicLong(0);

        Thread producer = new Thread(() -> {
            for (int i = 0; i < totalEntries; i++) {
                logger.log("BlockEntry-" + i);
                successCount.incrementAndGet();
            }
            done.countDown();
        });

        long start = System.nanoTime();
        producer.start();
        done.await(30, TimeUnit.SECONDS);
        logger.shutdown();
        long elapsedMs = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start);

        System.out.printf("│  Total entries:     %d%n", totalEntries);
        System.out.printf("│  Successfully logged: %d%n", successCount.get());
        System.out.printf("│  Flushed:           %d%n", logger.getTotalEntriesFlushed());
        System.out.printf("│  Backpressure waits: %d%n", logger.getBackpressureEvents());
        System.out.printf("│  Elapsed:           %d ms%n", elapsedMs);

        assert successCount.get() == totalEntries :
            "BLOCK policy should eventually write all entries";
        assert logger.getTotalEntriesFlushed() == totalEntries :
            "All entries should be flushed after shutdown";

        System.out.println("└─ PASSED ✓");
        System.out.println(THIN_DIVIDER);
    }

    // ─── Test 4: Shutdown While Writing ──────────────────────────────────────

    private static void testShutdownWhileWriting() throws Exception {
        System.out.println("┌─ TEST 4: Shutdown While Writing (graceful drain)");

        StringWriter output = new StringWriter();
        DoubleBufferedLogger logger = new DoubleBufferedLogger(
            output, 64, DoubleBufferedLogger.BackpressurePolicy.BLOCK, false
        );

        AtomicLong written = new AtomicLong(0);
        AtomicLong shutdownExceptions = new AtomicLong(0);

        // Start a producer that writes continuously
        Thread producer = new Thread(() -> {
            for (int i = 0; i < 100_000; i++) {
                try {
                    logger.log("ShutdownTest-" + i);
                    written.incrementAndGet();
                } catch (LogEngineException e) {
                    if (e.getReason() == LogEngineException.Reason.SHUTDOWN) {
                        shutdownExceptions.incrementAndGet();
                        break;
                    }
                }
            }
        });

        producer.start();
        Thread.sleep(10); // Let producer run briefly
        logger.shutdown(); // Shutdown mid-flight
        producer.join(5000);

        System.out.printf("│  Entries written before shutdown: %d%n", written.get());
        System.out.printf("│  Shutdown exceptions caught:     %d%n", shutdownExceptions.get());
        System.out.printf("│  Entries flushed to output:      %d%n", logger.getTotalEntriesFlushed());

        // All logged entries should be flushed (zero data loss)
        assert logger.getTotalEntriesFlushed() == logger.getTotalEntriesLogged() :
            "Data loss detected: logged=" + logger.getTotalEntriesLogged() +
            " flushed=" + logger.getTotalEntriesFlushed();

        System.out.println("└─ PASSED ✓");
        System.out.println(THIN_DIVIDER);
    }

    // ─── Test 5: Double Shutdown Idempotency ─────────────────────────────────

    private static void testDoubleShutdownIdempotency() throws Exception {
        System.out.println("┌─ TEST 5: Double Shutdown Idempotency");

        StringWriter output = new StringWriter();
        DoubleBufferedLogger logger = new DoubleBufferedLogger(
            output, 32, DoubleBufferedLogger.BackpressurePolicy.BLOCK, false
        );

        logger.log("Entry-1");
        logger.log("Entry-2");

        // Shutdown twice — should not throw
        logger.shutdown();
        logger.shutdown(); // Second call should be a no-op

        assert !logger.isRunning() : "Logger should not be running after shutdown";

        System.out.println("│  Double shutdown completed without exception");
        System.out.println("└─ PASSED ✓");
        System.out.println(THIN_DIVIDER);
    }

    // ─── Test 6: Post-Shutdown Rejection ─────────────────────────────────────

    private static void testPostShutdownRejection() throws Exception {
        System.out.println("┌─ TEST 6: Post-Shutdown Rejection");

        StringWriter output = new StringWriter();
        DoubleBufferedLogger logger = new DoubleBufferedLogger(
            output, 32, DoubleBufferedLogger.BackpressurePolicy.BLOCK, false
        );

        logger.log("Before-Shutdown");
        logger.shutdown();

        boolean rejected = false;
        try {
            logger.log("After-Shutdown");
        } catch (LogEngineException e) {
            if (e.getReason() == LogEngineException.Reason.SHUTDOWN) {
                rejected = true;
            }
        }

        assert rejected : "Post-shutdown log() should throw SHUTDOWN exception";

        System.out.println("│  Post-shutdown write correctly rejected with SHUTDOWN reason");
        System.out.println("└─ PASSED ✓");
        System.out.println(THIN_DIVIDER);
    }

    // ─── Helper: Slow Writer ─────────────────────────────────────────────────

    /**
     * A Writer that introduces artificial delay on flush() to simulate slow disk I/O.
     * Used to deterministically trigger backpressure scenarios.
     */
    private static class SlowWriter extends Writer {
        private final int flushDelayMs;
        private final StringBuilder buffer = new StringBuilder();

        SlowWriter(int flushDelayMs) {
            this.flushDelayMs = flushDelayMs;
        }

        @Override
        public void write(char[] cbuf, int off, int len) {
            buffer.append(cbuf, off, len);
        }

        @Override
        public void flush() {
            try {
                Thread.sleep(flushDelayMs);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }

        @Override
        public void close() {
            // No-op for test
        }

        public String getOutput() {
            return buffer.toString();
        }
    }
}