# Day 7: Double-Buffered Log Aggregation Engine

---

## The Interview Question

> *"Design a high-throughput log aggregation engine where 16 producer threads write log entries and a background flusher writes batches to disk. Producers must never block on I/O. What happens when the flusher can't keep up?"*

**What the interviewer is testing:**
- Can you separate the fast path (buffer add) from the slow path (disk I/O)?
- Do you understand double-buffering and why pointer swap is O(1)?
- Can you articulate backpressure strategies (BLOCK vs THROW vs DROP)?
- Do you know the correct graceful shutdown sequence and why ordering matters?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: The Problem Space](#part-1-the-problem-space)
2. [Part 2: The Core Insight — Double-Buffering](#part-2-the-core-insight--double-buffering)
3. [Part 3: What Happens When Things Go Wrong — Backpressure](#part-3-what-happens-when-things-go-wrong--backpressure)
4. [Part 4: Lifecycle — Graceful Shutdown](#part-4-lifecycle--graceful-shutdown)
5. [Part 5: Synchronization Design — Why ReentrantLock?](#part-5-synchronization-design--why-reentrantlock)
6. [Part 6: Putting It All Together — Architecture](#part-6-putting-it-all-together--architecture)
7. [Part 7: Interview Playbook](#part-7-interview-playbook)
8. [How to Run](#how-to-run)

---

## Part 1: The Problem Space

### What is a Log Aggregation Engine?

Every application generates logs — debug messages, error traces, audit records, metric events. In a distributed system, a single node might produce **millions of log entries per second**. These entries need to be collected (aggregated) and written to persistent storage (disk, network, or a downstream service).

A **Log Aggregation Engine** is the component responsible for:
1. Accepting log entries from application threads (producers)
2. Batching them efficiently in memory
3. Flushing batches to a durable destination (disk/network)

### Why Can't We Just Write Directly to Disk?

The naive approach looks like this:

```java
// Naive: every thread writes directly
synchronized void log(String entry) {
    fileWriter.write(entry + "\n");
    fileWriter.flush();
}
```

This has two catastrophic problems at scale:

**Problem 1: I/O is slow.** A disk write takes 1–10ms. If your lock is held for the entire duration of the I/O operation, every producer thread is serialized. With 16 producer threads, you've turned a concurrent system into a sequential one.

**Problem 2: Contention destroys throughput.** When multiple threads compete for the same lock that guards a slow operation, they spend most of their time *waiting* rather than *working*. CPU cores sit idle while threads are parked.

```
Thread-1: [===WAIT===][write][===WAIT===][write]
Thread-2: [===WAIT========][write][===WAIT===]
Thread-3: [===WAIT==============][write][====]
                    ↑
        Lock held during slow I/O = everyone waits
```

### The Insight: Separate the Fast Path from the Slow Path

What if we could make the producer's critical section extremely fast (nanoseconds) and move the slow I/O operation to a separate thread that doesn't block anyone?

This is exactly what **double-buffering** achieves.

---

## Part 2: The Core Insight — Double-Buffering

### The Intuition

Imagine two buckets and a single drain pipe:
- **Bucket A** (the Active Buffer): All producers pour water (log entries) into this bucket. Pouring is instant.
- **Bucket B** (the Flush Buffer): Connected to the drain pipe (disk I/O). Water flows out slowly.

When Bucket A fills up, you **swap** the two buckets:
- Bucket A (now full) becomes the new Flush Buffer → it drains slowly via the pipe
- Bucket B (now empty) becomes the new Active Buffer → producers immediately start filling it

The producers never wait for the drain. The drain never competes with the producers. They operate on **different** buckets.

### How It Works Step by Step

```
INITIAL STATE:
┌─────────────────┐         ┌─────────────────┐
│  ACTIVE BUFFER  │         │  FLUSH BUFFER   │
│  [entry, entry] │         │  [empty]        │
│  (producers     │         │  (flusher       │
│   write here)   │         │   idle)         │
└─────────────────┘         └─────────────────┘

──── Active buffer fills up ────

AFTER SWAP:
┌─────────────────┐         ┌─────────────────┐
│  ACTIVE BUFFER  │         │  FLUSH BUFFER   │
│  [empty]        │         │  [entry, entry] │
│  (was flush;    │         │  (was active;   │
│   producers     │         │   flusher now   │
│   write here)   │         │   drains this)  │
└─────────────────┘         └─────────────────┘
```

### The Pointer Swap in Code

The swap itself is just two reference reassignments — it takes nanoseconds:

```java
lock.lock();
try {
    // The entire critical section is just these two lines:
    LogBuffer temp = activeBuffer;
    activeBuffer = flushBuffer;   // Producers now write to the old flush buffer (empty)
    flushBuffer = temp;           // Flusher will drain the old active buffer (full)
    swapReady.signal();           // Wake up the flusher thread
} finally {
    lock.unlock();
}
```

**Key realization:** The lock is held only during the swap (nanoseconds), NOT during the flush (milliseconds). This is the fundamental difference from the naive approach.

### Two Swap Triggers

The swap should happen when:

1. **Capacity-based**: The active buffer reaches its maximum entry count (e.g., 1024 entries). This ensures we don't run out of memory.

2. **Time-based (50ms window)**: Even if the buffer isn't full, we flush every 50ms. This prevents data staleness — if only 3 entries arrive in a second, we don't want them sitting in memory for minutes.

Why do we need both?
- Capacity-only: Low-throughput periods would leave stale data in memory indefinitely.
- Time-only: High-throughput bursts would overflow the buffer before the timer fires.

### Performance Characteristics

| Metric | Naive Single-Buffer | Double-Buffered |
|--------|-------------------|-----------------|
| Lock-held time | O(flush duration) = milliseconds | O(swap) = nanoseconds |
| Producer blocking | Entire I/O duration | Only during swap (~50ns) |
| Flusher contention | Competes with all producers | Zero — operates on its own buffer |
| Throughput ceiling | ~10K entries/sec | ~500K+ entries/sec |

---

## Part 3: What Happens When Things Go Wrong — Backpressure

### The Failure Scenario

Everything above works beautifully *as long as the flusher can keep up*. But what happens when it can't?

Picture this timeline:
1. Active Buffer A fills up → swap → A becomes Flush Buffer, B becomes Active Buffer
2. Flusher starts draining A to disk (slow — takes 200ms because disk is busy)
3. Meanwhile, producers fill up Buffer B (it's now the Active Buffer)
4. Buffer B is now full. We want to swap. But Buffer A **isn't empty yet** — the flusher is still working!
5. **Both buffers are full.** A new producer arrives. Where does its entry go?

This is the **backpressure** moment. The system is saturated. We must make a choice.

### The Three Strategies

**Strategy 1: BLOCK (Wait until space is available)**

```java
while (activeBuffer.isFull() && !flushBuffer.isEmpty()) {
    notFull.await();  // Park this thread until flusher signals space
}
```

- The producer thread goes to sleep until the flusher finishes draining and signals `notFull`.
- **Pros**: Zero data loss. Every entry is guaranteed to be written.
- **Cons**: If the flusher is very slow, producers pile up waiting. This can cascade — if producers are also serving user requests, those requests stall. In the worst case, your entire application freezes waiting for a log flush.
- **Best for**: Critical audit logs, financial transactions, any data you absolutely cannot lose.

**Strategy 2: THROW (Reject with an exception)**

```java
if (activeBuffer.isFull() && !flushBuffer.isEmpty()) {
    throw LogEngineException.backpressure();
}
```

- The producer immediately gets an exception. It can decide what to do: retry, drop the entry, alert an operator, etc.
- **Pros**: System stays responsive. The caller maintains control. No risk of cascading latency.
- **Cons**: Data might be lost if the caller doesn't handle the exception. Adds complexity to callers.
- **Best for**: High-throughput metric streams, debug logs, situations where losing some entries is acceptable.

**Strategy 3: DROP (Silently discard)**

```java
if (activeBuffer.isFull() && !flushBuffer.isEmpty()) {
    droppedEntries.incrementAndGet();  // Just count it
    return;  // Entry is lost
}
```

- The entry vanishes. A counter tracks how many were dropped.
- **Pros**: Maximum throughput. Zero impact on producers. Simple.
- **Cons**: Silent data loss. Only discoverable via monitoring the drop counter.
- **Best for**: Extremely high-volume debug/trace logs where completeness isn't required.

### Our Implementation Choice

We implement **BLOCK** and **THROW** as a configurable `BackpressurePolicy` enum. The caller decides at construction time:

```java
// For critical audit logs — never lose data, accept potential slowdown
var logger = new DoubleBufferedLogger(writer, 1024, BackpressurePolicy.BLOCK, true);

// For debug metrics — stay fast, let caller handle overflow
var logger = new DoubleBufferedLogger(writer, 1024, BackpressurePolicy.THROW, true);
```

### Why This Matters in an Interview

Discussing backpressure signals that you understand:
- Unbounded queues are a production anti-pattern (they just move the OOM crash into the future)
- Every bounded buffer must have an explicit "what happens when full?" policy
- The trade-off between data durability and system responsiveness is a design *choice*, not an accident

---

## Part 4: Lifecycle — Graceful Shutdown

### The Problem

Your application is shutting down. Maybe it's a rolling deployment, maybe it's responding to SIGTERM. You call `logger.shutdown()`.

But right now:
- 3 threads are in the middle of calling `log()` — they hold the lock and are about to add entries
- The active buffer has 47 entries that haven't been swapped to the flusher yet
- The flush buffer has 200 entries that the flusher is still writing to disk

If you just kill everything (`System.exit()`), those 247+ entries are gone forever. For an audit system, that's a compliance violation. For a metrics system, that's a gap in your dashboard.

### The Correct Shutdown Sequence

Each step depends on the previous one completing. Reordering causes bugs.

**Step 1: Set `running = false`**

```java
running = false;  // volatile write — instantly visible to all threads
```

This does NOT interrupt anyone. It simply means: the next time a producer calls `log()`, they'll see `running == false` and get a `SHUTDOWN` exception instead of writing. We're "closing the door" to new arrivals.

*Why first?* If we swapped first, new entries could arrive *after* our "final" swap, and we'd lose them.

**Step 2: Wait for in-flight writers to finish**

Any thread currently inside `log()` (between `lock.lock()` and `lock.unlock()`) must be allowed to complete its `buffer.add()`. We don't interrupt them — they'll finish in nanoseconds and exit naturally.

*How?* We simply acquire the lock ourselves. If someone holds it, we wait. Once we have it, we know no one is mid-write.

**Step 3: Wait for flush buffer to drain**

Before we do a final swap, we must ensure the flush buffer is empty. Otherwise we'd swap a non-empty flush buffer back into the active position, corrupting the data flow.

```java
while (!flushBuffer.isEmpty()) {
    notFull.await();  // Wait for flusher to finish current batch
}
```

**Step 4: Final pointer swap**

```java
if (!activeBuffer.isEmpty()) {
    swap();  // Move residual entries to flush buffer for draining
}
```

This captures any entries that were added between "last regular swap" and "running = false".

**Step 5: Wait for flusher thread to complete**

```java
flusherThread.join(5000);  // Give it 5 seconds to drain the final batch
```

The flusher sees `flushPending = true` (from the swap), drains the last buffer, and exits its loop because `running == false`.

**Step 6: Close file resources**

```java
writer.flush();
writer.close();
```

Only AFTER the flusher is done writing. If we closed early, the flusher would get an IOException.

### What Goes Wrong If You Skip Steps

| Skipped Step | Consequence |
|---|---|
| Skip Step 1 | New entries arrive after "final" flush → data loss |
| Skip Step 3 | Swap overwrites non-empty flush buffer → entries lost or duplicated |
| Skip Step 4 | Residual entries in active buffer never reach disk → data loss |
| Skip Step 5 | Writer closed while flusher still writing → IOException |
| Reorder 1↔4 | Race: entries arrive between swap and running=false → lost |

### Idempotency

Calling `shutdown()` twice should be safe (no exception, no double-close):

```java
if (!running) return;  // Already shut down — no-op
```

---

## Part 5: Synchronization Design — Why ReentrantLock?

### The Coordination Challenge

We have multiple concurrent actors that need to coordinate:
- **N producer threads**: Each wants to add an entry to the active buffer
- **1 flusher thread**: Needs to know when a swap happened so it can drain
- **1 timer thread**: Fires every 50ms to trigger time-based swaps
- **shutdown() caller**: Needs to orchestrate the final drain

We need a synchronization mechanism that supports:
1. Mutual exclusion (only one thread modifies buffer state at a time)
2. Multiple wait conditions (producers wait for "space available"; flusher waits for "data ready")
3. Timed waits (flusher shouldn't block forever if no data arrives)
4. Fine-grained control over when to swap (inspect buffer state, then decide)

### Option A: `synchronized` + `wait()/notify()`

```java
synchronized void log(String entry) {
    while (activeBuffer.isFull() && !flushBuffer.isEmpty()) {
        wait();  // Only ONE wait condition available
    }
    // ...
}
```

**Limitations:**
- Only one `wait()` condition per monitor. We can't separately signal "space available" vs "data ready to flush" — a `notifyAll()` wakes EVERYONE, including threads that can't proceed yet (spurious wakeups waste CPU).
- No `tryLock()` or timed lock acquisition.
- No fairness control (starvation possible under high contention).

### Option B: `ReentrantLock` + Multiple `Condition` Objects ✓

```java
ReentrantLock lock = new ReentrantLock();
Condition notFull = lock.newCondition();    // Signaled when space becomes available
Condition swapReady = lock.newCondition();  // Signaled when data is ready to flush
```

**Advantages:**
- **Multiple conditions**: Producers wait on `notFull`; flusher waits on `swapReady`. Signals are targeted — only the right threads wake up.
- **Timed waits**: `notFull.await(100, TimeUnit.MILLISECONDS)` — prevents permanent blocking during shutdown edge cases.
- **tryLock()**: Useful for non-blocking diagnostics or shutdown probing.
- **Fairness option**: `new ReentrantLock(true)` prevents starvation (though we use unfair for throughput).
- **Explicit lock/unlock**: Makes the critical section boundaries visible in code review.

### Why Not Lock-Free Structures?

You might ask: "Why not use `ConcurrentLinkedQueue` or `AtomicReference` for lock-free operation?"

- `ConcurrentLinkedQueue` is **unbounded** — no backpressure possible. It just grows until OOM.
- Lock-free swap of two buffers requires complex CAS loops that are harder to reason about and don't provide the "inspect state then act" atomicity we need.
- Our lock-held time is already nanoseconds (just `ArrayList.add()` + reference swap). The overhead of the lock itself is negligible compared to the benefit of simple, correct code.

### Summary: Our Synchronization Design

```
┌────────────────────────────────────────────────┐
│  ReentrantLock (single lock for all state)     │
│                                                │
│  Condition: notFull                            │
│    - Producers await() when both buffers full  │
│    - Flusher signalAll() after draining        │
│                                                │
│  Condition: swapReady                          │
│    - Flusher await() until swap happens        │
│    - Swap operation signal() to wake flusher   │
│                                                │
│  volatile boolean running                      │
│    - Cheapest visibility for shutdown flag     │
│    - Checked at log() entry (fast rejection)   │
└────────────────────────────────────────────────┘
```

---

## Part 6: Putting It All Together — Architecture

### System Diagram

```
┌──────────────────────────────────────────────────────────────────────┐
│                        DoubleBufferedLogger                          │
│                                                                      │
│  ┌─────────────────┐     pointer swap     ┌─────────────────┐        │
│  │   Buffer A      │◄────────────────────►│   Buffer B      │        │
│  │   (active)      │                      │   (flushing)    │        │
│  │   capacity=1024 │                      │   capacity=1024 │        │
│  └────────┬────────┘                      └────────┬────────┘        │
│           │                                        │                 │
│     N Producer Threads                      1 Flusher Thread         │
│           │                                        │                 │
│     1. lock.lock()                          1. await swapReady       │
│     2. check running                        2. lock → drain buffer   │
│     3. check backpressure                   3. unlock                │
│     4. activeBuffer.add(entry)              4. write to disk (slow)  │
│     5. if full → swap                       5. lock → signal notFull │
│     6. lock.unlock()                        6. unlock                │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │  ScheduledExecutor (50ms) — time-based swap for data freshness │  │
│  └────────────────────────────────────────────────────────────────┘  │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │  Metrics: totalLogged, totalFlushed, totalSwaps, bpEvents      │  │
│  └────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────┘
```

### Dataflow Sequence (Normal Operation)

```
Producer calls log("entry-42")
    │
    ▼
lock.lock()
    │
    ▼
Is running? ──NO──► throw SHUTDOWN
    │ YES
    ▼
Is activeBuffer full? ──NO──► activeBuffer.add("entry-42") → unlock → done
    │ YES
    ▼
Is flushBuffer empty? ──YES──► swap() → activeBuffer.add("entry-42") → unlock
    │ NO
    ▼
Both full! Apply backpressure policy:
    ├── BLOCK: await notFull → retry from "Is activeBuffer full?"
    └── THROW: throw LogEngineException.backpressure()
```

### File Structure & Responsibilities

```
src/
├── engine/
│   ├── DoubleBufferedLogger.java
│   │     └── The orchestrator. Manages swap timing, backpressure,
│   │         shutdown protocol, and flusher thread lifecycle.
│   │
│   ├── LogBuffer.java
│   │     └── A simple bounded ArrayList<String> wrapper.
│   │         NOT thread-safe — relies on the orchestrator's lock.
│   │         Provides: add(), drainTo(), isFull(), isEmpty(), size()
│   │
│   └── LogEngineException.java
│         └── Custom RuntimeException with a Reason enum.
│             Factory methods: backpressure(), shutdown(), flushFailure(cause)
│             Allows callers to programmatically distinguish failure modes.
│
└── runners/
    ├── ComprehensiveStressTestRunner.java
    │     └── 6 stress tests: high throughput, BLOCK policy, THROW policy,
    │         shutdown-while-writing, double-shutdown, post-shutdown rejection.
    │         Uses CountDownLatch for synchronized starts, SlowWriter for
    │         deterministic backpressure triggering.
    │
    └── InterviewLeanFlusherRunner.java
          └── ~80 lines of core logic. Self-contained, no imports from engine/.
              Demonstrates the exact same pattern in whiteboard-ready form.
              Ideal for walking an interviewer through the design live.
```

---

## How to Run

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day7:run                                                        # Runs ComprehensiveStressTestRunner
./gradlew :day7:run -PmainClass=runners.InterviewLeanFlusherRunner         # Runs lean interview version
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on any `main()` method directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out runners.ComprehensiveStressTestRunner
```

Expected output — all 6 tests pass:
- **Test 1**: 160,000 entries logged and flushed across 16 threads (~500K entries/sec)
- **Test 2**: Backpressure THROW correctly rejects when saturated
- **Test 3**: Backpressure BLOCK eventually writes all entries (zero loss)
- **Test 4**: Shutdown mid-flight drains all logged entries (logged == flushed)
- **Test 5**: Double shutdown is idempotent (no exception)
- **Test 6**: Post-shutdown writes are rejected with SHUTDOWN reason

### Run the Interview-Ready Lean Version

```bash
java -cp out runners.InterviewLeanFlusherRunner
```

This demonstrates the core pattern with 4 producers, 8-entry buffers (small for visibility), and verifies all 80 entries are flushed correctly.

---

## Part 7: Interview Playbook

### Key Design Decisions to Articulate

| Decision | Rationale |
|----------|-----------|
| `ReentrantLock` over `synchronized` | Multiple `Condition` objects, timed waits, explicit critical sections |
| Single flusher thread (not a pool) | Guarantees write ordering, simpler state reasoning, no flush-flush races |
| 50ms time-window flush | Prevents data staleness in low-throughput periods without hurting high-throughput |
| Configurable backpressure | Shows you understand both blocking and non-blocking paradigms |
| `volatile boolean running` | Cheapest visibility guarantee; checked before lock acquisition for fast-path rejection |
| No third-party dependencies | Pure JDK — demonstrates understanding of primitives, interview-appropriate |

### Common Follow-Up Questions & Answers

**Q: "Why not just use a ConcurrentLinkedQueue?"**

A: ConcurrentLinkedQueue is unbounded — it provides no backpressure and will grow until OOM under sustained overload. It also requires iteration to drain (O(n) under contention), while our swap is O(1). Double-buffering gives bounded memory with explicit saturation handling.

**Q: "What if the flusher thread dies?"**

A: We wrap all flush I/O in try/catch. On failure, we store the error in `lastFlushError` and the system degrades gracefully — backpressure kicks in (both buffers fill up because nothing is draining), and producers either block or get an exception. We never silently lose data.

**Q: "What's the maximum lock-held time?"**

A: `ArrayList.add()` (amortized O(1)) plus potentially a pointer swap (two reference assignments + one Condition signal). Completely independent of I/O latency. Measured in nanoseconds.

**Q: "How would you make this distributed?"**

A: The flusher's write destination becomes a network call (e.g., Kafka producer, gRPC stream). The same double-buffer pattern works — you're just replacing `fileWriter.write()` with `kafkaProducer.send()`. Backpressure still applies (network can be slow too). You'd add a retry queue between the buffer and the network call.

**Q: "How do you test concurrency correctness?"**

A: Three techniques:
1. `CountDownLatch` for synchronized thread starts (maximum contention)
2. `SlowWriter` (artificial delay) to deterministically trigger backpressure
3. Assertion: `totalEntriesLogged == totalEntriesFlushed` after shutdown (zero data loss invariant)

**Q: "What about log ordering?"**

A: Within a single swap batch, order is preserved (ArrayList maintains insertion order). Across batches from different threads, ordering is interleaved — this is inherent to any concurrent system. If strict global ordering is required, entries would need timestamps and a merge step downstream.

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
