# Day 2: Advanced Synchronization and Memory Management

A production-grade study of low-latency system patterns in Java, contrasting naive blocking implementations against advanced lock-free and memory-optimized designs.

---

## The Interview Question

> *"Design a metrics ingestion pipeline that can process 50 million events per second with zero GC pauses. Reads to the metrics registry happen 10x more often than writes. How would you optimize for both the write path and the read path?"*

**What the interviewer is testing:**
- Do you know when `volatile` is too expensive and what's cheaper (lazySet, memory barriers)?
- Can you design a lock-free SPSC queue with pre-allocated memory?
- Do you understand StampedLock optimistic reads and when they beat ReadWriteLock?
- Can you eliminate GC pressure on a hot path?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: Revise from Day 1 — Assumed Knowledge](#part-1-revise-from-day-1--assumed-knowledge)
2. [Part 2: New Concepts — Memory Barriers and lazySet](#part-2-new-concepts--memory-barriers-and-lazyset)
3. [Part 3: Architecture Overview](#part-3-architecture-overview)
4. [Part 4: StampedLock Optimistic Reads](#part-4-stampedlock-optimistic-reads)
5. [Part 5: Lock-Free SPSC Ring Buffer](#part-5-lock-free-spsc-ring-buffer)
6. [Part 6: GC Pressure and Pre-allocation](#part-6-gc-pressure-and-pre-allocation)
7. [Part 7: Benchmarking Results Interpretation](#part-7-benchmarking-results-interpretation)
8. [Part 8: Interview Discussion Points](#part-8-interview-discussion-points)
9. [How to Run](#how-to-run)
10. [Directory Structure](#directory-structure)
11. [Further Reading](#further-reading)

---

## Part 1: Revise from Day 1 — Assumed Knowledge

Before proceeding, ensure you're comfortable with these foundational concepts from **Day 1's Prerequisites section**. Each row is a one-line refresher — if anything feels unclear, go back to the Day 1 README and re-read that section before continuing.

| # | Concept | One-Line Refresher | Day 1 Section |
|---|---------|-------------------|---------------|
| 1 | **Cache hierarchy** | L1(~1ns) → L2(~5ns) → L3(~10-40ns) → DRAM(~100ns); each core has private L1/L2, shared L3 | Section 2.2 |
| 2 | **Cache lines** | 64 bytes (x86) / 128 bytes (Apple M); minimum unit the CPU moves between cache levels | Section 2.2 |
| 3 | **MESI protocol** | Hardware ensures cache coherence via Modified/Exclusive/Shared/Invalid states; a write by one core invalidates all other cores' copies of that line | Section 2.3 |
| 4 | **False sharing** | Independent variables on the same cache line → unnecessary MESI invalidation traffic; fix by padding to separate cache lines | Section 2.7 |
| 5 | **CAS (Compare-And-Swap)** | Atomic CPU instruction: read-compare-write in one step; on failure, retry in a loop; costs ~20-40ns | Section 2.5 |
| 6 | **Context switches** | Saving/restoring thread state when OS parks/unparks threads; costs ~1-10µs; triggered by lock contention | Section 2.4 |
| 7 | **JMM Happens-before** | A write by Thread A is only guaranteed visible to Thread B if connected by a happens-before edge (e.g., lock release → lock acquire) | Section 2.6 |
| 8 | **volatile keyword** | Guarantees visibility (no stale cache reads) + ordering fence (no reordering across it); volatile write costs ~20-40ns | Section 2.6 |

### How Day 1 Concepts Connect to Day 2

```
Day 1 Foundation                          Day 2 Builds On It
═══════════════                          ═══════════════════

Cache lines + MESI ──────────────────►  False sharing prevention in ring buffer
                                         (padding producer/consumer sequences)

volatile + JMM ──────────────────────►  Memory barriers (4 types) + lazySet()
                                         (understanding WHICH barrier volatile uses
                                          and when you can use a cheaper one)

CAS + lock-free definition ──────────►  StampedLock optimistic reads (avoids CAS entirely)
                                         SPSC ring buffer (avoids both locks AND CAS)

Context switches + lock overhead ────►  Why pre-allocated ring buffer >> BlockingQueue
                                         (eliminating the lock that causes parking)
```

---

## Part 2: New Concepts — Memory Barriers and lazySet

This section introduces concepts that **build on** Day 1's foundation. These are the "next level up" — you need Day 1's understanding of volatile, caches, and CAS to fully appreciate why these techniques matter.

---

### Memory Barriers (Fences) — Going Deeper Than volatile

#### Prerequisites from Day 1
- You know that `volatile` provides visibility + ordering 
- You know that CPUs have store buffers and can reorder writes
- You know what cache-line invalidation costs (~40-80ns)

#### What Are Memory Barriers?

In Day 1, we said `volatile` "prevents reordering." But HOW does it prevent reordering? The answer is **memory barriers** (also called "fences") — special CPU instructions that constrain the order in which memory operations become visible.

A memory barrier tells the CPU: **"You CANNOT reorder operations across this line."**

Think of it like a **checkpoint on a highway**:
- Instructions (cars) before the checkpoint must ALL complete before any instruction after the checkpoint can proceed
- It enforces an ORDER that the hardware would otherwise violate for performance

#### The Four Barrier Types

There are 4 types, named by what they prevent from being reordered:

##### 1. StoreStore Barrier ("my writes stay in order")

```
write A        ← these writes...
write B
─── StoreStore ───   ← ...must be visible BEFORE...
write C        ← ...these writes
write D
```

**Plain English**: "Everything I wrote above this line must be flushed/visible to other cores before anything I write below this line becomes visible."

**Real example in our code**: Producer writes data into a buffer slot, then increments the sequence number. StoreStore ensures the data write is visible BEFORE the sequence increment. Otherwise, consumer might see "new sequence" but read stale data.

**Cost**: ~1-2 nanoseconds (cheap!)

##### 2. LoadLoad Barrier ("my reads stay in order")

```
read X         ← these reads...
read Y
─── LoadLoad ───     ← ...must complete BEFORE...
read Z         ← ...these reads
read W
```

**Plain English**: "Everything I read above this line must be actually loaded from memory before I read anything below this line."

**Real example in our code**: Consumer reads the producer's sequence number (to check if new data is available), then reads the actual data. LoadLoad ensures it sees the sequence FIRST, then reads the data that corresponds to that sequence.

**Cost**: ~5-10 nanoseconds (moderate)

##### 3. StoreLoad Barrier ("my writes are visible before my reads") — THE EXPENSIVE ONE

```
write X
write Y
─── StoreLoad ───    ← FULL FENCE — most expensive barrier
read Z
read W
```

**Plain English**: "ALL my writes above must be flushed to main memory and visible to all cores BEFORE I perform any reads below."

**Why it's expensive**: Forces a complete flush of the CPU's write buffer + waits for acknowledgment from all other cores. It's essentially saying "synchronize the entire memory state NOW."

**Cost**: ~20-40 nanoseconds (expensive!)

**When it's needed**: When the SAME memory location can be written by multiple threads. You need to make sure your write is globally visible before you read (to avoid lost updates).

##### 4. LoadStore Barrier ("my reads complete before my writes")

```
read X
read Y
─── LoadStore ───
write Z
write W
```

**Plain English**: "All my reads above must have fetched their values before any writes below can begin."

**Cost**: ~1-2 nanoseconds (cheap)

#### What Java Operations Generate Which Barriers?

This is the critical mapping that connects Java code to hardware behavior:

| Java Operation | Barrier Generated | Cost | Day 1 Equivalent |
|---------------|-------------------|------|-------------------|
| Plain `x = 5` | None | ~0.5ns | — |
| Plain `y = x` | None | ~0.5ns | — |
| `volatile x = 5` (volatile write) | StoreStore + **StoreLoad** | ~20-40ns | Day 1 covered the cost; now you know WHY |
| `y = volatile x` (volatile read) | LoadLoad + LoadStore | ~5-10ns | Day 1 covered the cost; now you know WHY |
| `AtomicLong.lazySet(5)` | **StoreStore only** (no StoreLoad!) | ~1-2ns | NEW — Day 2 concept |
| `AtomicLong.get()` | Same as volatile read | ~5-10ns | — |
| `AtomicLong.compareAndSet()` | Full fence (StoreLoad) | ~20-40ns | Day 1 covered CAS cost |

**Key insight for Day 2**: Now you can see WHY `volatile` costs ~20-40ns for writes — it includes the expensive StoreLoad barrier. And you can see that `lazySet()` gets ordering (StoreStore) without paying for full visibility (StoreLoad). This distinction is the foundation of our SPSC ring buffer's performance.

#### Why This Matters: Instruction Reordering Example

Modern CPUs don't execute instructions in the order you wrote them — they reorder for performance:

```java
// You wrote:                     // CPU might execute as:
data = 42;        // (A)          ready = true;      // (B) ← moved up!
ready = true;     // (B)          data = 42;         // (A)
```

For a **single thread**, this is fine — the CPU guarantees the result looks the same. But for **multiple threads**, reordering causes bugs:

```java
// Thread 1:                    // Thread 2:
data = 42;        // (A)        if (ready) {         // (C)
ready = true;     // (B)            print(data);     // (D) → might print 0!
                                }
```

Without a StoreStore barrier between (A) and (B), the CPU might make `ready = true` visible to Thread 2 BEFORE `data = 42`. Thread 2 sees `ready == true` but `data` is still 0.

**The fix**: A `volatile` write on `ready` inserts StoreStore + StoreLoad after (B), ensuring (A) is visible before (B) is visible.

---

### lazySet() — The Secret Weapon

#### Prerequisites
- You understand the 4 barrier types above (especially StoreStore vs StoreLoad)
- You understand that `volatile write` = StoreStore + StoreLoad (expensive)

#### What is lazySet()?

`lazySet()` is a method on `AtomicLong`/`AtomicInteger` that provides:
- ✅ **Ordering guarantee** (StoreStore barrier — writes before it are visible before it)
- ❌ Does NOT provide **immediate visibility** (no StoreLoad barrier)

```
┌──────────────────────────────────────────────────────────────┐
│              lazySet() vs volatile write                     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  volatile write (AtomicLong.set()):                          │
│  ┌──────────────────────────────────────────────┐            │
│  │ 1. Write the value                           │            │
│  │ 2. StoreStore barrier (order my writes)      │            │
│  │ 3. StoreLoad barrier (flush + notify cores)  │ ← SLOW     │
│  │                                              │            │
│  │ Total: ~20-40ns                              │            │
│  └──────────────────────────────────────────────┘            │
│                                                              │
│  lazySet():                                                  │
│  ┌──────────────────────────────────────────────┐            │
│  │ 1. Write the value                           │            │
│  │ 2. StoreStore barrier (order my writes)      │ ← FAST     │
│  │    (no StoreLoad — don't flush immediately)  │            │
│  │                                              │            │
│  │ Total: ~1-2ns                                │            │
│  └──────────────────────────────────────────────┘            │
│                                                              │
│  The value WILL become visible to other cores eventually     │
│  (within a few nanoseconds), just not instantly.             │
│  The other thread's volatile READ will pick it up.           │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

#### When is lazySet() Sufficient?

When only **ONE thread** ever writes to that variable. In SPSC (Single-Producer Single-Consumer):
- Only the producer writes `producerSequence`
- Only the consumer writes `consumerSequence`

Since there's no competing writer, we don't need the expensive "make sure my write is globally visible RIGHT NOW" guarantee (StoreLoad). The consumer will eventually see the new value when it does its next volatile read (which triggers LoadLoad).

**Why we don't need StoreLoad**: StoreLoad prevents lost updates when multiple threads write to the SAME variable. If only one thread writes, there are no competing writes to lose — so StoreStore alone is sufficient for ordering.

**Savings**: Every publish operation saves ~20-38ns compared to a volatile write. At 50M events/sec, that's 1-2 SECONDS saved per second of operation.

---

### Quick Glossary

These terms appear throughout Day 2's material. Quick definitions for reference:

| Term | Simple Explanation |
|------|-------------------|
| **GC (Garbage Collection)** | JVM's automatic memory cleanup. When you create objects with `new`, the GC eventually frees them. During cleanup, it can PAUSE all your threads (stop-the-world). |
| **Heap allocation** | Creating an object with `new` — puts it on the heap memory that GC manages |
| **Pre-allocation** | Creating all objects upfront (at startup) so the hot path never uses `new` |
| **SPSC** | Single-Producer Single-Consumer — exactly one thread writes, exactly one thread reads |
| **Ring buffer / Circular queue** | A fixed-size array where the index wraps around (0→1→2→...→N→0→1→...) |
| **Power of 2** | Buffer sizes like 1024, 2048, 65536. Allows using `&` (bitwise AND) instead of `%` (modulo) for index wrapping — much faster |
| **Backpressure** | When the buffer is full, the producer must wait (spin) instead of dropping data |
| **JIT (Just-In-Time)** | JVM compiles Java bytecode to native machine code while running. First few runs are slow (interpreted), then fast. That's why we "warm up" before benchmarking. |
| **DCE (Dead Code Elimination)** | JIT can remove code with no observable effect. In benchmarks we must trick it into thinking our reads matter. |
| **Thread.onSpinWait()** | Hints to the CPU: "I'm busy-waiting, optimize power consumption" (uses PAUSE instruction on x86) |
| **Convoy effect** | When threads queue up behind a lock, each waiting for the previous one to finish — like cars stuck behind a slow truck on a single-lane road |

---

## Part 3: Architecture Overview

```
┌──────────────────────────────────────────────────────────────────┐
│                    METRICS INGESTION PIPELINE                    │
├──────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────┐     ┌─────────────────────┐     ┌────────────┐  │
│  │  Producer   │────▶│   SPSC Ring Buffer  │────▶│  Consumer  │  │
│  │  (Sensors)  │     │  (Pre-allocated)    │     │  (Agg)     │  │
│  └─────────────┘     └─────────────────────┘     └────────────┘  │
│                                                         │        │
│                                                         ▼        │
│                              ┌────────────────────────────────┐  │
│                              │       Metrics Registry         │  │
│                              │  ┌──────────┐  ┌────────────┐  │  │
│                              │  │ RWLock   │  │ StampedLock│  │  │
│                              │  │ (Base)   │  │(Optimistic)│  │  │
│                              │  └──────────┘  └────────────┘  │  │
│                              └────────────────────────────────┘  │
│                                        │                         │
│                                        ▼                         │
│                              ┌────────────────────┐              │
│                              │  Dashboard Readers │              │
│                              │  (8+ threads)      │              │
│                              └────────────────────┘              │
└──────────────────────────────────────────────────────────────────┘
```

---

## Part 4: StampedLock Optimistic Reads

### The Problem with ReentrantReadWriteLock

`ReentrantReadWriteLock` (from Day 1, you know what a lock costs — context switches, CAS overhead) allows multiple concurrent readers OR one exclusive writer. However, even in read-only scenarios:

1. **Every read acquires a lock** — involves a CAS operation (~20-40ns, as you learned in Day 1 Section 2.5) on the lock's internal state
2. **Lock acquisition = memory barrier** — forces all cores to synchronize their caches (MESI invalidation, Day 1 Section 2.3)
3. **Under write pressure**, readers queue behind writers (convoy effect)
4. **Non-fair mode**: writers can starve; **Fair mode**: readers can starve writers

```java
// ReentrantReadWriteLock: Every get() pays the cost of CAS + potential thread parking
lock.readLock().lock();    // CAS on shared state → ALL cores must synchronize
try {
    return metrics.get(key);
} finally {
    lock.readLock().unlock(); // Another CAS
}
// Total cost: ~40-80ns even with NO contention
```

### How StampedLock Optimistic Reads Work

`StampedLock` (Java 8+) introduces a third mode: **optimistic reading** — which doesn't acquire a lock at all.

**The key idea**: Instead of asking "can I read?" (acquiring a lock = CAS = expensive), just READ the data, and then CHECK if anyone wrote while you were reading. If nobody wrote → your data is good. If someone did write → retry with a real lock.

```
┌────────────────────────────────────────────────────────────────┐
│                    OPTIMISTIC READ — STEP BY STEP              │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  Step 1: Get a "stamp" (version number)                        │
│  ─────────────────────────────────────                         │
│     long stamp = lock.tryOptimisticRead();                     │
│                                                                │
│     What happens: Just reads a version counter (volatile read) │
│     Cost: ~5ns (ONE cheap volatile read — LoadLoad barrier)    │
│     No CAS, no lock acquisition, no MESI invalidation!         │
│                                                                │
│  Step 2: Read the shared data                                  │
│  ─────────────────────────────                                 │
│     Double val = metrics.get(metricName);                      │
│                                                                │
│     What happens: Normal HashMap read. BUT this data might be  │
│     stale if a writer snuck in between step 1 and step 3!      │
│                                                                │
│  Step 3: Validate — "did anyone write since my stamp?"         │
│  ──────────────────────────────────────────────────            │
│     if (lock.validate(stamp)) { ... }                          │
│                                                                │
│     What happens: Compares current version to our stamp.       │
│     If they match → NO writer intervened → our read is valid!  │
│     If they don't match → a writer changed data → retry        │
│                                                                │
│  ┌────────────────────────────────────────────────────────┐    │
│  │ validate() == true?                                    │    │
│  │                                                        │    │
│  │   YES (common case, ~95% of the time)                  │    │
│  │   → Return the result. Total cost: ~5-10ns             │    │
│  │   → No lock was ever acquired!                         │    │
│  │   → No CAS happened!                                   │    │
│  │   → No other thread was affected!                      │    │
│  │                                                        │    │
│  │   NO (rare — a writer snuck in)                        │    │
│  │   → Fall back to full readLock() (like RWLock)         │    │
│  │   → Cost: ~40-80ns (same as RWLock)                    │    │
│  │   → But this is rare, so average cost stays low        │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                │
└────────────────────────────────────────────────────────────────┘
```

### Why Optimistic Reads Prevent Starvation

**The starvation problem with RWLock:**
- In "non-fair" mode: if readers keep coming, a writer can NEVER get in (writer starvation)
- In "fair" mode: if a writer is waiting, new readers must queue (reader starvation)

**StampedLock solves this because optimistic readers are INVISIBLE:**

| Scenario | RWLock Problem | StampedLock Solution |
|----------|----------------|---------------------|
| Heavy readers, rare writers | Readers hold the read lock → writer has to wait for ALL readers to release | Optimistic readers don't hold ANY state → writer just grabs the write lock immediately |
| Heavy writers, many readers | Readers get starved in fair mode | Optimistic reads that fail just retry or fall back; writers are never blocked by readers |
| Mixed workload | Convoy effects: threads line up | Only real contention is writer-vs-writer |

**Key insight**: When a thread does `tryOptimisticRead()`, it doesn't increment any counter, doesn't register in any queue, doesn't change any shared state. It's as if it doesn't exist from the writer's perspective. Writers can proceed without ever knowing optimistic readers exist.

### Implementation in Our Code

```java
public double get(String metricName) {
    // FAST PATH (~5-10ns): No lock acquired!
    long stamp = lock.tryOptimisticRead();     // volatile read of version
    Double val = metrics.get(metricName);       // read data (might be stale)
    double result = (val != null) ? val : 0.0;
    
    if (lock.validate(stamp)) {                // check: did anyone write?
        return result;  // Nobody wrote → our data is valid!
    }
    
    // SLOW PATH (~40-80ns): A writer intervened, use real lock
    stamp = lock.readLock();
    try {
        val = metrics.get(metricName);
        return (val != null) ? val : 0.0;
    } finally {
        lock.unlockRead(stamp);
    }
}
```

### When NOT to Use Optimistic Reads

- **Multi-step reads**: If you read `firstName` and `lastName` that must be consistent, the optimistic window must cover BOTH reads
- **Side effects**: Never do something irreversible before `validate()` (e.g., don't send an email based on optimistically-read data)
- **Very high write contention**: If >50% of optimistic reads fail validation, the overhead of "try optimistic → fail → retry with real lock" makes it slower than just using a real lock from the start

---

## Part 5: Lock-Free SPSC Ring Buffer

### What is a Ring Buffer?

A ring buffer is a fixed-size array where, when you reach the end, you wrap around to the beginning:

```
Index:    0   1   2   3   4   5   6   7   (capacity = 8)
          ↓                                 
Data:   [ A | B | C | _ | _ | _ | _ | _ ]
          ↑           ↑
         consumer  producer
         reads      writes
         from here  here next

After producer writes more and consumer reads A:
          
Data:   [ _ | B | C | D | E | _ | _ | _ ]
              ↑               ↑
           consumer        producer

Producer keeps writing and consumer reads further:
Data:   [ A | B | C | D | E | F | G | H ]
                      ↑               ↑
                   consumer        producer

After wrapping around (producer at index 7 writes, next goes to 0):

Data:   [ I | B | C | D | E | F | G | H ]
          ↑                   ↑           
       producer            consumer       
```

**Power-of-2 trick**: If capacity is a power of 2 (like 8, 1024, 65536), we can compute the array index using bitwise AND instead of modulo:
- `index = sequence % capacity` → SLOW (division operation, ~20-30ns)  
- `index = sequence & (capacity - 1)` → FAST (single AND instruction, ~0.3ns)

Example with capacity = 8, mask = 8-1 = 7 (= 0b111 binary):
- Sequence 0: `0 & 7 = 0` ← First write goes to index 0
- Sequence 7: `7 & 7 = 7` ← Seventh write goes to index 7
- Sequence 8: `8 & 7 = 0` ← Wraps around! Eight write goes to index 0 again.
- Sequence 15: `15 & 7 = 7`
- Sequence 16: `16 & 7 = 0` ← Wraps again!

### How the SPSC Ring Buffer Works (No Locks!)

The entire design relies on two sequence numbers and careful memory ordering (using the barriers you learned in the New Concepts section above):

```
┌───────────────────────────────────────────────────────────────┐
│               SPSC RING BUFFER — HOW IT WORKS                 │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  producerSequence: "I've written this many items total"       │
│  consumerSequence: "I've read this many items total"          │
│                                                               │
│  Buffer FULL when:  producerSeq - consumerSeq >= capacity     │
│  Buffer EMPTY when: producerSeq == consumerSeq                │
│                                                               │
│  ─── PRODUCER (Thread A) ───                                  │
│  1. Check if buffer full:                                     │
│     → read consumerSeq to see how far consumer has gotten     │
│  2. If not full, get the slot:                                │
│     → slot = buffer[producerSeq & mask]                       │
│  3. Write data INTO the slot (mutate in-place):               │
│     → slot.set(timestamp, name, value, tags)                  │
│  4. "Publish" by incrementing producerSeq:                    │
│     → producerSeq.lazySet(producerSeq + 1)                    │
│     → lazySet ensures: step 3 is visible BEFORE step 4        │
│       (StoreStore barrier — see New Concepts section)         │
│                                                               │
│  ─── CONSUMER (Thread B) ───                                  │
│  1. Check if data available:                                  │
│     → read producerSeq (volatile read) to see if producer     │
│       has written anything new                                │
│  2. If available, get the slot:                               │
│     → slot = buffer[consumerSeq & mask]                       │
│  3. Read data FROM the slot:                                  │
│     → use slot.getValue(), slot.getTimestamp(), etc.          │
│     → The volatile read in step 1 guarantees we see           │
│       the data the producer wrote (LoadLoad barrier)          │
│  4. "Release" by incrementing consumerSeq:                    │
│     → consumerSeq.lazySet(consumerSeq + 1)                    │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

### Why This is Thread-Safe WITHOUT Locks

The safety comes from the **happens-before chain** (Day 1 Section 2.6) created by the memory barriers (Day 2 New Concepts):

```
┌───────────────────────────────────────────────────────────────┐
│               THE HAPPENS-BEFORE CHAIN                        │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  PRODUCER                                 CONSUMER            │
│  ════════                                 ════════            │
│                                                               │
│  1. slot.set(data)                                            │
│     │                                                         │
│     │ ← StoreStore barrier (from lazySet)                     │
│     ▼                                                         │
│  2. producerSeq.lazySet(seq+1)                                │
│     │                                                         │
│     │ ← This value is eventually visible to consumer...       │
│     │                                                         │
│     └──────────────────────────────▶ 3. producerSeq.get()     │
│                                         (volatile read)       │
│                                         │                     │
│                                         │ ← LoadLoad barrier  │
│                                         ▼                     │
│                                      4. slot.getValue()       │
│                                         ← Guaranteed to see   │
│                                            data from step 1!  │
│                                                               │
│  THE GUARANTEE:                                               │
│  If consumer sees producerSeq == N (step 3),                  │
│  then ALL data writes for sequence N (step 1)                 │
│  are guaranteed to be visible to the consumer (step 4).       │
│                                                               │
│  This is because:                                             │
│  - Producer: lazySet creates StoreStore (data BEFORE seq)     │
│  - Consumer: volatile read creates LoadLoad (seq BEFORE data) │
│  - Combined: data → StoreStore → seq → LoadLoad → read data   │
│  - This forms a complete happens-before chain!                │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

### Why lazySet() Works Here (Not volatile write)

Connecting back to the New Concepts section:
- `volatile write` = StoreStore + StoreLoad (~20-40ns)
- `lazySet()` = StoreStore only (~1-2ns)

**Why we don't need StoreLoad**: StoreLoad prevents lost updates when multiple threads write to the SAME variable (Day 1: CAS requires this). In SPSC:
- Only the producer writes `producerSequence`
- Only the consumer writes `consumerSequence`
- No competing writers → no need for StoreLoad!

The consumer's volatile READ of producerSequence provides the LoadLoad barrier needed to see the data. The combination of producer's StoreStore + consumer's LoadLoad = complete happens-before = thread-safe.

### False Sharing Prevention in Our Ring Buffer

Connecting back to Day 1 Section 2.7 (false sharing): our code adds 56 bytes of padding around each sequence counter to ensure they're on different cache lines:

```java
private long p1, p2, p3, p4, p5, p6, p7; // 7 × 8 = 56 bytes padding
private final AtomicLong producerSequence = new AtomicLong(0); // 8 bytes
private long p8, p9, p10, p11, p12, p13, p14; // 56 bytes padding

private long c1, c2, c3, c4, c5, c6, c7; // 56 bytes padding
private final AtomicLong consumerSequence = new AtomicLong(0); // 8 bytes
private long c8, c9, c10, c11, c12, c13, c14; // 56 bytes padding
```

**Why (Day 1 recap):** Without padding, `producerSequence` and `consumerSequence` might sit on the same 64-byte cache line. Then every time the producer updates its sequence, the consumer's core gets an MESI invalidation and must re-fetch — even though `consumerSequence` hasn't changed. With padding, each sequence is on its own cache line: zero cross-core interference.

### Sequence Caching — Reducing Cross-Core Communication

An additional optimization: each thread caches the OTHER thread's sequence number locally:

```java
// Producer keeps a LOCAL copy of consumerSequence
private long cachedConsumerSequence = 0;

public T claimSlot() {
    long seq = producerSequence.get();  // cheap — reading OUR OWN sequence (in our L1)
    
    if (seq - cachedConsumerSequence >= capacity) {
        // Only NOW do we check the consumer's actual sequence (expensive cross-core read!)
        cachedConsumerSequence = consumerSequence.get();
        if (seq - cachedConsumerSequence >= capacity) {
            return null; // truly full
        }
    }
    return buffer[(int)(seq & mask)];
}
```

**Why this helps (Day 1 connection)**: Reading `consumerSequence.get()` requires fetching data from the OTHER core's cache (cross-core traffic = MESI Shared transition, ~40-80ns, Day 1 Section 2.3). By caching it locally, we only do this expensive read when we THINK the buffer might be full — which is rare in a well-sized buffer.

---

## Part 6: GC Pressure and Pre-allocation

### What is GC Pressure?

Every time you write `new SomeObject()` in Java, memory is allocated on the "heap." The JVM's Garbage Collector (GC) periodically scans the heap to find objects nobody uses anymore and reclaims that memory.

**The problem**: During GC, the JVM might PAUSE all your application threads (a "stop-the-world" pause). In a metrics pipeline processing millions of events per second:

```
┌──────────────────────────────────────────────────────────────┐
│    WHAT HAPPENS WITH new MetricEvent() PER EVENT             │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  At 10M events/sec, each MetricEvent ≈ 300 bytes:            │
│                                                              │
│  → 3 GIGABYTES of objects created per second!                │
│  → JVM's "Young Generation" (nursery) fills in milliseconds  │
│  → Minor GC triggered every 5-10ms                           │
│  → Each minor GC pauses ALL threads for 1-5ms                │
│  → Occasional Full GC pauses ALL threads for 50-200ms        │
│                                                              │
│  Your latency profile looks like:                            │
│                                                              │
│  Normal operation:  1 microsecond per event                  │
│  During minor GC:   event processing STOPS for 5ms           │
│  During full GC:    event processing STOPS for 200ms         │
│                                                              │
│  That means every ~5 seconds, you LOSE 200ms of events!      │
│  (or they queue up, creating cascading latency)              │
│                                                              │
└──────────────────────────────────────────────────────────────┘
```

### The Solution: Pre-allocate Everything

Instead of creating new objects on the hot path, we allocate all objects ONCE at startup and reuse them forever:

```
┌───────────────────────────────────────────────────────────────┐
│    RING BUFFER: ZERO ALLOCATION ON HOT PATH                   │
├───────────────────────────────────────────────────────────────┤
│                                                               │
│  STARTUP (one-time cost, happens once):                       │
│    buffer = new MetricEvent[65536];                           │
│    for (i = 0; i < 65536; i++)                                │
│        buffer[i] = new MetricEvent();                         │
│    // 65536 objects created. Never again.                     │
│                                                               │
│  HOT PATH (every single event — millions per second):         │
│    MetricEvent slot = ringBuffer.claimSlot();                 │
│    // ↑ Returns a REFERENCE to an existing object. No 'new'!  │
│                                                               │
│    slot.set(timestamp, name, value, tags);                    │
│    // ↑ Overwrites fields in the existing object. No 'new'!   │
│                                                               │
│    ringBuffer.publish();                                      │
│    // ↑ Just increments a counter. No 'new'!                  │
│                                                               │
│  RESULT:                                                      │
│    → 0 objects created per second on hot path                 │
│    → GC has nothing to collect                                │
│    → No GC pauses                                             │
│    → Completely predictable latency                           │
│                                                               │
└───────────────────────────────────────────────────────────────┘
```

### Design Choices That Avoid GC

| Naive Approach (GC pressure) | Our Approach (GC free) | Why |
|------------------------------|------------------------|-----|
| `new MetricEvent()` per event | Pre-allocated slots, mutate in-place | No allocation = no garbage |
| `String metricName` | `char[128] metricName` (fixed array) | Strings are immutable → every change creates a new String object |
| `Double value` (boxed) | `double value` (primitive) | Boxed types allocate wrapper objects on heap |
| `Map<String,String> tags` | `long tags` (bit-packed) | One primitive vs. HashMap with String keys and values |
| `ArrayBlockingQueue.put(new Event())` | `ringBuffer.claimSlot()` + mutate | Queue = lock + allocation; Ring buffer = barrier + reuse |

### The MetricEvent Design

```java
public class MetricEvent {
    private long timestamp;          // 8 bytes — primitive, no boxing
    private final char[] metricName; // Fixed 128-char array — no new String per event
    private int metricNameLength;    // 4 bytes — how many chars are actually used
    private double value;            // 8 bytes — primitive, no boxing
    private long tags;               // 8 bytes — bit-packed flags instead of Map
    
    // Mutate in place — ZERO allocation!
    public void set(long ts, String name, double val, long tags) {
        this.timestamp = ts;
        this.metricNameLength = Math.min(name.length(), MAX_NAME_LENGTH);
        name.getChars(0, metricNameLength, this.metricName, 0); // copies chars, no new String
        this.value = val;
        this.tags = tags;
    }
}
```

---

## Part 7: Benchmarking Results Interpretation

### Benchmark 1: Registry Lock Strategy

**What to expect:**

| Metric | RWLock | StampedLock | Why the difference |
|--------|--------|-------------|-------------------|
| Read ops/sec | ~20-50M | ~80-200M | Optimistic reads avoid CAS (Day 1 Section 2.5); just volatile read + validate |
| Write ops/sec | ~5-15M | ~5-15M | Both use exclusive write lock — similar cost |
| Read speedup | baseline | 2-5x faster | At 8:2 reader:writer ratio, most optimistic reads succeed |

**Why StampedLock wins on reads:**
- RWLock: readLock() → CAS → potential park (Day 1 Section 2.4) → readUnlock() → CAS = minimum ~40ns
- StampedLock: tryOptimisticRead() → volatile read → validate() = ~5-10ns

**When RWLock would win:**
- If StampedLock's optimistic reads fail >80% of the time (extreme write pressure)
- If you need reentrant locking (StampedLock deadlocks if you try to lock twice in the same thread)

### Benchmark 2: Ring Buffer vs Dynamic Allocation

**What to expect:**

| Metric | ArrayBlockingQueue | SPSC Ring Buffer | Why the difference |
|--------|-------------------|------------------|-------------------|
| Throughput | ~2-5M events/sec | ~20-80M events/sec | No lock + no allocation + no GC |
| Memory allocated | Hundreds of MB | ~0 bytes | Pre-allocated vs new object per event |
| GC collections | 10-50+ | 0-1 | No garbage created = nothing to collect |

**The throughput gap comes from THREE compounding factors:**
1. **No lock overhead**: SPSC uses only lazySet (~1-2ns) vs ArrayBlockingQueue's ReentrantLock (~40ns per put+take, plus context switches — Day 1 Section 2.4)
2. **No allocation overhead**: Each `new MetricEvent()` costs ~10-20ns + generates garbage
3. **No GC pauses**: BlockingQueue creates millions of objects → triggers GC → all threads pause

---

## How to Run

### Prerequisites
- JDK 17+ (Gradle Wrapper included — no separate Gradle installation needed)
- No external dependencies (pure JDK)

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day2:run
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. The IDE auto-detects the Gradle project and lets you click ▶ on `Main.java` directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out Main
```

### Expected Runtime
- Benchmark 1 (Registry): ~14 seconds (2s warmup + 5s measurement × 2 implementations)
- Benchmark 2 (Ring Buffer): ~10-20 seconds (warm-up + 10M events × 2 modes)
- Total: ~30-40 seconds

---

## Directory Structure

```
src/
├── Main.java                                  # Entry point — runs both benchmarks
├── metrics/
│   ├── MetricEvent.java                       # Pre-allocated, mutable metric payload
│   ├── registry/
│   │   ├── MetricsRegistry.java               # Interface for registry operations
│   │   ├── RWLockMetricsRegistry.java         # Approach A: ReentrantReadWriteLock
│   │   └── StampedLockMetricsRegistry.java    # Approach B: StampedLock optimistic reads
│   ├── ringbuffer/
│   │   └── SPSCRingBuffer.java                # Lock-free SPSC circular queue
│   └── benchmark/
│       ├── RegistryBenchmark.java             # RWLock vs StampedLock throughput test
│       └── RingBufferBenchmark.java           # Ring buffer vs dynamic alloc GC test
```

---

## Part 8: Interview Discussion Points

### 1. "Why not just use ConcurrentHashMap?"
`ConcurrentHashMap` uses fine-grained striped locking (divides the map into segments, each with its own lock). For a metrics registry where reads vastly outnumber writes, StampedLock's optimistic path is faster because it avoids even segment-level lock acquisition. However, ConcurrentHashMap scales better when you have heavy writes to MANY different keys simultaneously.

### 2. "How would you handle multiple producers?"
Our SPSC ring buffer is strictly single-producer. For MPSC (Multiple Producer, Single Consumer):
- **CAS loop on producerSequence**: Each producer atomically claims a slot via `compareAndSet` (Day 1 Section 2.5 — same CAS retry loop pattern)
- **Disruptor pattern**: Separate "claim" and "publish" phases with a multi-producer sequencer
- **Per-producer buffers**: Each producer has its own SPSC buffer; consumer drains all of them (simplest, best cache behavior — no false sharing between producers)

### 3. "What about off-heap memory?"
For even lower GC pressure, the ring buffer could store data OUTSIDE the JVM heap entirely:
- `ByteBuffer.allocateDirect()` — memory not managed by GC
- Memory-mapped files (`MappedByteBuffer`) — for persistence + zero-copy
- `VarHandle` / `sun.misc.Unsafe` — direct memory access with explicit barrier control

### 4. "How does this compare to LMAX Disruptor?"
Our SPSC ring buffer implements the core concepts from the Disruptor:
- Pre-allocated ring buffer with power-of-2 capacity ✓
- Sequence-based coordination ✓
- Cache-line padding for false-sharing prevention (Day 1 Section 2.7) ✓
- The Disruptor adds: multi-producer support, dependency graphs between consumers, and configurable wait strategies (busy-spin vs. yield vs. block)

---

## Further Reading

- [JSR-133 (Java Memory Model)](https://www.cs.umd.edu/~pugh/java/memoryModel/jsr133.pdf)
- [LMAX Disruptor Technical Paper](https://lmax-exchange.github.io/disruptor/disruptor.html)
- [Doug Lea — JSR-166 Concurrency Utilities](http://gee.cs.oswego.edu/dl/concurrency-interest/)
- [JEP 193: Variable Handles](https://openjdk.org/jeps/193)
- [Mechanical Sympathy Blog — Memory Barriers](https://mechanical-sympathy.blogspot.com/)

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
