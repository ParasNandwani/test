package metrics;

/**
 * Pre-allocated, mutable metric payload designed to minimize GC pressure.
 * 
 * In a high-throughput pipeline, allocating a new object per metric event
 * creates enormous garbage collection overhead. This class is designed to be
 * reused: slots in the ring buffer are pre-allocated at startup and mutated
 * in-place during publish operations.
 * 
 * Key design decisions:
 * - Mutable fields (no defensive copies)
 * - Fixed-size char array for metric name (avoids String interning/allocation)
 * - No boxing: primitive double for value, primitive long for timestamp
 */
public class MetricEvent {

    private long timestamp;
    private final char[] metricName;
    private int metricNameLength;
    private double value;
    private long tags; // Bit-packed tags for zero-allocation tagging

    public static final int MAX_NAME_LENGTH = 128;

    public MetricEvent() {
        this.metricName = new char[MAX_NAME_LENGTH];
        this.metricNameLength = 0;
        this.timestamp = 0L;
        this.value = 0.0;
        this.tags = 0L;
    }

    /**
     * Populate this event in-place. No allocation occurs.
     */
    public void set(long timestamp, String name, double value, long tags) {
        this.timestamp = timestamp;
        this.metricNameLength = Math.min(name.length(), MAX_NAME_LENGTH);
        name.getChars(0, this.metricNameLength, this.metricName, 0);
        this.value = value;
        this.tags = tags;
    }

    public void reset() {
        this.timestamp = 0L;
        this.metricNameLength = 0;
        this.value = 0.0;
        this.tags = 0L;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getMetricName() {
        return new String(metricName, 0, metricNameLength);
    }

    public int getMetricNameLength() {
        return metricNameLength;
    }

    public char[] getMetricNameChars() {
        return metricName;
    }

    public double getValue() {
        return value;
    }

    public long getTags() {
        return tags;
    }

    @Override
    public String toString() {
        return "MetricEvent{" +
                "ts=" + timestamp +
                ", name=" + new String(metricName, 0, metricNameLength) +
                ", value=" + value +
                ", tags=0x" + Long.toHexString(tags) +
                '}';
    }
}