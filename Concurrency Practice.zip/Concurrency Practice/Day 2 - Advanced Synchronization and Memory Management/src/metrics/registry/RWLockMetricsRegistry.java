package metrics.registry;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Approach A: Metrics Registry using ReentrantReadWriteLock.
 * 
 * This is the baseline implementation. It provides:
 * - Multiple concurrent readers (shared read lock)
 * - Exclusive writer access (write lock blocks all readers and other writers)
 * 
 * Limitations under high contention:
 * - Readers must acquire a lock even when no writer is active (lock acquisition overhead)
 * - Under continuous write pressure, reader throughput degrades significantly
 *   due to lock fairness policies and context switching
 * - Each lock acquisition involves a CAS operation and potential park/unpark
 */
public class RWLockMetricsRegistry implements MetricsRegistry {

    private final Map<String, Double> metrics;
    private final ReadWriteLock lock;

    public RWLockMetricsRegistry() {
        this.metrics = new HashMap<>(256);
        this.lock = new ReentrantReadWriteLock(false); // Non-fair for max throughput
    }

    @Override
    public void record(String metricName, double value) {
        lock.writeLock().lock();
        try {
            metrics.put(metricName, value);
        } finally {
            lock.writeLock().unlock();
        }
    }

    @Override
    public double get(String metricName) {
        lock.readLock().lock();
        try {
            Double val = metrics.get(metricName);
            return val != null ? val : 0.0;
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public Map<String, Double> snapshot() {
        lock.readLock().lock();
        try {
            return new HashMap<>(metrics);
        } finally {
            lock.readLock().unlock();
        }
    }

    @Override
    public int size() {
        lock.readLock().lock();
        try {
            return metrics.size();
        } finally {
            lock.readLock().unlock();
        }
    }
}