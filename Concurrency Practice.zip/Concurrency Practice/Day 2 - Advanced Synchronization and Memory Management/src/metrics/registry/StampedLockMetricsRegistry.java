package metrics.registry;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.StampedLock;

/**
 * Approach B: Metrics Registry using StampedLock with Optimistic Reading.
 * 
 * StampedLock provides three modes of access:
 * 1. Write Lock (exclusive) — same as ReentrantReadWriteLock's write lock
 * 2. Read Lock (pessimistic) — same as ReentrantReadWriteLock's read lock
 * 3. Optimistic Read (lock-free!) — the key differentiator
 * 
 * OPTIMISTIC READ MECHANICS:
 * ─────────────────────────────
 * tryOptimisticRead() returns a "stamp" (a version number) WITHOUT acquiring any lock.
 * The thread then reads shared state optimistically (no memory barriers beyond volatile read).
 * After reading, validate(stamp) checks if any writer acquired the lock since the stamp
 * was issued. If validation succeeds → the read was consistent, return immediately.
 * If validation fails → a concurrent write occurred, fall back to pessimistic read lock.
 * 
 * WHY THIS IS FASTER:
 * - In read-heavy workloads (typical for metrics: many dashboards polling, few writes),
 *   optimistic reads NEVER block and NEVER contend with writers.
 * - No CAS operation on the hot read path when optimistic validation succeeds.
 * - Writers still get exclusive access via writeLock().
 * 
 * STARVATION PREVENTION:
 * - Unlike ReentrantReadWriteLock where readers can starve writers (non-fair mode),
 *   StampedLock's optimistic reads don't hold any lock state, so writers are never
 *   blocked by optimistic readers.
 * - Writers only contend with pessimistic readers and other writers.
 * - The optimistic→pessimistic fallback ensures progress even under extreme write pressure.
 * 
 * IMPORTANT CAVEATS:
 * - StampedLock is NOT reentrant (acquiring write lock twice = deadlock)
 * - Optimistic reads must not have side effects (the read may be inconsistent)
 * - Fields read optimistically should be stored in locals before validation
 */
public class StampedLockMetricsRegistry implements MetricsRegistry {

    private final Map<String, Double> metrics;
    private final StampedLock lock;

    public StampedLockMetricsRegistry() {
        this.metrics = new HashMap<>(256);
        this.lock = new StampedLock();
    }

    @Override
    public void record(String metricName, double value) {
        long stamp = lock.writeLock();
        try {
            metrics.put(metricName, value);
        } finally {
            lock.unlockWrite(stamp);
        }
    }

    @Override
    public double get(String metricName) {
        // FAST PATH: Optimistic read (no lock acquired)
        long stamp = lock.tryOptimisticRead();
        
        // Read shared state into local variables
        Double val = metrics.get(metricName);
        double result = (val != null) ? val : 0.0;
        
        // Validate: was there a concurrent write since we got the stamp?
        if (lock.validate(stamp)) {
            // SUCCESS: No write occurred, our read is consistent
            return result;
        }
        
        // SLOW PATH: Optimistic read failed (a writer intervened)
        // Fall back to pessimistic read lock
        stamp = lock.readLock();
        try {
            val = metrics.get(metricName);
            return (val != null) ? val : 0.0;
        } finally {
            lock.unlockRead(stamp);
        }
    }

    @Override
    public Map<String, Double> snapshot() {
        // Snapshot is a bulk operation — use pessimistic read lock
        // (optimistic read would be unreliable for iterating the entire map)
        long stamp = lock.readLock();
        try {
            return new HashMap<>(metrics);
        } finally {
            lock.unlockRead(stamp);
        }
    }

    @Override
    public int size() {
        // Optimistic read for a single-value read
        long stamp = lock.tryOptimisticRead();
        int s = metrics.size();
        if (lock.validate(stamp)) {
            return s;
        }
        // Fallback
        stamp = lock.readLock();
        try {
            return metrics.size();
        } finally {
            lock.unlockRead(stamp);
        }
    }
}