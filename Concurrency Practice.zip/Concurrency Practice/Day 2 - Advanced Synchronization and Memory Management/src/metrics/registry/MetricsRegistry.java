package metrics.registry;

import java.util.Map;

/**
 * Thread-safe metrics registry interface.
 * 
 * Implementations provide different concurrency strategies:
 * - ReentrantReadWriteLock (baseline)
 * - StampedLock with optimistic reads (low-latency)
 */
public interface MetricsRegistry {

    /**
     * Record a metric value. Overwrites the current value for the given name.
     * This is the write path — must be thread-safe.
     */
    void record(String metricName, double value);

    /**
     * Retrieve the current value for a metric.
     * This is the read path — optimized for high concurrency.
     * 
     * @return the current value, or 0.0 if not present
     */
    double get(String metricName);

    /**
     * Capture a consistent snapshot of all registered metrics.
     * This is a bulk read operation.
     */
    Map<String, Double> snapshot();

    /**
     * Returns the number of distinct metrics in the registry.
     */
    int size();
}