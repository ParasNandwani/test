package metrics.ringbuffer;

import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;

/**
 * Lock-Free Single-Producer Single-Consumer (SPSC) Ring Buffer.
 *
 * ARCHITECTURAL DESIGN:
 * ─────────────────────────
 * This is a bounded, pre-allocated circular queue that enables zero-allocation
 * message passing between exactly ONE producer thread and ONE consumer thread.
 *
 * KEY INVARIANTS:
 * - Exactly one thread calls offer()/publish() (the producer)
 * - Exactly one thread calls poll()/consume() (the consumer)
 * - Buffer capacity is always a power of 2 (enables bitwise index masking)
 * - All slots are pre-allocated at construction time (zero GC on hot path)
 *
 * MEMORY BARRIER SEMANTICS:
 * ──────────────────────────
 * Thread safety without locks is achieved through careful use of memory ordering:
 *
 * 1. Producer writes data to buffer[producerSeq & mask], then publishes
 *    producerSeq using lazySet() (StoreStore barrier / release semantics).
 *    This ensures the data write is visible BEFORE the sequence increment.
 *
 * 2. Consumer reads producerSeq using volatile read (LoadLoad barrier / acquire
 *    semantics). If producerSeq > consumerSeq, data is available. The consumer
 *    then reads buffer[consumerSeq & mask] — guaranteed to see the producer's write.
 *
 * 3. Consumer publishes consumerSeq using lazySet() after processing.
 *    Producer reads consumerSeq to check available capacity.
 *
 * WHY lazySet() INSTEAD OF volatile WRITE:
 * - volatile write issues a StoreLoad barrier (full fence) — expensive (~20-40ns)
 * - lazySet() issues only a StoreStore barrier — much cheaper (~1-2ns)
 * - In SPSC, we don't need StoreLoad because only ONE thread writes each sequence
 * - The consumer's volatile read of producerSeq provides the necessary LoadLoad
 *
 * FALSE SHARING PREVENTION:
 * - Producer and consumer sequences are padded to separate cache lines (64 bytes)
 * - Without padding, both sequences could share a cache line, causing
 *   cache-line bouncing between cores (invalidation storms)
 *
 * @param <T> The element type stored in the ring buffer
 */
public class SPSCRingBuffer<T> {

    private final int capacity;
    private final int mask;
    private final T[] buffer;

    // ─── Padded producer sequence ────────────────────────────────────────
    // Cache line padding to prevent false sharing with consumer sequence
    private long p1, p2, p3, p4, p5, p6, p7; // 56 bytes padding
    private final AtomicLong producerSequence = new AtomicLong(0);
    private long p8, p9, p10, p11, p12, p13, p14; // 56 bytes padding

    // ─── Padded consumer sequence ────────────────────────────────────────
    private long c1, c2, c3, c4, c5, c6, c7; // 56 bytes padding
    private final AtomicLong consumerSequence = new AtomicLong(0);
    private long c8, c9, c10, c11, c12, c13, c14; // 56 bytes padding

    // Cached sequences to reduce volatile reads across cache lines
    private long cachedConsumerSequence = 0; // Only read by producer
    private long cachedProducerSequence = 0; // Only read by consumer

    /**
     * Creates a new SPSC Ring Buffer with pre-allocated slots.
     *
     * @param requestedCapacity desired capacity (will be rounded up to next power of 2)
     * @param slotFactory factory to pre-allocate each slot (e.g., MetricEvent::new)
     */
    @SuppressWarnings("unchecked")
    public SPSCRingBuffer(int requestedCapacity, java.util.function.Supplier<T> slotFactory) {
        this.capacity = nextPowerOfTwo(requestedCapacity);
        this.mask = this.capacity - 1;
        this.buffer = (T[]) new Object[this.capacity];

        // Pre-allocate all slots — this is the key to zero-GC operation
        for (int i = 0; i < this.capacity; i++) {
            buffer[i] = slotFactory.get();
        }
    }

    /**
     * PRODUCER OPERATION: Claim a slot for writing.
     *
     * Returns the pre-allocated element at the next write position,
     * or null if the buffer is full. The producer should mutate the
     * returned element in-place, then call publish().
     *
     * @return the pre-allocated slot to write into, or null if full
     */
    public T claimSlot() {
        long currentProducerSeq = producerSequence.get();

        // Check if buffer is full
        if (currentProducerSeq - cachedConsumerSequence >= capacity) {
            // Refresh cached consumer sequence (volatile read)
            cachedConsumerSequence = consumerSequence.get();
            if (currentProducerSeq - cachedConsumerSequence >= capacity) {
                return null; // Buffer is truly full
            }
        }

        return buffer[(int) (currentProducerSeq & mask)];
    }

    /**
     * PRODUCER OPERATION: Publish the claimed slot.
     *
     * Must be called AFTER writing data into the slot returned by claimSlot().
     * Uses lazySet (StoreStore barrier) — guarantees the data write is visible
     * before the sequence increment, without the cost of a full StoreLoad fence.
     */
    public void publish() {
        // lazySet provides release semantics:
        // All stores before this point are visible to any thread that
        // subsequently reads this sequence via volatile read (acquire)
        producerSequence.lazySet(producerSequence.get() + 1);
    }

    /**
     * CONSUMER OPERATION: Poll for the next available element.
     *
     * Returns the element at the current consumer position if data is available,
     * or null if the buffer is empty. The consumer should read the element's data,
     * then call release() to advance the consumer sequence.
     *
     * @return the next element to consume, or null if empty
     */
    public T poll() {
        long currentConsumerSeq = consumerSequence.get();

        // Check if data is available
        if (cachedProducerSequence <= currentConsumerSeq) {
            // Refresh cached producer sequence (volatile read)
            cachedProducerSequence = producerSequence.get();
            if (cachedProducerSequence <= currentConsumerSeq) {
                return null; // Buffer is empty
            }
        }

        return buffer[(int) (currentConsumerSeq & mask)];
    }

    /**
     * CONSUMER OPERATION: Release the consumed slot.
     *
     * Must be called AFTER processing the element returned by poll().
     * Uses lazySet (StoreStore barrier) to publish the consumer's progress
     * to the producer without a full memory fence.
     */
    public void release() {
        consumerSequence.lazySet(consumerSequence.get() + 1);
    }

    /**
     * Convenience method: Offer data using a writer function.
     * Claims a slot, applies the writer, and publishes in one call.
     *
     * @param writer function that populates the claimed slot
     * @return true if the offer succeeded, false if the buffer was full
     */
    public boolean offer(Consumer<T> writer) {
        T slot = claimSlot();
        if (slot == null) {
            return false;
        }
        writer.accept(slot);
        publish();
        return true;
    }

    /**
     * Convenience method: Drain one element using a reader function.
     * Polls a slot, applies the reader, and releases in one call.
     *
     * @param reader function that processes the consumed element
     * @return true if an element was consumed, false if buffer was empty
     */
    public boolean drain(Consumer<T> reader) {
        T slot = poll();
        if (slot == null) {
            return false;
        }
        reader.accept(slot);
        release();
        return true;
    }

    /**
     * Returns the number of elements currently in the buffer.
     * Note: This is an approximation in a concurrent context.
     */
    public long size() {
        return producerSequence.get() - consumerSequence.get();
    }

    /**
     * Returns the total capacity of the ring buffer.
     */
    public int capacity() {
        return capacity;
    }

    /**
     * Returns true if the buffer is empty.
     */
    public boolean isEmpty() {
        return producerSequence.get() == consumerSequence.get();
    }

    /**
     * Returns true if the buffer is full.
     */
    public boolean isFull() {
        return (producerSequence.get() - consumerSequence.get()) >= capacity;
    }

    // ─── Utility ─────────────────────────────────────────────────────────

    private static int nextPowerOfTwo(int value) {
        if (value <= 0) {
            return 1;
        }
        value--;
        value |= value >> 1;
        value |= value >> 2;
        value |= value >> 4;
        value |= value >> 8;
        value |= value >> 16;
        return value + 1;
    }

    // Prevent dead-code elimination of padding fields
    public long preventPaddingElimination() {
        return p1 + p2 + p3 + p4 + p5 + p6 + p7 +
               p8 + p9 + p10 + p11 + p12 + p13 + p14 +
               c1 + c2 + c3 + c4 + c5 + c6 + c7 +
               c8 + c9 + c10 + c11 + c12 + c13 + c14;
    }
}