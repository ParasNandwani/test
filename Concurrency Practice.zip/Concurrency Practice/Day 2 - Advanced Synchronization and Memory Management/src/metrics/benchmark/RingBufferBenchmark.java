package metrics.benchmark;

import metrics.MetricEvent;
import metrics.ringbuffer.SPSCRingBuffer;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Benchmarking Harness: Pre-allocated Ring Buffer vs Dynamic Allocation (BlockingQueue)
 *
 * Compares two approaches for passing metric events between producer and consumer:
 *
 * Mode A (Naive - Dynamic Allocation):
 * - Producer creates a NEW MetricEvent object per iteration
 * - Uses ArrayBlockingQueue (lock-based) for thread communication
 * - Each event = heap allocation → GC pressure → unpredictable latency spikes
 *
 * Mode B (Ring Buffer - Zero Allocation):
 * - Uses pre-allocated SPSCRingBuffer with MetricEvent slots
 * - Producer claims a slot, mutates in-place, publishes
 * - Zero heap allocation on the hot path → predictable latency
 * - Lock-free: no thread parking/unparking overhead
 *
 * Metrics Captured:
 * - Throughput (events/second)
 * - Memory allocated (bytes, estimated via Runtime)
 * - GC invocation count (via Runtime/GC tracking)
 */
public class RingBufferBenchmark {

    private static final int BUFFER_CAPACITY = 1024 * 64; // 64K slots
    private static final int TOTAL_EVENTS = 10_000_000; // 10M events per test
    private static final String[] METRIC_NAMES = {
            "cpu.usage", "mem.heap", "disk.iops", "net.rx_bytes",
            "gc.pause_ms", "thread.count", "latency.p99", "queue.depth"
    };

    public static void run() {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║     RING BUFFER BENCHMARK: Pre-allocated vs Dynamic Alloc    ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
        System.out.println();
        System.out.printf("  Configuration: %,d events, buffer capacity: %,d%n%n", TOTAL_EVENTS, BUFFER_CAPACITY);

        // Warm up JIT
        System.out.println("  Warming up JIT...");
        runRingBufferTest(1_000_000, false);
        runBlockingQueueTest(1_000_000, false);
        System.out.println("  Warm-up complete.\n");

        // Force GC before measurements
        forceGC();

        System.out.println("─── Mode A: Dynamic Allocation (ArrayBlockingQueue) ─────────");
        long[] dynamicResult = runBlockingQueueTest(TOTAL_EVENTS, true);

        System.out.println();

        // Force GC between tests
        forceGC();

        System.out.println("─── Mode B: Pre-allocated SPSC Ring Buffer ──────────────────");
        long[] ringBufferResult = runRingBufferTest(TOTAL_EVENTS, true);

        System.out.println();
        System.out.println("─── Comparison ──────────────────────────────────────────────");
        double throughputSpeedup = (double) ringBufferResult[0] / dynamicResult[0];
        System.out.printf("  Throughput Speedup:     %.2fx (Ring Buffer vs BlockingQueue)%n", throughputSpeedup);
        System.out.printf("  Memory Saved:           %,d bytes less allocated%n",
                dynamicResult[1] - ringBufferResult[1]);
        System.out.printf("  GC Runs Avoided:        %d fewer collections%n",
                dynamicResult[2] - ringBufferResult[2]);
        System.out.println();
    }

    /**
     * Mode B: Pre-allocated SPSC Ring Buffer test.
     *
     * @return [throughput_ops_per_sec, bytes_allocated, gc_count]
     */
    private static long[] runRingBufferTest(int numEvents, boolean printResults) {
        SPSCRingBuffer<MetricEvent> ringBuffer = new SPSCRingBuffer<>(BUFFER_CAPACITY, MetricEvent::new);

        AtomicLong producerDone = new AtomicLong(0);
        CountDownLatch finished = new CountDownLatch(2);

        long gcCountBefore = getGCCount();
        long memBefore = getUsedMemory();

        long startTime = System.nanoTime();

        // Producer thread
        Thread producer = new Thread(() -> {
            for (int i = 0; i < numEvents; i++) {
                // Spin until slot is available (backpressure)
                while (true) {
                    MetricEvent slot = ringBuffer.claimSlot();
                    if (slot != null) {
                        // Mutate in-place — ZERO allocation
                        slot.set(
                                System.nanoTime(),
                                METRIC_NAMES[i & (METRIC_NAMES.length - 1)],
                                i * 0.01,
                                (long) (i & 0xFF)
                        );
                        ringBuffer.publish();
                        break;
                    }
                    Thread.onSpinWait();
                }
            }
            producerDone.set(1);
            finished.countDown();
        }, "rb-producer");

        // Consumer thread
        Thread consumer = new Thread(() -> {
            long consumed = 0;
            while (consumed < numEvents) {
                MetricEvent event = ringBuffer.poll();
                if (event != null) {
                    // Simulate minimal processing (read value to prevent DCE)
                    if (event.getValue() < -1) {
                        throw new RuntimeException("Impossible");
                    }
                    ringBuffer.release();
                    consumed++;
                } else {
                    Thread.onSpinWait();
                }
            }
            finished.countDown();
        }, "rb-consumer");

        producer.start();
        consumer.start();

        try {
            finished.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        long elapsed = System.nanoTime() - startTime;
        long memAfter = getUsedMemory();
        long gcCountAfter = getGCCount();

        long throughput = (long) ((double) numEvents / (elapsed / 1_000_000_000.0));
        long bytesAllocated = Math.max(0, memAfter - memBefore);
        long gcRuns = gcCountAfter - gcCountBefore;

        if (printResults) {
            System.out.printf("  Events Processed: %,d%n", numEvents);
            System.out.printf("  Elapsed Time:     %,d ms%n", elapsed / 1_000_000);
            System.out.printf("  Throughput:       %,d events/sec%n", throughput);
            System.out.printf("  Memory Delta:     %,d bytes%n", bytesAllocated);
            System.out.printf("  GC Collections:   %d%n", gcRuns);
        }

        return new long[]{throughput, bytesAllocated, gcRuns};
    }

    /**
     * Mode A: Dynamic allocation with ArrayBlockingQueue.
     *
     * @return [throughput_ops_per_sec, bytes_allocated, gc_count]
     */
    private static long[] runBlockingQueueTest(int numEvents, boolean printResults) {
        ArrayBlockingQueue<MetricEvent> queue = new ArrayBlockingQueue<>(BUFFER_CAPACITY);
        CountDownLatch finished = new CountDownLatch(2);

        long gcCountBefore = getGCCount();
        long memBefore = getUsedMemory();

        long startTime = System.nanoTime();

        // Producer thread — allocates a NEW object per event
        Thread producer = new Thread(() -> {
            for (int i = 0; i < numEvents; i++) {
                // Create a new MetricEvent every iteration (GC pressure!)
                MetricEvent event = new MetricEvent();
                event.set(
                        System.nanoTime(),
                        METRIC_NAMES[i & (METRIC_NAMES.length - 1)],
                        i * 0.01,
                        (long) (i & 0xFF)
                );
                // Spin until space available
                while (!queue.offer(event)) {
                    Thread.onSpinWait();
                }
            }
            finished.countDown();
        }, "bq-producer");

        // Consumer thread
        Thread consumer = new Thread(() -> {
            long consumed = 0;
            while (consumed < numEvents) {
                MetricEvent event = queue.poll();
                if (event != null) {
                    if (event.getValue() < -1) {
                        throw new RuntimeException("Impossible");
                    }
                    consumed++;
                } else {
                    Thread.onSpinWait();
                }
            }
            finished.countDown();
        }, "bq-consumer");

        producer.start();
        consumer.start();

        try {
            finished.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        long elapsed = System.nanoTime() - startTime;
        long memAfter = getUsedMemory();
        long gcCountAfter = getGCCount();

        long throughput = (long) ((double) numEvents / (elapsed / 1_000_000_000.0));
        long bytesAllocated = Math.max(0, memAfter - memBefore);
        long gcRuns = gcCountAfter - gcCountBefore;

        if (printResults) {
            System.out.printf("  Events Processed: %,d%n", numEvents);
            System.out.printf("  Elapsed Time:     %,d ms%n", elapsed / 1_000_000);
            System.out.printf("  Throughput:       %,d events/sec%n", throughput);
            System.out.printf("  Memory Delta:     %,d bytes%n", bytesAllocated);
            System.out.printf("  GC Collections:   %d%n", gcRuns);
        }

        return new long[]{throughput, bytesAllocated, gcRuns};
    }

    // ─── Utility Methods ─────────────────────────────────────────────────

    private static long getGCCount() {
        long count = 0;
        for (java.lang.management.GarbageCollectorMXBean gc :
                java.lang.management.ManagementFactory.getGarbageCollectorMXBeans()) {
            long c = gc.getCollectionCount();
            if (c > 0) count += c;
        }
        return count;
    }

    private static long getUsedMemory() {
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    private static void forceGC() {
        System.gc();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.gc();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}