package metrics.benchmark;

import metrics.registry.MetricsRegistry;
import metrics.registry.RWLockMetricsRegistry;
import metrics.registry.StampedLockMetricsRegistry;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Benchmarking Harness: ReentrantReadWriteLock vs StampedLock
 *
 * Measures read and write throughput (operations/second) under concurrent load.
 *
 * Test Configuration:
 * - Multiple reader threads performing continuous get() operations
 * - Multiple writer threads performing continuous record() operations
 * - Fixed measurement duration (configurable)
 * - Warm-up phase to allow JIT compilation and steady-state behavior
 *
 * Expected Outcome:
 * StampedLock should significantly outperform ReentrantReadWriteLock on the
 * read path due to optimistic reads avoiding lock acquisition overhead.
 * The advantage is most pronounced under high read:write ratios.
 */
public class RegistryBenchmark {

    private static final int WARMUP_SECONDS = 2;
    private static final int MEASUREMENT_SECONDS = 5;
    private static final int NUM_READERS = 8;
    private static final int NUM_WRITERS = 2;
    private static final int NUM_METRICS = 100; // Pre-seeded metric names

    public static void run() {
        System.out.println("╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("║     REGISTRY BENCHMARK: ReentrantReadWriteLock vs StampedLock    ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════╝");
        System.out.println();
        System.out.printf("  Configuration: %d readers, %d writers, %ds warmup, %ds measurement%n",
                NUM_READERS, NUM_WRITERS, WARMUP_SECONDS, MEASUREMENT_SECONDS);
        System.out.printf("  Pre-seeded metrics: %d%n%n", NUM_METRICS);

        // Pre-generate metric names to avoid allocation during benchmark
        String[] metricNames = new String[NUM_METRICS];
        for (int i = 0; i < NUM_METRICS; i++) {
            metricNames[i] = "metric.throughput.counter." + i;
        }

        System.out.println("─── Approach A: ReentrantReadWriteLock ───────────────────────");
        BenchmarkResult rwLockResult = benchmark(new RWLockMetricsRegistry(), metricNames);
        printResult(rwLockResult);

        System.out.println();
        System.out.println("─── Approach B: StampedLock (Optimistic Reads) ──────────────");
        BenchmarkResult stampedResult = benchmark(new StampedLockMetricsRegistry(), metricNames);
        printResult(stampedResult);

        System.out.println();
        System.out.println("─── Comparison ──────────────────────────────────────────────");
        double readSpeedup = (double) stampedResult.readOps / rwLockResult.readOps;
        double writeSpeedup = (double) stampedResult.writeOps / rwLockResult.writeOps;
        System.out.printf("  Read Throughput Speedup:  %.2fx (StampedLock vs RWLock)%n", readSpeedup);
        System.out.printf("  Write Throughput Speedup: %.2fx (StampedLock vs RWLock)%n", writeSpeedup);
        System.out.printf("  Total Ops Speedup:        %.2fx%n",
                (double) (stampedResult.readOps + stampedResult.writeOps) /
                        (rwLockResult.readOps + rwLockResult.writeOps));
        System.out.println();
    }

    private static BenchmarkResult benchmark(MetricsRegistry registry, String[] metricNames) {
        // Pre-seed the registry
        for (int i = 0; i < metricNames.length; i++) {
            registry.record(metricNames[i], i * 1.0);
        }

        AtomicBoolean running = new AtomicBoolean(false);
        AtomicBoolean measuring = new AtomicBoolean(false);
        AtomicLong totalReadOps = new AtomicLong(0);
        AtomicLong totalWriteOps = new AtomicLong(0);
        CountDownLatch allReady = new CountDownLatch(NUM_READERS + NUM_WRITERS);
        CountDownLatch allDone = new CountDownLatch(NUM_READERS + NUM_WRITERS);

        // Spawn reader threads
        for (int r = 0; r < NUM_READERS; r++) {
            final int readerId = r;
            Thread reader = new Thread(() -> {
                long localOps = 0;
                int idx = readerId;
                allReady.countDown();

                // Spin until benchmark starts
                while (!running.get()) {
                    Thread.onSpinWait();
                }

                while (running.get()) {
                    registry.get(metricNames[idx % metricNames.length]);
                    idx++;
                    if (measuring.get()) {
                        localOps++;
                    }
                }
                totalReadOps.addAndGet(localOps);
                allDone.countDown();
            }, "reader-" + readerId);
            reader.setDaemon(true);
            reader.start();
        }

        // Spawn writer threads
        for (int w = 0; w < NUM_WRITERS; w++) {
            final int writerId = w;
            Thread writer = new Thread(() -> {
                long localOps = 0;
                int idx = writerId;
                double value = 0.0;
                allReady.countDown();

                while (!running.get()) {
                    Thread.onSpinWait();
                }

                while (running.get()) {
                    registry.record(metricNames[idx % metricNames.length], value);
                    idx++;
                    value += 1.0;
                    if (measuring.get()) {
                        localOps++;
                    }
                }
                totalWriteOps.addAndGet(localOps);
                allDone.countDown();
            }, "writer-" + writerId);
            writer.setDaemon(true);
            writer.start();
        }

        try {
            // Wait for all threads to be ready
            allReady.await();

            // Start warm-up phase
            running.set(true);
            Thread.sleep(WARMUP_SECONDS * 1000L);

            // Start measurement phase
            measuring.set(true);
            Thread.sleep(MEASUREMENT_SECONDS * 1000L);

            // Stop
            running.set(false);
            allDone.await();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new RuntimeException("Benchmark interrupted", e);
        }

        return new BenchmarkResult(
                totalReadOps.get(),
                totalWriteOps.get(),
                MEASUREMENT_SECONDS
        );
    }

    private static void printResult(BenchmarkResult result) {
        System.out.printf("  Read Ops:     %,15d total | %,12d ops/sec%n",
                result.readOps, result.readOps / result.durationSec);
        System.out.printf("  Write Ops:    %,15d total | %,12d ops/sec%n",
                result.writeOps, result.writeOps / result.durationSec);
        System.out.printf("  Total Ops:    %,15d total | %,12d ops/sec%n",
                result.readOps + result.writeOps,
                (result.readOps + result.writeOps) / result.durationSec);
    }

    static class BenchmarkResult {
        final long readOps;
        final long writeOps;
        final int durationSec;

        BenchmarkResult(long readOps, long writeOps, int durationSec) {
            this.readOps = readOps;
            this.writeOps = writeOps;
            this.durationSec = durationSec;
        }
    }
}