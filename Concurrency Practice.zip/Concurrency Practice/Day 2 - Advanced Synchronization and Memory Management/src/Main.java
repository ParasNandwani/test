import metrics.benchmark.RegistryBenchmark;
import metrics.benchmark.RingBufferBenchmark;

/**
 * High-Throughput Metrics Ingestion Pipeline — Benchmark Runner
 *
 * Day 2: Advanced Synchronization and Memory Management
 *
 * This entry point orchestrates two benchmark suites:
 * 1. Registry Benchmark: ReentrantReadWriteLock vs StampedLock (optimistic reads)
 * 2. Ring Buffer Benchmark: Pre-allocated SPSC Ring Buffer vs Dynamic Allocation
 *
 * Run with: javac -d out src/**\/*.java && java -cp out Main
 */
public class Main {

    public static void main(String[] args) {
        System.out.println();
        System.out.println("████████████████████████████████████████████████████████████████");
        System.out.println("██  HIGH-THROUGHPUT METRICS INGESTION PIPELINE                ██");
        System.out.println("██  Advanced Synchronization & Memory Management Benchmarks   ██");
        System.out.println("████████████████████████████████████████████████████████████████");
        System.out.println();
        System.out.printf("  JVM: %s %s%n",
                System.getProperty("java.vm.name"),
                System.getProperty("java.vm.version"));
        System.out.printf("  OS:  %s %s (%s)%n",
                System.getProperty("os.name"),
                System.getProperty("os.version"),
                System.getProperty("os.arch"));
        System.out.printf("  CPUs: %d available processors%n",
                Runtime.getRuntime().availableProcessors());
        System.out.printf("  Heap: %,d MB max%n",
                Runtime.getRuntime().maxMemory() / (1024 * 1024));
        System.out.println();

        // ─── Benchmark 1: Lock Strategy Comparison ───────────────────────
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println("  BENCHMARK 1: Lock Strategy Comparison");
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println();
        RegistryBenchmark.run();

        // ─── Benchmark 2: Memory/GC Pressure Comparison ──────────────────
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println("  BENCHMARK 2: Memory & GC Pressure Comparison");
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println();
        RingBufferBenchmark.run();

        // ─── Summary ─────────────────────────────────────────────────────
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println("  BENCHMARKS COMPLETE");
        System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        System.out.println();
        System.out.println("  Key Takeaways:");
        System.out.println("  • StampedLock optimistic reads eliminate lock acquisition overhead");
        System.out.println("    on the read path — critical for read-heavy metrics systems.");
        System.out.println("  • Pre-allocated ring buffers eliminate per-event heap allocation,");
        System.out.println("    reducing GC pressure and tail latency in ingestion pipelines.");
        System.out.println("  • Lock-free SPSC design removes thread parking/unparking overhead");
        System.out.println("    and enables sub-microsecond message passing between threads.");
        System.out.println();
    }
}