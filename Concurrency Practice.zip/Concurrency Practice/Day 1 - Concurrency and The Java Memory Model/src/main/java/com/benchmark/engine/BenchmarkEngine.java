package com.benchmark.engine;

import com.benchmark.counter.Counter;
import com.benchmark.counter.FalseSharingCounter;
import com.benchmark.counter.PaddedCounter;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

/**
 * Benchmarking engine responsible for spawning threads, coordinating execution,
 * measuring elapsed time, and reporting results.
 *
 * <h2>Design (SRP)</h2>
 * <p>This class knows <em>how</em> to benchmark but knows nothing about <em>what</em>
 * counter strategy is being used. It accepts any {@link Counter} implementation.</p>
 *
 * <h2>Coordination Strategy</h2>
 * <ol>
 *   <li><b>CyclicBarrier:</b> all threads wait at a barrier before starting.
 *       This ensures the timer starts only when all threads are ready to run,
 *       eliminating thread-creation skew from the measurement.</li>
 *   <li><b>CountDownLatch:</b> main thread waits for all worker threads to finish
 *       before stopping the timer.</li>
 * </ol>
 *
 * <h2>Warmup</h2>
 * <p>We run a configurable number of warmup iterations before the measured run.
 * This allows the JIT compiler (C2) to compile hot loops and for the CPU branch
 * predictor to stabilize.</p>
 */
public final class BenchmarkEngine {

    private final int numThreads;
    private final long incrementsPerThread;
    private final int warmupIterations;

    /**
     * @param numThreads         number of concurrent threads
     * @param incrementsPerThread number of increments each thread performs
     * @param warmupIterations   number of untimed iterations for JIT warmup
     */
    public BenchmarkEngine(int numThreads, long incrementsPerThread, int warmupIterations) {
        this.numThreads = numThreads;
        this.incrementsPerThread = incrementsPerThread;
        this.warmupIterations = warmupIterations;
    }

    /**
     * Runs the benchmark for the given counter.
     *
     * @param counter the counter implementation to benchmark
     * @return the result containing elapsed time and final count
     */
    public BenchmarkResult run(Counter counter) {
        // Warmup phase — JIT compilation + branch predictor training
        for (int i = 0; i < warmupIterations; i++) {
            executeRun(counter);
            counter.reset();
        }

        // Measured phase
        long startNanos = System.nanoTime();
        executeRun(counter);
        long elapsedNanos = System.nanoTime() - startNanos;

        long finalCount = counter.get();
        return new BenchmarkResult(counter.name(), elapsedNanos, finalCount, numThreads * incrementsPerThread);
    }

    /**
     * Spawns threads and runs the counter workload.
     */
    private void executeRun(Counter counter) {
        // Barrier ensures all threads start simultaneously
        CyclicBarrier startBarrier = new CyclicBarrier(numThreads);
        CountDownLatch doneLatch = new CountDownLatch(numThreads);

        Thread[] threads = new Thread[numThreads];

        for (int t = 0; t < numThreads; t++) {
            final int threadIndex = t;
            threads[t] = new Thread(() -> {
                try {
                    startBarrier.await(); // Wait for all threads to be ready
                } catch (Exception e) {
                    Thread.currentThread().interrupt();
                    return;
                }

                // Execute increments — branch on counter type for index-based access
                if (counter instanceof FalseSharingCounter) {
                    FalseSharingCounter fsc = (FalseSharingCounter) counter;
                    for (long i = 0; i < incrementsPerThread; i++) {
                        fsc.increment(threadIndex);
                    }
                } else if (counter instanceof PaddedCounter) {
                    PaddedCounter pc = (PaddedCounter) counter;
                    for (long i = 0; i < incrementsPerThread; i++) {
                        pc.increment(threadIndex);
                    }
                } else {
                    for (long i = 0; i < incrementsPerThread; i++) {
                        counter.increment();
                    }
                }

                doneLatch.countDown();
            }, "Worker-" + threadIndex);

            threads[t].start();
        }

        try {
            doneLatch.await(); // Wait for all threads to finish
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /**
     * Immutable result of a benchmark run.
     */
    public static final class BenchmarkResult {
        private final String counterName;
        private final long elapsedNanos;
        private final long finalCount;
        private final long expectedCount;

        public BenchmarkResult(String counterName, long elapsedNanos, long finalCount, long expectedCount) {
            this.counterName = counterName;
            this.elapsedNanos = elapsedNanos;
            this.finalCount = finalCount;
            this.expectedCount = expectedCount;
        }

        public String getCounterName() {
            return counterName;
        }

        public long getElapsedNanos() {
            return elapsedNanos;
        }

        public double getElapsedMillis() {
            return elapsedNanos / 1_000_000.0;
        }

        public long getFinalCount() {
            return finalCount;
        }

        public long getExpectedCount() {
            return expectedCount;
        }

        public boolean isCorrect() {
            return finalCount == expectedCount;
        }

        @Override
        public String toString() {
            return String.format(
                "%-38s | Time: %,10.2f ms | Count: %,d | Correct: %s",
                counterName,
                getElapsedMillis(),
                finalCount,
                isCorrect() ? "✓" : "✗ (expected " + expectedCount + ")"
            );
        }
    }
}