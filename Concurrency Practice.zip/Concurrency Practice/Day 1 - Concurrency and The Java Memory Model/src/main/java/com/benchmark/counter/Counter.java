package com.benchmark.counter;

/**
 * Contract for all thread-safe counter implementations.
 *
 * <p>Each implementation demonstrates a different concurrency strategy:
 * mutual exclusion (locks), lock-free CAS, or per-thread striping.</p>
 */
public interface Counter {

    /**
     * Atomically increments the counter by one.
     */
    void increment();

    /**
     * Returns the current value of the counter.
     * For striped counters, this aggregates all per-thread slots.
     *
     * @return the accumulated count
     */
    long get();

    /**
     * Resets the counter to zero (used between benchmark iterations).
     */
    void reset();

    /**
     * Human-readable name for reporting.
     *
     * @return implementation name
     */
    String name();
}