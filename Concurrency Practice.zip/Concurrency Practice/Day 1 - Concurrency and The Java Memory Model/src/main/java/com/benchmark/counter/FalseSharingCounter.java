package com.benchmark.counter;

/**
 * Demonstrates the "False Sharing" problem.
 *
 * <h2>What is False Sharing?</h2>
 * <p>Modern CPUs transfer memory in <b>cache lines</b> (typically 64 bytes on x86,
 * 128 bytes on Apple Silicon). When two independent variables happen to reside on
 * the <em>same</em> cache line, a write to one variable invalidates the entire line
 * for all other cores — even though the other cores are accessing a <em>different</em>
 * variable on that same line.</p>
 *
 * <h2>How this class triggers it</h2>
 * <ul>
 *   <li>We allocate an array of 8 {@code volatile long} values: {@code slots[0..7]}.</li>
 *   <li>8 longs = 64 bytes — they fit neatly in a <b>single cache line</b>.</li>
 *   <li>Each thread only writes to its own {@code slots[threadIndex]}, so logically
 *       there is <em>zero</em> data sharing.</li>
 *   <li>But physically, every write by any thread causes an <b>MESI Invalidate</b>
 *       message to every other core that has the line cached, forcing them to re-fetch
 *       from L3 or the interconnect.</li>
 * </ul>
 *
 * <h2>Performance impact</h2>
 * <p>Despite each thread being independent, performance degrades to near-AtomicLong
 * levels (or worse) because the hardware treats it as a shared-write scenario.
 * Compare with {@link PaddedCounter} to see the fix.</p>
 *
 * <h2>MESI state transitions (per write)</h2>
 * <pre>
 * Core 0 writes slots[0]:
 *   Core 0: Invalid → Modified
 *   Core 1-7: Modified/Exclusive/Shared → Invalid  (snoop invalidate)
 *
 * Core 1 writes slots[1]:
 *   Core 1: Invalid → Modified  (must fetch line from Core 0 or L3)
 *   Core 0: Modified → Invalid
 *   Core 2-7: already Invalid (no-op)
 * </pre>
 * <p>This "ping-pong" between cores is extremely expensive — each transition
 * costs 40-100+ ns depending on the interconnect topology.</p>
 */
public final class FalseSharingCounter implements Counter {

    /**
     * All 8 slots packed together. On most JVMs, this array's data will sit
     * within 1-2 cache lines, causing massive cross-core invalidation traffic.
     */
    private final long[] slots;
    private final int numThreads;

    public FalseSharingCounter(int numThreads) {
        this.numThreads = numThreads;
        this.slots = new long[numThreads];
    }

    /**
     * Each thread calls this with its own index (0..7).
     * Despite being logically independent, writes cause cache-line invalidation
     * for ALL other cores sharing this line.
     */
    public void increment(int threadIndex) {
        slots[threadIndex]++;
    }

    /**
     * Default increment — uses thread-local index via thread ID hashing.
     * For the benchmark engine, we use {@link #increment(int)} directly.
     */
    @Override
    public void increment() {
        int index = (int) (Thread.currentThread().getId() % numThreads);
        slots[index]++;
    }

    @Override
    public long get() {
        long sum = 0;
        for (int i = 0; i < numThreads; i++) {
            sum += slots[i];
        }
        return sum;
    }

    @Override
    public void reset() {
        for (int i = 0; i < numThreads; i++) {
            slots[i] = 0L;
        }
    }

    @Override
    public String name() {
        return "False Sharing Counter (unpadded)";
    }

    public int getNumThreads() {
        return numThreads;
    }
}