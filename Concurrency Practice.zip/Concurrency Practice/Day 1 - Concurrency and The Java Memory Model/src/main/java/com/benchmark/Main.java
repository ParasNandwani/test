package com.benchmark;

import com.benchmark.counter.*;
import com.benchmark.engine.BenchmarkEngine;
import com.benchmark.engine.BenchmarkEngine.BenchmarkResult;

import java.util.ArrayList;
import java.util.List;

/**
 * Entry point for the counter benchmark suite.
 *
 * <p>Wires together counter implementations and the benchmark engine,
 * then prints a formatted comparison table.</p>
 *
 * <h2>Parameters</h2>
 * <ul>
 *   <li>Threads: 8</li>
 *   <li>Increments per thread: 10,000,000</li>
 *   <li>Warmup iterations: 2</li>
 * </ul>
 */
public final class Main {

    private static final int NUM_THREADS = 8;
    private static final long INCREMENTS_PER_THREAD = 10_000_000L;
    private static final int WARMUP_ITERATIONS = 2;

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════════════════════════════════════╗");
        System.out.println("║          CONCURRENT COUNTER BENCHMARK — Cache Lines & Contention             ║");
        System.out.println("╠══════════════════════════════════════════════════════════════════════════════╣");
        System.out.printf("║  Threads: %-4d | Increments/thread: %,14d | Warmup: %d iterations    ║%n",
                NUM_THREADS, INCREMENTS_PER_THREAD, WARMUP_ITERATIONS);
        System.out.printf("║  Total expected increments: %,d                                       ║%n",
                NUM_THREADS * INCREMENTS_PER_THREAD);
        System.out.println("╠══════════════════════════════════════════════════════════════════════════════╣");
        System.out.printf("║  Java: %-20s | OS: %-15s | Arch: %-10s         ║%n",
                System.getProperty("java.version"),
                System.getProperty("os.name"),
                System.getProperty("os.arch"));
        System.out.printf("║  Available processors: %-4d                                                  ║%n",
                Runtime.getRuntime().availableProcessors());
        System.out.println("╚══════════════════════════════════════════════════════════════════════════════╝");
        System.out.println();

        // Create benchmark engine
        BenchmarkEngine engine = new BenchmarkEngine(NUM_THREADS, INCREMENTS_PER_THREAD, WARMUP_ITERATIONS);

        // Create counter implementations
        List<Counter> counters = new ArrayList<>();
        counters.add(new SynchronizedCounter());
        counters.add(new AtomicCounter());
        counters.add(new FalseSharingCounter(NUM_THREADS));
        counters.add(new PaddedCounter(NUM_THREADS));

        // Run benchmarks
        List<BenchmarkResult> results = new ArrayList<>();
        for (Counter counter : counters) {
            System.out.printf("  ▶ Running: %s ...%n", counter.name());
            BenchmarkResult result = engine.run(counter);
            results.add(result);
            System.out.printf("    ✓ Done: %.2f ms%n%n", result.getElapsedMillis());
        }

        // Print results table
        System.out.println("┌────────────────────────────────────────────────────────────────────────────────────────────────┐");
        System.out.println("│                                       RESULTS SUMMARY                                          │");
        System.out.println("├────────────────────────────────────────────────────────────────────────────────────────────────┤");

        // Find fastest for relative comparison
        double fastestMs = results.stream()
                .mapToDouble(BenchmarkResult::getElapsedMillis)
                .min()
                .orElse(1.0);

        for (BenchmarkResult result : results) {
            double slowdown = result.getElapsedMillis() / fastestMs;
            System.out.printf("│  %s │%n", result);
            System.out.printf("│  %38s   Relative: %.2fx slower than fastest%n", "", slowdown);
            System.out.println("├────────────────────────────────────────────────────────────────────────────────────────────────┤");
        }

        System.out.println("└────────────────────────────────────────────────────────────────────────────────────────────────┘");
        System.out.println();

        // Print analysis hints
        printAnalysis(results);
    }

    private static void printAnalysis(List<BenchmarkResult> results) {
        System.out.println("┌──────────────────────────────────────────────────────────────────────────────┐");
        System.out.println("│                           PERFORMANCE ANALYSIS                               │");
        System.out.println("├──────────────────────────────────────────────────────────────────────────────┤");
        System.out.println("│                                                                              │");
        System.out.println("│  WHY IS ReentrantLock SLOWEST?                                               │");
        System.out.println("│  • Lock acquisition → OS context switch when contended (~1-10 µs each)       │");
        System.out.println("│  • Only 1 thread makes progress at a time (serialized execution)             │");
        System.out.println("│  • park/unpark syscalls + kernel scheduler overhead                          │");
        System.out.println("│                                                                              │");
        System.out.println("│  WHY IS AtomicLong FASTER THAN LOCKS BUT SLOWER THAN PADDED?                 │");
        System.out.println("│  • No OS context switches (pure user-space spin)                             │");
        System.out.println("│  • But: single cache line shared by all 8 cores → MESI invalidation storm    │");
        System.out.println("│  • CAS failures force retries (wasted cycles + interconnect traffic)         │");
        System.out.println("│                                                                              │");
        System.out.println("│  WHY DOES FALSE SHARING HURT?                                                │");
        System.out.println("│  • Logically independent writes, physically on same cache line               │");
        System.out.println("│  • Hardware treats it as shared-write → full invalidation protocol           │");
        System.out.println("│  • Performance similar to (or worse than) a single AtomicLong                │");
        System.out.println("│                                                                              │");
        System.out.println("│  WHY IS PADDED COUNTER FASTEST?                                              │");
        System.out.println("│  • Each thread's slot on its own cache line → zero coherence traffic         │");
        System.out.println("│  • No locks, no CAS, no invalidation → pure register-to-memory increment     │");
        System.out.println("│  • Effectively single-threaded speed × N threads (linear scaling)            │");
        System.out.println("│                                                                              │");
        System.out.println("└──────────────────────────────────────────────────────────────────────────────┘");

        // Correctness warnings
        System.out.println();
        for (BenchmarkResult result : results) {
            if (!result.isCorrect()) {
                System.out.printf("  ⚠ WARNING: %s produced incorrect count! Got %,d, expected %,d%n",
                        result.getCounterName(), result.getFinalCount(), result.getExpectedCount());
                System.out.println("    → This indicates a race condition (expected for non-atomic per-thread counters");
                System.out.println("      when thread IDs collide on modulo mapping. The benchmark engine uses explicit");
                System.out.println("      thread indices to avoid this — if you see this, there may be a bug.)");
                System.out.println();
            }
        }
    }
}