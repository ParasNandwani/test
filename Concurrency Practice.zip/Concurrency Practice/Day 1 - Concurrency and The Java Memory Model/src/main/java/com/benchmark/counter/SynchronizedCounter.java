package com.benchmark.counter;

import java.util.concurrent.locks.ReentrantLock;

/**
 * A thread-safe counter guarded by a {@link ReentrantLock}.
 *
 * <h2>How it works</h2>
 * <ul>
 *   <li>Every call to {@link #increment()} acquires the lock, updates the plain
 *       {@code long} field, then releases the lock.</li>
 *   <li>Under high contention (8 threads × 10M ops), most threads spin briefly
 *       then park via {@code LockSupport.park()}, which triggers an OS context
 *       switch (involuntary or voluntary).</li>
 * </ul>
 *
 * <h2>Why it's slow under contention</h2>
 * <ol>
 *   <li><b>OS context switches:</b> parking/unparking threads costs ~1-10 µs each,
 *       and the kernel scheduler must choose which thread to wake.</li>
 *   <li><b>Memory fence on lock release:</b> the JMM requires a store-load fence,
 *       flushing the store buffer and invalidating remote cache lines.</li>
 *   <li><b>Serialization:</b> only one thread can make progress at any time;
 *       the effective throughput is bounded by single-core speed + lock overhead.</li>
 * </ol>
 */
public final class SynchronizedCounter implements Counter {

    private final ReentrantLock lock = new ReentrantLock();
    private long count = 0L;

    @Override
    public void increment() {
        lock.lock();
        try {
            count++;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public long get() {
        lock.lock();
        try {
            return count;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void reset() {
        lock.lock();
        try {
            count = 0L;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String name() {
        return "ReentrantLock Counter";
    }
}