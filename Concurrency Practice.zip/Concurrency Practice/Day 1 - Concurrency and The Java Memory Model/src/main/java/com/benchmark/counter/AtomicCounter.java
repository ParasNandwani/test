package com.benchmark.counter;

import java.util.concurrent.atomic.AtomicLong;

/**
 * A lock-free thread-safe counter backed by {@link AtomicLong}.
 *
 * <h2>How it works</h2>
 * <ul>
 *   <li>{@code AtomicLong.incrementAndGet()} uses a Compare-And-Swap (CAS) loop
 *       internally: read current value → compute new value → CAS(expected, new).
 *       If CAS fails (another thread wrote first), retry.</li>
 *   <li>No OS-level blocking ever occurs — threads never park. This is "lock-free"
 *       because at least one thread always makes progress.</li>
 * </ul>
 *
 * <h2>Why it's faster than locks but still not perfect</h2>
 * <ol>
 *   <li><b>No context switches:</b> failed CAS simply retries in user-space.
 *       No kernel involvement.</li>
 *   <li><b>Cache-line bouncing (MESI protocol):</b> the single {@code AtomicLong}
 *       lives on one cache line. When core 0 writes, all other cores' copies move
 *       to Invalid state. The next core that attempts CAS must fetch the line from
 *       L3 or the remote core's L1/L2 (costs ~40-80 ns on modern x86).</li>
 *   <li><b>CAS failures under high contention:</b> with 8 threads hammering the
 *       same variable, the probability of CAS success on first try drops.
 *       Each retry wastes a CPU cycle and causes another round-trip on the
 *       interconnect.</li>
 * </ol>
 *
 * <h2>When to use</h2>
 * Best for moderate contention. Under extreme write pressure, consider
 * {@code LongAdder} which stripes across multiple cells (similar to our
 * {@link PaddedCounter} approach).
 */
public final class AtomicCounter implements Counter {

    private final AtomicLong count = new AtomicLong(0L);

    @Override
    public void increment() {
        count.incrementAndGet();
    }

    @Override
    public long get() {
        return count.get();
    }

    @Override
    public void reset() {
        count.set(0L);
    }

    @Override
    public String name() {
        return "AtomicLong (CAS) Counter";
    }
}