package com.benchmark.counter;

/**
 * Eliminates false sharing by padding each thread's counter slot to occupy
 * its own cache line.
 *
 * <h2>The Fix: Cache-Line Padding</h2>
 * <p>Instead of packing all counters into adjacent memory (like {@link FalseSharingCounter}),
 * we ensure each counter occupies at least 128 bytes (to cover both Intel's 64-byte
 * and Apple Silicon's 128-byte cache lines). This way, a write by one core
 * <b>never</b> invalidates another core's cache line.</p>
 *
 * <h2>Memory Layout</h2>
 * <pre>
 * ┌─────────────────────────────────────────────────────────────────────────────────┐
 * │ Cache Line 0 (128 bytes)                                                        │
 * │  [pad0..pad6][value0][pad7..pad14]                                              │
 * ├─────────────────────────────────────────────────────────────────────────────────┤
 * │ Cache Line 1 (128 bytes)                                                        │
 * │  [pad0..pad6][value1][pad7..pad14]                                              │
 * ├─────────────────────────────────────────────────────────────────────────────────┤
 * │ ...                                                                             │
 * └─────────────────────────────────────────────────────────────────────────────────┘
 * </pre>
 *
 * <h2>MESI Behavior (Ideal)</h2>
 * <pre>
 * Core 0 writes to its padded slot:
 *   Core 0: Exclusive → Modified  (no snoop needed — no other core caches this line)
 *   Core 1-7: unaffected (their lines remain in Exclusive/Modified state)
 * </pre>
 * <p>Each core can stay in the Modified state indefinitely without generating
 * any interconnect traffic. This is as fast as single-threaded execution
 * because there is <b>zero coherence overhead</b>.</p>
 *
 * <h2>Expected Performance</h2>
 * <p>This should be the <b>fastest</b> implementation because:</p>
 * <ul>
 *   <li>No locks, no CAS, no atomic operations</li>
 *   <li>No cache-line invalidation (each core owns its line exclusively)</li>
 *   <li>Each thread's hot loop compiles down to a simple {@code inc [mem]} instruction</li>
 *   <li>The only cost is the final aggregation in {@link #get()}</li>
 * </ul>
 */
public final class PaddedCounter implements Counter {

    /**
     * Padding ensures each {@code value} field sits on its own cache line.
     * We use 128 bytes of separation (16 longs) to handle both 64-byte (x86)
     * and 128-byte (Apple M-series) cache line sizes.
     */
    private static final int CACHE_LINE_PADDING = 16; // 16 longs = 128 bytes

    /**
     * The padded array. For N threads, we allocate N * CACHE_LINE_PADDING longs.
     * Thread i writes to index i * CACHE_LINE_PADDING.
     * The remaining 15 longs per slot are dead padding.
     */
    private final long[] slots;
    private final int numThreads;

    public PaddedCounter(int numThreads) {
        this.numThreads = numThreads;
        // Each thread gets CACHE_LINE_PADDING longs of space
        this.slots = new long[numThreads * CACHE_LINE_PADDING];
    }

    /**
     * Increment with explicit thread index — no false sharing.
     * Thread i writes to slots[i * 16], which is on a different cache line
     * from slots[j * 16] for any j ≠ i.
     */
    public void increment(int threadIndex) {
        slots[threadIndex * CACHE_LINE_PADDING]++;
    }

    @Override
    public void increment() {
        int index = (int) (Thread.currentThread().getId() % numThreads);
        slots[index * CACHE_LINE_PADDING]++;
    }

    @Override
    public long get() {
        long sum = 0;
        for (int i = 0; i < numThreads; i++) {
            sum += slots[i * CACHE_LINE_PADDING];
        }
        return sum;
    }

    @Override
    public void reset() {
        for (int i = 0; i < numThreads; i++) {
            slots[i * CACHE_LINE_PADDING] = 0L;
        }
    }

    @Override
    public String name() {
        return "Padded Counter (no false sharing)";
    }

    public int getNumThreads() {
        return numThreads;
    }
}