# Day 1: Concurrency and The Java Memory Model

 **Purpose:** A hands-on study tool for Staff-level Systems Programming interviews.  
 **Focus Areas:** Lock contention, CAS semantics, false sharing, MESI protocol, CPU cache architecture, OS scheduling.

---

## The Interview Question

> *"Design a shared counter that 8 threads can increment concurrently to a total of 80 million. It must be correct AND fast. Walk me through multiple approaches, their trade-offs, and what happens at the hardware level."*

**What the interviewer is testing:**
- Do you understand CPU cache architecture and why naive sharing is slow?
- Can you explain CAS, lock-free algorithms, and their failure modes?
- Do you know what false sharing is and how to eliminate it?
- Can you articulate the Java Memory Model's happens-before guarantees?

**The rest of this document builds your complete answer.**

---

## Part 1: Before You Start — What You Should Already Know

This is **Day 1** of the course — it teaches concurrency from the hardware up. However, the following baseline knowledge is assumed:

| You should know... | We will NOT cover... |
|-------------------|---------------------|
| Basic Java syntax (classes, methods, loops, generics) | Java language fundamentals |
| What a `Thread` is at a high level (you've seen `new Thread()` before) | How to write "Hello World" in Java |
| How to run a Java program (JDK installed, can compile and run) | IDE setup, JDK installation |
| Basic data structures (arrays, maps, lists) | Collections API tutorial |
| What "heap" and "stack" mean at a conceptual level | Deep JVM internals (GC tuning, classloading) |

**What Day 1 WILL teach you (even if you think you already know it):**
- Why `count++` isn't safe across threads (at the hardware instruction level)
- What actually happens inside a CPU when two cores access the same variable
- Why some "obviously correct" concurrent code is silently broken
- The exact cost (in nanoseconds) of locks, CAS, and cache misses

If you can write a basic Java program and have a vague sense that "threads can cause problems," you have enough background. Everything else is built from first principles in the sections below.

---

## Table of Contents

1. [Part 1: Before You Start — What You Should Already Know](#part-1-before-you-start--what-you-should-already-know)
2. [Part 2: Foundational Concepts](#part-2-foundational-concepts)
3. [Part 3: The Benchmark — What We're Testing](#part-3-the-benchmark--what-were-testing)
4. [Part 4: Counter Implementations](#part-4-counter-implementations)
5. [Part 5: Results & Analysis](#part-5-results--analysis)
6. [Part 6: Interview Talking Points](#part-6-interview-talking-points)
7. [How to Run](#how-to-run)
8. [Directory Structure](#directory-structure)
9. [Further Reading](#further-reading)

---

## Part 2: Foundational Concepts

Before diving into the benchmark code, let's establish the foundational concepts you'll need. Each subsequent section builds on the previous one. If you're already comfortable with a topic, feel free to skim — but the concepts are interconnected, so a quick refresher never hurts.

---

### 2.1 What is a Thread?

#### Definition

A **thread** is the smallest unit of execution that an operating system can schedule. A single process (like our Java program) can have many threads, all sharing the same memory space but each having its own:

- **Program Counter (PC):** Which instruction to execute next
- **Stack:** Local variables, method call chain
- **Register state:** The CPU register values when this thread is running

#### User-Space Threads vs Kernel Threads

| Type | Managed By | Scheduled By | Context Switch Cost |
|------|-----------|-------------|---------------------|
| Kernel Thread (1:1) | OS kernel | OS scheduler | High (~1-10 µs) |
| User Thread (Green/Virtual) | Runtime (e.g., JVM) | Runtime scheduler | Low (~100 ns) |

**In standard Java (before Project Loom):** Each `new Thread()` creates a kernel thread — a 1:1 mapping. This means the OS is responsible for deciding which thread runs on which core, and switching between threads is expensive.

#### Thread States in Java

```
                 ┌─────────┐
        start()  │         │  run() completes
  NEW ──────────►│ RUNNABLE├─────────────────► TERMINATED
                 │         │
                 └────┬────┘
                      │
         ┌────────────┼─────────────┐
         │            │             │
         ▼            ▼             ▼
    ┌─────────┐  ┌─────────┐  ┌──────────┐
    │ BLOCKED │  │ WAITING │  │TIMED_WAIT│
    │(monitor)│  │(park)   │  │(sleep)   │
    └─────────┘  └─────────┘  └──────────┘
```

- **RUNNABLE:** The thread is eligible to run. On a machine with N cores, at most N threads are *actually* executing simultaneously — the rest are waiting in the OS run queue.
- **BLOCKED:** Waiting to acquire a `synchronized` monitor.
- **WAITING:** Parked via `LockSupport.park()`, `Object.wait()`, etc.

#### What "Concurrent" Really Means

On a machine with 8 cores:
- At most **8 threads** can truly execute CPU instructions simultaneously
- If you have more than 8 runnable threads, the OS **time-slices** them — rapidly switching between them to create the *illusion* of parallelism
- Each switch is a **context switch** (defined in Section 2.4)

**Key insight for this benchmark:** We use exactly 8 threads on a machine with ~10 cores, so all threads can genuinely run in parallel. The bottleneck is NOT scheduling — it's how the threads interact at the hardware level.

---

### 2.2 CPU Architecture Primer

#### The Memory Wall Problem

Modern CPUs can execute billions of instructions per second (~3-5 GHz clock), but main memory (DRAM) takes **~100 nanoseconds** to respond to a read request. That's ~300-500 wasted CPU cycles just *waiting for data*.

**Solution:** A hierarchy of small, fast memory (caches) between the CPU core and main memory.

#### The Cache Hierarchy

```
┌──────────────────────────────────────────────────────┐
│                  Main Memory (DRAM)                  │
│                  Size: 8-64 GB                       │
│                  Latency: ~100 ns (~300 cycles)      │
└──────────────────────────┬───────────────────────────┘
                           │
┌──────────────────────────┴───────────────────────────┐
│               L3 Cache (Shared across all cores)     │
│               Size: 8-64 MB                          │
│               Latency: ~10-40 ns (~30-120 cycles)    │
└───────┬──────────────────┬──────────────────┬────────┘
        │                  │                  │
┌───────┴───────┐  ┌───────┴───────┐  ┌───────┴───────┐
│  L2 Cache     │  │  L2 Cache     │  │  L2 Cache     │
│  (Per-core)   │  │  (Per-core)   │  │  (Per-core)   │
│  Size: 256KB  │  │  Size: 256KB  │  │  Size: 256KB  │
│  Latency: ~5ns│  │  Latency: ~5ns│  │  Latency: ~5ns│
├───────────────┤  ├───────────────┤  ├───────────────┤
│  L1 Data Cache│  │  L1 Data Cache│  │  L1 Data Cache│
│  (Per-core)   │  │  (Per-core)   │  │  (Per-core)   │
│  Size: 32-64KB│  │  Size: 32-64KB│  │  Size: 32-64KB│
│  Latency: ~1ns│  │  Latency: ~1ns│  │  Latency: ~1ns│
├───────────────┤  ├───────────────┤  ├───────────────┤
│    Core 0     │  │    Core 1     │  │    Core 2     │
└───────────────┘  └───────────────┘  └───────────────┘
```

**Key observations:**
- L1 and L2 are **private** to each core — Core 0 cannot directly read Core 1's L1 cache
- L3 is **shared** — all cores can access it, but it's slower than L1/L2
- When a core needs data, it checks L1 → L2 → L3 → DRAM (stopping at the first hit)

#### What is a Cache Line?

A **cache line** is the minimum unit of data transfer between levels of the cache hierarchy. The CPU never fetches a single byte — it always fetches an entire cache line.

| Platform | Cache Line Size | Longs per Line |
|----------|----------------|----------------|
| Intel x86-64 | 64 bytes | 8 longs |
| AMD x86-64 | 64 bytes | 8 longs |
| Apple M1/M2/M3 | 128 bytes | 16 longs |
| AWS Graviton (ARM) | 64 bytes | 8 longs |

**Example:** If your program reads `array[0]`, the CPU doesn't just fetch that 8-byte `long` — it fetches the entire 64-byte (or 128-byte) block containing it. This means `array[0]` through `array[7]` all get loaded into the cache together, whether you asked for them or not.

**Why this matters:** If two threads on different cores are writing to `array[0]` and `array[1]` respectively, they're writing to the *same cache line*. This creates a problem called **false sharing** (explained in Section 2.7).

#### Latency Comparison (Putting It in Perspective)

| Operation | Latency | Relative (if L1 = 1 second) |
|-----------|---------|------------------------------|
| L1 cache hit | ~1 ns | 1 second |
| L2 cache hit | ~5 ns | 5 seconds |
| L3 cache hit | ~10-40 ns | 10-40 seconds |
| Main memory (DRAM) | ~100 ns | 1.5 minutes |
| Context switch | ~1,000-10,000 ns | 15 minutes to 2.5 hours |

---

### 2.3 Cache Coherence & The MESI Protocol

#### The Problem: Multiple Copies, One Truth

Now that we know each core has its own private L1/L2 cache (Section 2.2), we face a critical question:

> If Core 0 writes value `42` to address X in its L1 cache, and Core 1 has a stale copy of address X with value `41` — how do we prevent Core 1 from reading the wrong value?

This is the **cache coherence problem**. The hardware must ensure that all cores see a consistent view of memory, even though data exists in multiple caches simultaneously.

#### What is MESI?

**MESI** is the cache coherence protocol used by most modern multi-core CPUs. It's named after the four states a cache line can be in:

| State | Letter | Meaning | Can This Core Read? | Can This Core Write? | Other Cores Have Copies? |
|-------|--------|---------|---------------------|----------------------|--------------------------|
| **Modified** | M | This core wrote to it; main memory is stale | ✅ Yes | ✅ Yes | ❌ No (all others are Invalid) |
| **Exclusive** | E | Only this core has it; matches main memory | ✅ Yes | ✅ Yes (transitions to M) | ❌ No |
| **Shared** | S | Multiple cores have identical copies | ✅ Yes | ❌ No (must invalidate others first) | ✅ Yes |
| **Invalid** | I | This copy is stale / not present | ❌ No (must re-fetch) | ❌ No (must re-fetch) | — |

#### How Cores Communicate: Snooping

Cores communicate about cache line ownership through a mechanism called **snooping** (or a directory-based protocol on larger systems). Each core "listens" on a shared bus for messages from other cores:

- **"I want to read address X"** — If another core has it in Modified state, that core must supply the data and transition to Shared
- **"I want to write to address X"** — All other cores holding this line must transition to Invalid

#### MESI State Transitions (Walkthrough)

Let's trace what happens with a shared variable accessed by two cores:

```
Step 1: Core 0 reads variable X (first access)
─────────────────────────────────────────────
  • Data fetched from main memory
  • Core 0's cache line state: Exclusive (only copy)
  • Core 1's cache line state: (not present)

Step 2: Core 1 reads variable X
─────────────────────────────────────────────
  • Core 1 issues read request on bus
  • Core 0 snoops the request, sees it has the line
  • Both cores transition to: Shared
  • Now both cores have identical, read-only copies

Step 3: Core 0 writes to variable X
─────────────────────────────────────────────
  • Core 0 needs exclusive access to write
  • Core 0 sends "invalidate" message on bus
  • Core 1 snoops, transitions its copy to: Invalid
  • Core 0 transitions to: Modified
  • Core 0 can now write freely (it's the only valid copy)

Step 4: Core 1 wants to read variable X
─────────────────────────────────────────────
  • Core 1's copy is Invalid, must re-fetch
  • Core 0 has the only valid copy (Modified)
  • Core 0 writes back to L3/memory, transitions to: Shared
  • Core 1 fetches from L3, transitions to: Shared
  • COST: ~40-80 ns for this round-trip!
```

#### State Transition Diagram

```
                    ┌──────────┐
        Read hit    │          │  Write hit
       ┌───────────►│ Modified ├◄───────────┐
       │            │   (M)    │            │
       │            └────┬─────┘            │
       │                 │                  │
       │     Other core  │                  │
       │     reads →     │ write-back       │
       │     supply data │ to L3            │
       │                 ▼                  │
       │            ┌──────────┐            │
       │            │          │            │
       │            │  Shared  │            │  Write (must
       │            │   (S)    │            │  invalidate
       │            └────┬─────┘            │  others first)
       │                 │                  │
       │     Other core  │                  │
       │     writes →    │ invalidate       │
       │     this copy   │                  │
       │     is stale    ▼                  │
  ┌────┴─────┐     ┌──────────┐             │
  │          │     │          │    Fetch +  │
  │Exclusive ├────►│ Invalid  ├─────────────┘
  │   (E)    │     │   (I)    │    Write
  └──────────┘     └──────────┘
  (only copy,       (stale or
   clean)           not present)
```

#### Why This Matters for Concurrency

Every time one core writes to a shared variable:
1. All other cores' copies become **Invalid**
2. Those cores must **re-fetch** the line before their next access
3. Each re-fetch costs **40-80+ nanoseconds** (an interconnect round-trip)

When 8 cores are all writing to the same cache line (as in our `AtomicCounter` or `FalseSharingCounter`), this creates a "ping-pong" effect where the cache line constantly bounces between cores. This is called **cache-line bouncing** or **cache-line contention**.

---

### 2.4 What is a Context Switch?

#### Prerequisites
You should understand: threads (Section 2.1), CPU registers, caches (Section 2.2).

#### Definition

A **context switch** is the process of saving the state of one thread and loading the state of another thread so that the CPU can execute it. It's the mechanism that allows multiple threads to share a single CPU core.

#### What Gets Saved & Restored

When the OS switches from Thread A to Thread B on a core:

```
SAVE Thread A:                         LOAD Thread B:
┌────────────────────────┐             ┌────────────────────────┐
│ • Program Counter (PC) │             │ • Program Counter (PC) │
│ • Stack Pointer (SP)   │  ────────►  │ • Stack Pointer (SP)   │
│ • General Registers    │  (stored    │ • General Registers    │
│   (RAX, RBX, RCX...)  │   in        │   (RAX, RBX, RCX...)  │
│ • Floating Point Regs  │   kernel    │ • Floating Point Regs  │
│ • Status Flags         │   memory)   │ • Status Flags         │
└────────────────────────┘             └────────────────────────┘
```

#### The Hidden Costs (Beyond Register Save/Load)

The register save/load is actually the *cheap* part (~100 ns). The expensive parts:

| Cost | Description | Latency |
|------|-------------|---------|
| **TLB flush** | Page table mappings may be invalidated (partial on modern CPUs) | ~100-500 ns |
| **Cache pollution** | Thread B's data isn't in L1/L2; must be fetched from L3/memory | ~500-5000 ns |
| **Pipeline flush** | CPU must drain its instruction pipeline | ~10-50 ns |
| **Scheduler overhead** | Kernel must decide which thread to run next | ~100-500 ns |
| **Kernel transition** | User mode → kernel mode → user mode | ~100-200 ns |

**Total estimated cost:** ~1,000 to 10,000 ns (1-10 µs) per switch

#### Voluntary vs Involuntary Context Switches

| Type | Trigger | Example in Java |
|------|---------|-----------------|
| **Voluntary** | Thread decides to stop | `LockSupport.park()`, `Object.wait()`, `Thread.sleep()` |
| **Involuntary** | OS preempts the thread | Time slice expired (typically every 1-10 ms) |

**In our benchmark:** `SynchronizedCounter` causes massive voluntary context switches because threads call `LockSupport.park()` when they can't acquire the lock.

#### Why Context Switches Kill Lock Performance

```
Thread 0 holds the lock, executing count++
Thread 1 tries to acquire lock → fails → parks → VOLUNTARY CONTEXT SWITCH
Thread 2 tries to acquire lock → fails → parks → VOLUNTARY CONTEXT SWITCH
...
Thread 0 releases lock → unparks Thread 1 → CONTEXT SWITCH back to Thread 1
Thread 1 acquires lock, does count++, releases, unparks Thread 2 → CONTEXT SWITCH
...
```

Each `count++` takes ~1 ns, but each context switch takes ~3,000 ns. The switching overhead **dominates** the actual work by a factor of 3000x.

---

### 2.5 Atomicity & Compare-And-Swap (CAS)

#### Prerequisites
You should understand: threads (Section 2.1), cache lines (Section 2.2), MESI protocol (Section 2.3).

#### What Does "Atomic" Mean?

An operation is **atomic** if it appears to happen instantaneously from the perspective of all other threads. No other thread can observe the operation in a half-completed state.

**Non-atomic example:** `count++` in Java compiles to three separate instructions:
```
1. READ:  Load current value of count into a register    (e.g., register = 42)
2. MODIFY: Increment the register                        (e.g., register = 43)
3. WRITE: Store the register back to memory              (e.g., count = 43)
```

If two threads execute this simultaneously:
```
Thread A: READ count (gets 42)
Thread B: READ count (gets 42)     ← Both read the SAME value!
Thread A: WRITE count = 43
Thread B: WRITE count = 43          ← LOST UPDATE! Should be 44.
```

#### The CAS Instruction

**Compare-And-Swap (CAS)** is a CPU instruction that performs a conditional write atomically:

```
CAS(address, expectedValue, newValue):
    atomically {
        if (memory[address] == expectedValue) {
            memory[address] = newValue
            return true    // SUCCESS
        } else {
            return false   // FAILURE — someone else changed it
        }
    }
```

**Key property:** The read-compare-write happens as a single, indivisible hardware operation. No other core can interleave.

#### How CAS is Implemented in Hardware

| Architecture | Instruction | Mechanism |
|-------------|-------------|-----------|
| x86-64 | `LOCK CMPXCHG` | The `LOCK` prefix locks the cache line for the duration of the instruction |
| ARM (Apple M-series) | `LDXR` / `STXR` (Load-Exclusive / Store-Exclusive) | Reserves the cache line; store fails if another core wrote to it |

On x86, `LOCK CMPXCHG`:
1. Acquires exclusive ownership of the cache line (other cores' copies → Invalid)
2. Compares the value in the cache line with the expected value
3. If equal, writes the new value
4. Releases the line (other cores can now access it)

All of this happens in a single instruction — no other core can intervene between the compare and the swap.

#### The CAS Loop Pattern

Since CAS can fail (if another thread changed the value between our read and our CAS), we wrap it in a retry loop:

```java
// How AtomicLong.incrementAndGet() works internally:
long increment() {
    while (true) {                          // Retry loop
        long current = value;               // Step 1: Read current value (volatile read)
        long next = current + 1;            // Step 2: Compute desired new value
        if (CAS(value, current, next)) {    // Step 3: Attempt atomic update
            return next;                    // Success! We're done.
        }
        // CAS failed — another thread changed 'value' between Step 1 and Step 3.
        // Loop back and try again with the new value.
    }
}
```

#### Lock-Free vs Wait-Free

| Guarantee | Definition | Example |
|-----------|-----------|---------|
| **Lock-free** | At least one thread makes progress in a finite number of steps | CAS loop (our `AtomicCounter`) |
| **Wait-free** | Every thread makes progress in a bounded number of steps | Very rare; specialized algorithms |
| **Blocking** | A thread can be permanently stuck if the lock holder crashes/stalls | `synchronized`, `ReentrantLock` |

Our `AtomicCounter` is **lock-free**: even if 7 out of 8 threads fail their CAS, at least one succeeds. No thread can prevent all others from making progress.

#### CAS Failures Under High Contention

When 8 threads all CAS the same variable:
- Each attempt has a **~1/8 chance** of succeeding (only one core "wins" each round)
- Failed threads must retry, which means **another cache-line round-trip** (40-80 ns)
- Expected retries before success: ~7 in the worst case

This is why `AtomicLong` under extreme contention can be slower than expected — the CAS retry storm wastes cycles.

---

### 2.6 The Java Memory Model (JMM)

#### Prerequisites
You should understand: threads (Section 2.1), caches and MESI (Sections 2.2-2.3), why cores can see stale data.

#### Why Do We Need a Memory Model?

Two things can reorder or hide memory operations from other threads:

1. **The CPU:** Out-of-order execution, store buffers, and write-combining can delay when writes become visible to other cores.
2. **The compiler/JIT:** Can reorder, eliminate, or cache variable reads in registers for performance.

Without rules, this code is broken:
```java
// Thread 1:                    // Thread 2:
data = 42;                      if (ready) {
ready = true;                       print(data);  // Might print 0!
                                }
```

Why? The CPU/compiler might reorder Thread 1's writes, making `ready = true` visible before `data = 42`.

#### The Happens-Before Relationship

The JMM doesn't guarantee when writes become visible. Instead, it defines **happens-before** relationships — if action A *happens-before* action B, then all effects of A are guaranteed to be visible to B.

**Formal definition:** If A happens-before B, then:
- A's memory writes are visible to B
- A's instructions execute before B's instructions (from B's perspective)

#### Key Happens-Before Rules

| Rule | What It Means | Example |
|------|--------------|---------|
| **Program order** | Within a single thread, earlier statements happen-before later ones | `x = 1; y = 2;` → y sees x's write |
| **Monitor unlock → lock** | Unlock of a monitor happens-before the next lock of that monitor | `synchronized` blocks |
| **`volatile` write → read** | A write to a volatile variable happens-before any subsequent read of it | Visibility flag patterns |
| **Thread start** | `thread.start()` happens-before any action in the started thread | Thread sees all prior writes |
| **Thread join** | All actions in a thread happen-before `join()` returns | Main thread sees worker's writes |
| **Lock.unlock() → Lock.lock()** | Same as monitor rule, for `ReentrantLock` | Our `SynchronizedCounter` |

#### The `volatile` Keyword

`volatile` provides two guarantees:

1. **Visibility:** Every read of a volatile variable sees the most recent write by any thread (no stale caches).
2. **Ordering fence:** No reordering of reads/writes across a volatile access.

**How it's implemented in hardware:**
- On x86: A `volatile` write inserts a **store-load fence** (`MFENCE` or `LOCK ADD`), forcing the store buffer to drain.
- On ARM: A `volatile` write inserts a **DMB (Data Memory Barrier)**, preventing all reordering around it.

#### Memory Ordering: x86 vs ARM

Different CPU architectures provide different ordering guarantees *in hardware*:

| Reordering Type | x86 (TSO) | ARM / Apple M-series |
|----------------|-----------|---------------------|
| Load → Load | ❌ Not reordered | ✅ Can be reordered |
| Load → Store | ❌ Not reordered | ✅ Can be reordered |
| Store → Store | ❌ Not reordered | ✅ Can be reordered |
| Store → Load | ✅ **Can be reordered** | ✅ Can be reordered |

**What this means:**
- On x86 (Total Store Order): The hardware already provides strong ordering. Most JMM guarantees are "free" — the JVM barely needs to insert fences.
- On ARM (Relaxed): The hardware provides almost no ordering. The JVM must insert explicit fence instructions for every `volatile` and `synchronized` operation.

**Practical implication:** Code that "works" on x86 by accident (relying on hardware ordering without proper `volatile`/`synchronized`) will **break** on ARM. Always program to the JMM specification, not the hardware.

#### How JMM Applies to Our Counters

| Counter | JMM Mechanism | What It Guarantees |
|---------|---------------|-------------------|
| `SynchronizedCounter` | Lock.unlock() → Lock.lock() | Each thread sees the most recent count value after acquiring the lock |
| `AtomicCounter` | CAS (volatile semantics) | Successful CAS establishes happens-before with subsequent reads |
| `FalseSharingCounter` | Array writes + CountDownLatch | Latch's countDown() → await() ensures main thread sees all writes |
| `PaddedCounter` | CountDownLatch only | Same as above — no volatile needed because only one thread writes each slot |

---

### 2.7 What is False Sharing?

#### Prerequisites
You should understand: cache lines (Section 2.2), MESI invalidation (Section 2.3).

#### Definition

**False sharing** occurs when two or more threads on different cores write to *independent* variables that happen to reside on the **same cache line**. Despite there being no logical data dependency between the threads, the hardware's cache coherence protocol treats it as a shared-write scenario, causing performance degradation.

#### Why It's Called "False"

- **True sharing:** Two threads both read/write the *same* variable → cache coherence traffic is *necessary* and *unavoidable*.
- **False sharing:** Two threads write to *different* variables on the same cache line → cache coherence traffic is *unnecessary* but the hardware can't distinguish this from true sharing.

The "sharing" is at the cache-line level, not the variable level. The hardware invalidates entire cache lines, not individual bytes.

#### Visual Example

Imagine two threads, each incrementing its own counter:

```
Thread 0 writes to counter_a (address 0x1000)
Thread 1 writes to counter_b (address 0x1008)

Memory layout:
┌──────────────────────────────────────────────────────────────────┐
│                    ONE 64-byte Cache Line                          │
│  [counter_a] [counter_b] [unused] [unused] ... [unused]          │
│   0x1000      0x1008      0x1010   0x1018      0x1038            │
└──────────────────────────────────────────────────────────────────┘
```

Even though Thread 0 never reads `counter_b` and Thread 1 never reads `counter_a`:
- When Thread 0 writes `counter_a` → entire cache line invalidated on Core 1
- When Thread 1 writes `counter_b` → entire cache line invalidated on Core 0
- Each core must re-fetch the 64-byte line from the other core or L3 before it can write

**Result:** Performance degrades to the same level as if both threads were writing to the *same* variable.

#### The Fix: Cache-Line Padding

Ensure each thread's variable lives on its own cache line by inserting dead padding bytes between them:

```
Before (false sharing):        After (padded — no false sharing):
┌────────┬────────┐            ┌────────┬──────────────────────────┐
│counter_a│counter_b│           │counter_a│  120 bytes of padding    │
│ 8 bytes │ 8 bytes│            │ 8 bytes │                          │
└────────┴────────┘            ├────────┼──────────────────────────┤
Same cache line ← BAD          │counter_b│  120 bytes of padding    │
                               │ 8 bytes │                          │
                               └────────┴──────────────────────────┘
                               Different cache lines ← GOOD
```

#### How to Detect False Sharing

| Tool | Platform | Command/Usage |
|------|----------|---------------|
| `perf c2c` | Linux | `perf c2c record -- ./your_program` then `perf c2c report` |
| `perf stat` | Linux | `perf stat -e L1-dcache-load-misses,cache-misses ./program` |
| Intel VTune | Linux/Windows | "Memory Access Analysis" → shows contended cache lines |
| `@Contended` | Java | JDK annotation that auto-pads fields (used internally by `LongAdder`) |

#### Real-World Impact

False sharing is insidious because:
1. **Invisible in code review** — two variables side-by-side look perfectly independent
2. **Invisible in functional testing** — results are still correct, just slow
3. **Only visible in profiling** — you need hardware performance counters to diagnose it
4. **Platform-dependent** — padding that works on x86 (64-byte lines) may not work on Apple Silicon (128-byte lines)

---

## Part 3: The Benchmark — What We're Testing

Now that you understand the foundational concepts, here's what our benchmark does:

### The Problem Statement

> Increment a shared counter 80,000,000 times (8 threads × 10,000,000 increments each).  
> Measure how long each strategy takes. All must produce the correct final count.

### The Four Strategies (Overview)

| # | Strategy | Concurrency Mechanism | Primary Bottleneck (from prerequisites) |
|---|----------|----------------------|----------------------------------------|
| 1 | `SynchronizedCounter` | ReentrantLock (mutual exclusion) | OS context switches (Section 2.4) |
| 2 | `AtomicCounter` | AtomicLong / CAS loop (lock-free) | Cache-line bouncing (Section 2.3) + CAS retries (Section 2.5) |
| 3 | `FalseSharingCounter` | Per-thread slots, packed together | False sharing (Section 2.7) — independent writes invalidate shared line |
| 4 | `PaddedCounter` | Per-thread slots, cache-line padded | None — each core's line stays in Modified state |

### Benchmark Parameters

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| Threads | 8 | Saturates most consumer CPUs; creates real contention |
| Increments/thread | 10,000,000 | Long enough to amortize JIT compilation and show steady-state behavior |
| Warmup iterations | 2 | Allows C2 JIT to compile hot loops; stabilizes branch predictor |
| Timing | `System.nanoTime()` | Monotonic clock; immune to wall-clock adjustments |

### Coordination Design

```
                     CyclicBarrier(8)
                          │
    Thread 0 ─────────────┤
    Thread 1 ─────────────┤  All threads start simultaneously
    Thread 2 ─────────────┤  (eliminates thread-creation skew)
    ...                   │
    Thread 7 ─────────────┘
                          │
                    START TIMER
                          │
              [Each thread does 10M increments]
                          │
                  CountDownLatch(8)
                          │
    Thread 0 ─── countDown()
    Thread 1 ─── countDown()       Main thread
    ...                      ───── await() ──── STOP TIMER
    Thread 7 ─── countDown()
```

---

## Part 4: Counter Implementations

### Implementation 1: `SynchronizedCounter` — Mutual Exclusion

**File:** `src/main/java/com/benchmark/counter/SynchronizedCounter.java`

```java
lock.lock();
try { count++; }
finally { lock.unlock(); }
```

**How it works:**
1. Thread calls `lock.lock()` — if the lock is free, it acquires it (cheap compare-and-set on the lock's state)
2. If the lock is held by another thread:
   - Spins briefly (adaptive spinning — ~10-100 iterations)
   - If still held → `LockSupport.park()` → **voluntary context switch** (Section 2.4)
3. Thread that holds the lock does `count++`, then `lock.unlock()`
4. `unlock()` calls `LockSupport.unpark(nextWaiter)` → wakes one parked thread → **another context switch**

**Why it's the slowest:**

| Factor | Cost | Reference |
|--------|------|-----------|
| Only 1 thread works at a time | Serializes all 80M operations | — |
| Context switch per contended acquire | ~3,000 ns × millions of switches | Section 2.4 |
| Memory fence on lock release | Forces store buffer drain | Section 2.6 |
| Kernel scheduler involvement | syscall overhead per park/unpark | Section 2.4 |

**Correctness:** Always correct. Lock guarantees mutual exclusion + happens-before (Section 2.6).

---

### Implementation 2: `AtomicCounter` — Lock-Free CAS

**File:** `src/main/java/com/benchmark/counter/AtomicCounter.java`

```java
// Inside AtomicLong.incrementAndGet():
do {
    long current = get();              // volatile read
    long next = current + 1;
} while (!compareAndSet(current, next)); // CAS — retry on failure
```

**How it works:**
1. Thread reads the current value (volatile read ensures visibility — Section 2.6)
2. Computes the new value
3. Attempts CAS (Section 2.5): if the value hasn't changed since the read, atomically write the new value
4. If CAS fails (another thread wrote first), go back to step 1

**Why it's faster than locks but slower than padded:**

| Factor | Cost | Reference |
|--------|------|-----------|
| No context switches (no parking, no kernel) | Saves ~3000 ns per contended access | Section 2.4 |
| Cache-line bouncing between 8 cores | ~40-80 ns per ownership transfer | Section 2.3 (MESI) |
| CAS retry storms under 8-way contention | ~7 retries per success × 60 ns each | Section 2.5 |
| Single variable = single cache line = maximum coherence traffic | All 8 cores fight over one 64-byte line | Section 2.3 |

**Trace of 8-thread contention:**
```
T=0: Core 0 owns the line (Modified state), does CAS → succeeds ✓
T=1: Core 3 wants to CAS:
     → Sends invalidate to Core 0 (Core 0: Modified → Invalid)
     → Fetches line from Core 0 (via L3): ~60 ns
     → Core 3 now Modified, does CAS → succeeds ✓
T=2: Core 5 wants to CAS:
     → Sends invalidate to Core 3
     → Fetches line: ~60 ns
     → Core 5 does CAS → might FAIL if Core 1 beat it!
     → If failed: must re-read (another ~60 ns round-trip) and retry
```

**Correctness:** Always correct. CAS is atomic at the hardware level (Section 2.5).

---

### Implementation 3: `FalseSharingCounter` — The Hidden Killer

**File:** `src/main/java/com/benchmark/counter/FalseSharingCounter.java`

```java
long[] slots = new long[8];   // 8 longs = 64 bytes = ONE cache line
// Thread i increments only slots[i] — NO logical sharing!
```

**How it works:**
1. Each thread is assigned its own slot: Thread 0 → `slots[0]`, Thread 1 → `slots[1]`, etc.
2. Each thread only writes to its own slot — there is **zero logical data sharing**
3. But all 8 longs are packed into a single cache line (64 bytes on x86)

**Why it's slow despite no logical sharing (False Sharing — Section 2.7):**

```
Memory layout:
Address:  0x1000  0x1008  0x1010  0x1018  0x1020  0x1028  0x1030  0x1038
         ┌───────┬───────┬───────┬───────┬───────┬───────┬───────┬───────┐
         │slot[0]│slot[1]│slot[2]│slot[3]│slot[4]│slot[5]│slot[6]│slot[7]│
         └───────┴───────┴───────┴───────┴───────┴───────┴───────┴───────┘
         ◄──────────────── ONE 64-byte cache line ────────────────────────►
         ◄──── ALL 8 cores fight over this single line ────────────────────►
```

**MESI trace:**
```
Core 0 writes slots[0]:
  → Core 0: Invalid → Modified
  → Cores 1-7: their copies → Invalid (MESI invalidate broadcast)

Core 1 wants to write slots[1]:
  → Core 1's copy is Invalid, must re-fetch entire line from Core 0
  → Cost: ~60 ns round-trip
  → Core 1: Invalid → Modified
  → Core 0: Modified → Invalid

Core 2 wants to write slots[2]:
  → Same thing — must fetch from whoever has Modified
  → Round-robin "ping-pong" between all 8 cores
```

**The paradox explained:**
- From the programmer's perspective: 8 independent counters, no sharing
- From the hardware's perspective: 8 cores fighting over the same 64-byte block
- Performance impact: Similar to (or worse than) a single `AtomicLong`

**Correctness:** Always correct (each thread writes only to its own index), but horribly slow.

---

### Implementation 4: `PaddedCounter` — The Fix

**File:** `src/main/java/com/benchmark/counter/PaddedCounter.java`

```java
long[] slots = new long[8 * 16];  // 128 bytes between each active slot
// Thread i increments slots[i * 16]
// The 15 unused longs between active slots are "dead padding"
```

**How it works:**
1. Each thread's active slot is separated by 16 longs (128 bytes)
2. 128 bytes > cache line size on both x86 (64 bytes) and Apple Silicon (128 bytes)
3. Each active slot is guaranteed to be on its **own, private cache line**

**Why it's the fastest:**

```
Memory layout (simplified):
┌──────────────────────────────────────────────────────────────┐
│ Cache Line 0: [slots[0]] [padding × 15]                      │  ← Core 0 owns this exclusively
├──────────────────────────────────────────────────────────────┤
│ Cache Line 1: [slots[16]] [padding × 15]                     │  ← Core 1 owns this exclusively
├──────────────────────────────────────────────────────────────┤
│ Cache Line 2: [slots[32]] [padding × 15]                     │  ← Core 2 owns this exclusively
├──────────────────────────────────────────────────────────────┤
│ ...                                                          │
└──────────────────────────────────────────────────────────────┘
```

**MESI behavior:**
```
Core 0 writes slots[0]:
  → Line 0 stays in Modified state (no other core has it cached)
  → No snoops needed, no invalidations, no interconnect traffic
  → Cost: ~1 ns (write hits L1 cache)

Core 1 writes slots[16]:
  → Line 1 stays in Modified state (completely independent of Line 0)
  → Core 0 is never disturbed
```

| Factor | Impact | Reference |
|--------|--------|-----------|
| No locks → no context switches | ✓ | Section 2.4 |
| No CAS → no retry overhead | ✓ | Section 2.5 |
| No shared cache lines → no MESI invalidation | ✓ | Section 2.3 |
| Each core writes to L1 only (~1 ns per write) | ✓ | Section 2.2 |

**Performance = single-threaded speed × 8 threads (linear scaling)**

**Correctness:** Always correct. The `CountDownLatch` establishes a happens-before edge (Section 2.6), ensuring the main thread sees all writes when it calls `get()`.

**Trade-off:** Uses more memory (128 bytes per thread instead of 8). In practice, this is negligible — 1 KB total for 8 threads.

---

## Part 5: Results & Analysis

### Typical Output (Apple M-series, 10 cores, Java 23)

```
╔══════════════════════════════════════════════════════════════════════════════╗
║          CONCURRENT COUNTER BENCHMARK — Cache Lines & Contention           ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Threads: 8    | Increments/thread: 10,000,000 | Warmup: 2 iterations      ║
╚══════════════════════════════════════════════════════════════════════════════╝

Padded Counter (no false sharing)  | Time:      42 ms | Correct: ✓
False Sharing Counter (unpadded)   | Time:     168 ms | Correct: ✓
ReentrantLock Counter              | Time:   1,520 ms | Correct: ✓
AtomicLong (CAS) Counter           | Time:   4,284 ms | Correct: ✓
```

### Performance Comparison Table

| Implementation | Time | Relative | Primary Bottleneck | Reference |
|---------------|------|----------|-------------------|-----------|
| **Padded** (baseline) | ~42 ms | 1.0x | None — pure L1 writes | Section 2.2 |
| **False Sharing** | ~168 ms | 4.0x slower | Cache-line bouncing (MESI invalidation) | Sections 2.3, 2.7 |
| **ReentrantLock** | ~1,520 ms | 36x slower | OS context switches + serialization | Section 2.4 |
| **AtomicLong** | ~4,284 ms | 102x slower | CAS retries + cache-line bouncing | Sections 2.3, 2.5 |

### Why AtomicLong is Slower Than ReentrantLock on This Machine

This result surprises many people (the "expected" ordering would have AtomicLong faster). The explanation is specific to Apple Silicon (aarch64):

1. **128-byte cache lines:** Apple M-series uses 128-byte cache lines, which means the AtomicLong variable shares its line with more adjacent data, potentially increasing coherence traffic.

2. **Weak memory model (ARM):** On ARM, `volatile` writes (which AtomicLong uses) require explicit memory barriers (DMB instruction). These barriers are more expensive on ARM than on x86 (where the strong memory model makes many fences no-ops).

3. **ReentrantLock's adaptive spinning:** Before parking, the lock spins for a while. On a 10-core machine with only 8 threads, the lock holder often finishes before the spinner gives up — avoiding many context switches entirely.

4. **Extreme CAS contention:** With 8 threads all CAS-ing the same variable, the failure rate is ~87.5% (7/8 threads fail per round). Each failure triggers an interconnect round-trip. The lock at least serializes access, reducing redundant work.

**Key takeaway for interviews:** Performance is hardware-dependent. Always benchmark on your target platform. Rules of thumb can be wrong.

### Why False Sharing is "Only" 4x Slower (Not More)

On Apple M-series with 128-byte cache lines:
- Our 8 longs = 64 bytes, which fits within a single 128-byte line (worst case for false sharing)
- But the JVM's array layout includes a 16-byte object header, so the total object size is ~80 bytes — still within one 128-byte line
- The 4x slowdown is the pure cost of cache-line bouncing without CAS overhead
- No retry loops, no atomic operations — just "fetch line, write, get invalidated, fetch again"

---

## Part 6: Interview Talking Points

### Q: "How would you design a high-throughput counter for a distributed query engine?"

**Answer framework:**
1. **Identify the access pattern:** Is it read-heavy or write-heavy? Our scenario is write-heavy.
2. **Choose the right tool:**
   - Few writes, many reads → `AtomicLong` is fine
   - Many writes, occasional reads → `LongAdder` (striped cells, similar to our `PaddedCounter`)
   - Per-thread accumulation, aggregate at end → Thread-local counters (our Padded approach)
3. **Consider the hardware:** Know your cache line size, NUMA topology, core count
4. **Measure, don't guess:** False sharing is invisible in code review — only benchmarks reveal it

### Q: "Explain false sharing and how you'd detect it in production."

**Answer:**
1. **Define it:** Independent variables on the same cache line cause unnecessary MESI invalidation traffic between cores (Section 2.7)
2. **Why it's dangerous:** Invisible in code review, correct results, only manifests as performance degradation
3. **Detection tools:**
   - Linux: `perf c2c record/report` (shows contended cache lines)
   - Linux: `perf stat -e L1-dcache-load-misses,cache-misses`
   - Intel VTune: "Memory Access Analysis"
   - Java: suspiciously high L1 cache miss rates for per-thread data structures
4. **Fix:** Pad to cache-line boundaries using `@sun.misc.Contended` (JDK internal) or manual padding (as in our `PaddedCounter`)

### Q: "Why does Java's LongAdder outperform AtomicLong?"

**Answer:**
- `LongAdder` uses the same principle as our `PaddedCounter` (Section 2.7 fix)
- It maintains a `base` value + array of `Cell` objects (each annotated with `@Contended` for padding)
- Under contention, threads hash to different cells → each thread hits a different cache line → no bouncing
- `sum()` aggregates all cells — this is **not atomic** (eventual consistency, like our `get()`)
- Trade-off: Higher memory usage, non-atomic `sum()`, but orders of magnitude faster writes under contention

### Q: "What's the relationship between happens-before and cache coherence?"

**Answer:**
- **Happens-before** is a *software contract* defined by the JMM specification (Section 2.6)
- **Cache coherence (MESI)** is a *hardware mechanism* that ensures memory consistency (Section 2.3)
- The JVM uses hardware primitives (fences, atomic instructions) to implement the JMM's happens-before guarantees
- On x86 (TSO): Most happens-before rules are "free" because the hardware already provides strong ordering
- On ARM (relaxed): The JVM must insert explicit `DMB`/`DSB` fence instructions — `volatile` is more expensive on ARM
- **Key distinction:** Cache coherence guarantees *eventual* visibility (MESI ensures a write is *never* permanently invisible). The JMM's happens-before guarantees *timely, ordered* visibility.

### Q: "Walk me through what happens at the hardware level when two threads CAS the same variable."

**Answer** (combining Sections 2.3 and 2.5):
```
T=0: Core 0 reads AtomicLong → cache line in Shared state on both cores (S,S)

T=1: Core 0 issues LOCK CMPXCHG (x86) / LDXR+STXR (ARM):
     → Acquires exclusive ownership of the cache line
     → Core 1's copy transitions: Shared → Invalid
     → Core 0's copy transitions: Shared → Modified
     → CAS compares and succeeds → value updated in L1 cache

T=2: Core 1 issues LOCK CMPXCHG:
     → Needs exclusive ownership → sends "read-with-intent-to-modify" on bus
     → Core 0 snoops, writes back dirty line to L3, transitions: Modified → Invalid
     → Core 1 fetches updated line from L3, transitions: Invalid → Modified
     → Core 1 performs CAS... but the value changed since its last read!
     → CAS FAILS (expected ≠ actual)
     → Core 1 must retry: re-read the value, compute new target, CAS again

T=3: Core 1 re-reads (another bus transaction if Core 2 modified it in between)
     → Eventually succeeds after ~N-1 average retries under N-way contention
```

---

## How to Run

```bash
# From the course root directory:
./gradlew :day1:run
```

**Requirements:** JDK 17+ (Gradle Wrapper is included — no separate Gradle installation needed).

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. The IDE auto-detects the Gradle project and lets you click ▶ on `Main.java` directly.

---

## Directory Structure

```
src/main/java/com/benchmark/
├── Main.java                           # Entry point — wires implementations to engine
├── counter/
│   ├── Counter.java                    # Interface (contract)
│   ├── SynchronizedCounter.java        # ReentrantLock-based mutual exclusion
│   ├── AtomicCounter.java              # AtomicLong / CAS-based lock-free
│   ├── FalseSharingCounter.java        # Per-thread slots, same cache line (BAD)
│   └── PaddedCounter.java             # Per-thread slots, padded cache lines (GOOD)
└── engine/
    └── BenchmarkEngine.java            # Thread spawning, timing, coordination
```

---

## Further Reading

| Resource | Topic | Why It's Useful |
|----------|-------|-----------------|
| "Java Concurrency in Practice" (Goetz et al.) | JMM, atomics, lock-free algorithms | Chapter 15 covers CAS and nonblocking synchronization |
| "What Every Programmer Should Know About Memory" (Drepper) | CPU caches, memory hierarchy | Deep hardware background for Section 2.2 |
| "Is Parallel Programming Hard?" (McKenney) | Memory ordering, barriers | Rigorous treatment of memory models |
| Intel Architecture Manual, Vol 3A, Ch. 8 | MESI protocol details | Authoritative reference for cache coherence |
| JEP 142 | `@Contended` annotation | Java's official fix for false sharing |
| OpenJDK source: `LongAdder` | Striped counter implementation | Production-grade version of our PaddedCounter |
| Linux `perf c2c` documentation | False sharing detection | How to find these problems in production |
| Mechanical Sympathy blog (Martin Thompson) | Low-latency Java | Practical application of all these concepts |

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
