import cache.StripedLRUCache;

/**
 * InterviewLeanCache.java
 *
 * Whiteboard-ready Striped LRU Cache.
 * Core focus: model.Node pointer surgery, per-stripe locking, eviction.
 * No metrics, no benchmark bloat — fits a 30-minute interview window.
 */
public class InterviewLeanCacheBenchmark {
    // ─── Demo ───────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        StripedLRUCache<String, Integer> cache = new StripedLRUCache<>(4, 2);

        cache.put("a", 1);
        cache.put("b", 2);
        cache.put("c", 3);
        cache.put("d", 4);

        System.out.println("get(a) = " + cache.get("a")); // may be evicted depending on stripe
        System.out.println("get(b) = " + cache.get("b"));
        System.out.println("get(c) = " + cache.get("c"));
        System.out.println("get(d) = " + cache.get("d"));

        // Trigger eviction by adding more keys
        cache.put("e", 5);
        cache.put("f", 6);
        cache.put("g", 7);

        System.out.println("\nAfter adding e, f, g:");
        System.out.println("get(a) = " + cache.get("a"));
        System.out.println("get(e) = " + cache.get("e"));
        System.out.println("get(f) = " + cache.get("f"));
        System.out.println("get(g) = " + cache.get("g"));
    }
}