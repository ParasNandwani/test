package cache;

/**
 * Version B: Striped (Segmented) Lock LRU Cache
 *
 * The cache is split into N independent segments (stripes).
 * Each stripe maintains its own lock, HashMap, and doubly linked list.
 * Threads touching different stripes never contend with each other.
 *
 * Key-to-stripe mapping: hash(key) % numSegments
 * Capacity per stripe: ceil(totalCapacity / numSegments)
 *
 * Deadlock safety: each operation touches exactly ONE stripe,
 * so cross-stripe lock ordering is never needed.
 */
public class StripedLRUCache<K, V> implements ConcurrentCache<K, V> {

    private final GlobalLockLRUCache<K, V>[] segments;
    private final int numSegments;

    @SuppressWarnings("unchecked")
    public StripedLRUCache(int totalCapacity, int numSegments) {
        this.numSegments = numSegments;
        this.segments = new GlobalLockLRUCache[numSegments];
        int perSegmentCapacity = (int) Math.ceil((double) totalCapacity / numSegments);
        for (int i = 0; i < numSegments; i++) {
            segments[i] = new GlobalLockLRUCache<>(perSegmentCapacity);
        }
    }

    @Override
    public String name() {
        return "StripedLRU(stripes=" + numSegments + ", capPerStripe=" + segments[0].getCapacity() + ")";
    }

    // ─── Stripe Selection ───────────────────────────────────────────────────

    private int stripeFor(K key) {
        int h = key.hashCode();
        h ^= (h >>> 16); // spread upper bits into lower to reduce clustering
        return Math.abs(h % numSegments);
    }

    // ─── Public API ─────────────────────────────────────────────────────────

    @Override
    public V get(K key) {
        return segments[stripeFor(key)].get(key);
    }

    @Override
    public void put(K key, V value) {
        segments[stripeFor(key)].put(key, value);
    }

    // ─── Aggregated Metrics ─────────────────────────────────────────────────

    public long getHits() {
        long total = 0;
        for (GlobalLockLRUCache<K, V> s : segments) total += s.getHits();
        return total;
    }

    public long getMisses() {
        long total = 0;
        for (GlobalLockLRUCache<K, V> s : segments) total += s.getMisses();
        return total;
    }

    public long getEvictions() {
        long total = 0;
        for (GlobalLockLRUCache<K, V> s : segments) total += s.getEvictions();
        return total;
    }
}
