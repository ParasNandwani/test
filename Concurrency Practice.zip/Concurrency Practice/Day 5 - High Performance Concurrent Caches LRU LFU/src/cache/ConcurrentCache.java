package cache;

/**
 * Common interface for concurrent LRU cache implementations.
 * Both Version A (Global Lock) and Version B (Striped Lock) implement this.
 */
public interface ConcurrentCache<K, V> {
    V get(K key);
    void put(K key, V value);
    String name();
}