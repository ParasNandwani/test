package cache;

import model.Node;

import java.util.HashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Version A: Global Lock LRU Cache
 *
 * A single ReentrantLock guards the entire structure.
 * Simple, correct, but serializes all threads — every get/put acquires the same lock.
 *
 * Internal structure:
 *   - HashMap<K, model.Node<K,V>> for O(1) key lookup
 *   - Doubly linked list with sentinel head/tail for O(1) recency reordering
 */
public class GlobalLockLRUCache<K, V> implements ConcurrentCache<K, V> {

    private final int capacity;
    private final HashMap<K, Node<K, V>> map;
    private final Node<K, V> head; // sentinel — always first
    private final Node<K, V> tail; // sentinel — always last
    private final ReentrantLock lock;

    // ─── Metrics ────────────────────────────────────────────────────────────
    private final AtomicLong hits = new AtomicLong(0);
    private final AtomicLong misses = new AtomicLong(0);
    private final AtomicLong evictions = new AtomicLong(0);

    public GlobalLockLRUCache(int capacity) {
        this.capacity = capacity;
        this.map = new HashMap<>(capacity * 4 / 3 + 1); // size to avoid rehashing
        this.head = new Node<>();
        this.tail = new Node<>();
        head.next = tail;
        tail.prev = head;
        this.lock = new ReentrantLock();
    }

    @Override
    public String name() {
        return "GlobalLockLRU(cap=" + capacity + ")";
    }

    // ─── Public API ─────────────────────────────────────────────────────────

    @Override
    public V get(K key) {
        lock.lock();
        try {
            Node<K, V> node = map.get(key);
            if (node == null) {
                misses.incrementAndGet();
                return null;
            }
            hits.incrementAndGet();
            moveToHead(node);
            return node.value;
        } finally {
            lock.unlock();
        }
    }

    @Override
    public void put(K key, V value) {
        lock.lock();
        try {
            Node<K, V> existing = map.get(key);
            if (existing != null) {
                // Key exists — update value and promote to MRU
                existing.value = value;
                moveToHead(existing);
            } else {
                // New key — insert at head, evict tail if over capacity
                Node<K, V> newNode = new Node<>(key, value);
                map.put(key, newNode);
                addToHead(newNode);
                if (map.size() > capacity) {
                    evict();
                }
            }
        } finally {
            lock.unlock();
        }
    }

    // ─── Eviction ───────────────────────────────────────────────────────────

    private void evict() {
        Node<K, V> victim = tail.prev; // LRU node is just before tail sentinel
        removeNode(victim);
        map.remove(victim.key);
        evictions.incrementAndGet();
    }

    // ─── Pointer Surgery (DLL operations) ───────────────────────────────────

    private void moveToHead(Node<K, V> node) {
        removeNode(node);
        addToHead(node);
    }

    private void removeNode(Node<K, V> node) {
        node.prev.next = node.next;
        node.next.prev = node.prev;
    }

    private void addToHead(Node<K, V> node) {
        node.next = head.next;
        node.prev = head;
        head.next.prev = node;
        head.next = node;
    }

    // ─── Metrics Access ─────────────────────────────────────────────────────

    public long getHits() { return hits.get(); }
    public long getMisses() { return misses.get(); }
    public long getEvictions() { return evictions.get(); }
    public int getCapacity() { return capacity; }
}