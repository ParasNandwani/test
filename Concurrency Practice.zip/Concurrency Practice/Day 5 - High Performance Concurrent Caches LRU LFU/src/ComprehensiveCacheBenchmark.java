import cache.ConcurrentCache;
import cache.GlobalLockLRUCache;
import cache.StripedLRUCache;
import model.BenchmarkConfig;
import model.BenchmarkResult;

import java.util.concurrent.CountDownLatch;

/**
 * ComprehensiveCacheBenchmark.java
 *
 * Multi-threaded benchmark harness that load-tests both LRU cache implementations:
 *   - Version A: cache.GlobalLockLRUCache (single lock)
 *   - Version B: cache.StripedLRUCache (N independent segments)
 *
 * Uses CountDownLatch for synchronized thread start to ensure fair measurement.
 * Tracks hits, misses, evictions, throughput (ops/sec), and speedup ratios.
 */
public class ComprehensiveCacheBenchmark {
    // ═══════════════════════════════════════════════════════════════════════════
    // MAIN — ORCHESTRATE BENCHMARKS
    // ═══════════════════════════════════════════════════════════════════════════

    public static void main(String[] args) throws InterruptedException {
        System.out.println("╔══════════════════════════════════════════════════════════════════╗");
        System.out.println("║       Concurrent LRU Cache — Comprehensive Benchmark            ║");
        System.out.println("╚══════════════════════════════════════════════════════════════════╝");
        System.out.println();

        BenchmarkConfig[] scenarios = new BenchmarkConfig[]{
                // Read-heavy workload (80% reads, 20% writes)
                new BenchmarkConfig(4, 500_000, 0.80, 10_000, 1_000, 16),
                new BenchmarkConfig(8, 500_000, 0.80, 10_000, 1_000, 16),
                new BenchmarkConfig(16, 500_000, 0.80, 10_000, 1_000, 16),
                new BenchmarkConfig(32, 250_000, 0.80, 10_000, 1_000, 16),

                // Write-heavy workload (30% reads, 70% writes)
                new BenchmarkConfig(8, 500_000, 0.30, 10_000, 1_000, 16),
                new BenchmarkConfig(16, 500_000, 0.30, 10_000, 1_000, 16),

                // Tiny cache, massive key space (high eviction pressure)
                new BenchmarkConfig(8, 500_000, 0.50, 100_000, 256, 16),

                // Varying stripe counts to observe scaling
                new BenchmarkConfig(16, 500_000, 0.80, 10_000, 1_000, 4),
                new BenchmarkConfig(16, 500_000, 0.80, 10_000, 1_000, 8),
                new BenchmarkConfig(16, 500_000, 0.80, 10_000, 1_000, 32),
                new BenchmarkConfig(16, 500_000, 0.80, 10_000, 1_000, 64),
        };

        for (int i = 0; i < scenarios.length; i++) {
            BenchmarkConfig config = scenarios[i];
            System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
            System.out.printf("Scenario %d: %s%n", i + 1, config);
            System.out.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

            // JVM warmup on first scenario
            if (i == 0) {
                System.out.println("  [Warming up JVM...]");
                GlobalLockLRUCache<Integer, Integer> warmup = new GlobalLockLRUCache<>(100);
                for (int w = 0; w < 100_000; w++) warmup.put(w, w);
                for (int w = 0; w < 100_000; w++) warmup.get(w % 100);
            }

            // Version A — Global Lock
            GlobalLockLRUCache<Integer, Integer> globalCache = new GlobalLockLRUCache<>(config.cacheCapacity);
            BenchmarkResult resultA = runBenchmark(globalCache, config);
            resultA.print();

            // Version B — Striped Lock
            StripedLRUCache<Integer, Integer> stripedCache = new StripedLRUCache<>(config.cacheCapacity, config.numStripes);
            BenchmarkResult resultB = runBenchmark(stripedCache, config);
            resultB.print();

            // Speedup ratio
            double speedup = resultB.throughputOpsPerSec() / resultA.throughputOpsPerSec();
            System.out.printf("  ➤ Striped speedup vs Global: %.2fx%n%n", speedup);
        }

        System.out.println("═══════════════════════════════════════════════════════════════════");
        System.out.println("Benchmark complete.");
        System.out.println("═══════════════════════════════════════════════════════════════════");

        // Correctness verification
        System.out.println();
        System.out.println("Running correctness smoke test...");
        correctnessTest();
        System.out.println("All correctness checks passed ✓");
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // BENCHMARK EXECUTION ENGINE
    // ═══════════════════════════════════════════════════════════════════════════

    /**
     * Run a benchmark against a given cache implementation.
     * Uses CountDownLatch to ensure all threads start simultaneously.
     */
    static BenchmarkResult runBenchmark(ConcurrentCache<Integer, Integer> cache, BenchmarkConfig config)
            throws InterruptedException {

        final CountDownLatch startGate = new CountDownLatch(1);   // all threads wait on this
        final CountDownLatch endGate = new CountDownLatch(config.numThreads); // main waits on this

        Thread[] threads = new Thread[config.numThreads];

        for (int t = 0; t < config.numThreads; t++) {
            final int threadId = t;
            threads[t] = new Thread(() -> {
                try {
                    startGate.await(); // wait for synchronized start
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }

                // Xorshift64 pseudo-random generator (avoids ThreadLocalRandom overhead)
                long seed = System.nanoTime() ^ (threadId * 1099511628211L);

                for (int i = 0; i < config.opsPerThread; i++) {
                    seed ^= (seed << 13);
                    seed ^= (seed >>> 7);
                    seed ^= (seed << 17);

                    int key = (int) (Math.abs(seed) % config.keySpaceSize);

                    // Determine read vs write based on configured ratio
                    double roll = ((seed >>> 33) & 0x7FFFFFFFL) / (double) 0x7FFFFFFFL;
                    if (roll < config.readRatio) {
                        cache.get(key);
                    } else {
                        cache.put(key, key * 10);
                    }
                }

                endGate.countDown();
            }, "worker-" + threadId);
            threads[t].start();
        }

        // Fire the start gate — all threads begin simultaneously
        long startTime = System.nanoTime();
        startGate.countDown();

        // Wait for all threads to finish
        endGate.await();
        long endTime = System.nanoTime();

        long durationMs = (endTime - startTime) / 1_000_000;
        long totalOps = (long) config.numThreads * config.opsPerThread;

        // Extract metrics based on implementation type
        long hits, misses, evictions;
        if (cache instanceof GlobalLockLRUCache) {
            GlobalLockLRUCache<Integer, Integer> c = (GlobalLockLRUCache<Integer, Integer>) cache;
            hits = c.getHits();
            misses = c.getMisses();
            evictions = c.getEvictions();
        } else if (cache instanceof StripedLRUCache) {
            StripedLRUCache<Integer, Integer> c = (StripedLRUCache<Integer, Integer>) cache;
            hits = c.getHits();
            misses = c.getMisses();
            evictions = c.getEvictions();
        } else {
            hits = misses = evictions = -1;
        }

        return new BenchmarkResult(cache.name(), durationMs, totalOps, hits, misses, evictions);
    }

    // ═══════════════════════════════════════════════════════════════════════════
    // CORRECTNESS SMOKE TEST
    // ═══════════════════════════════════════════════════════════════════════════

    static void correctnessTest() {
        // Test Global Lock version — deterministic LRU eviction order
        GlobalLockLRUCache<String, Integer> gc = new GlobalLockLRUCache<>(3);
        gc.put("a", 1);
        gc.put("b", 2);
        gc.put("c", 3);
        assert gc.get("a") == 1 : "Expected 1 for key 'a'";
        gc.put("d", 4); // should evict "b" (LRU after "a" was accessed)
        assert gc.get("b") == null : "Expected null — 'b' should be evicted";
        assert gc.get("c") == 3 : "Expected 3 for key 'c'";
        assert gc.get("d") == 4 : "Expected 4 for key 'd'";

        // Test Striped version — basic get/put/update
        StripedLRUCache<String, Integer> sc = new StripedLRUCache<>(3, 2);
        sc.put("x", 10);
        sc.put("y", 20);
        sc.put("z", 30);
        assert sc.get("x") == 10 : "Expected 10 for key 'x'";
        sc.put("x", 99); // update existing key
        assert sc.get("x") == 99 : "Expected 99 for updated key 'x'";

        // Verify capacity enforcement: put 100 keys into a size-5 cache
        GlobalLockLRUCache<Integer, Integer> bounded = new GlobalLockLRUCache<>(5);
        for (int i = 0; i < 100; i++) {
            bounded.put(i, i);
        }
        int found = 0;
        for (int i = 0; i < 100; i++) {
            if (bounded.get(i) != null) found++;
        }
        assert found == 5 : "Expected exactly 5 entries in cache, found " + found;
    }
}