package model;

/**
 * Doubly-linked list node used by both LRU cache implementations.
 * Each node lives simultaneously in:
 *   1. The HashMap (for O(1) key lookup)
 *   2. The DLL (for O(1) recency reordering)
 */
public class Node<K, V> {
    public K key;
    public V value;
    public Node<K, V> prev;
    public Node<K, V> next;

    public Node(K key, V value) {
        this.key = key;
        this.value = value;
    }

    /** Sentinel constructor (dummy head/tail — no key or value) */
    public Node() {
        this(null, null);
    }
}