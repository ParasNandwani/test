package model;

// ═══════════════════════════════════════════════════════════════════════════
// BENCHMARK RESULT
// ═══════════════════════════════════════════════════════════════════════════
public class BenchmarkResult {
    final String cacheName;
    final long durationMs;
    final long totalOps;
    final long hits;
    final long misses;
    final long evictions;

    public BenchmarkResult(String cacheName, long durationMs, long totalOps,
                           long hits, long misses, long evictions) {
        this.cacheName = cacheName;
        this.durationMs = durationMs;
        this.totalOps = totalOps;
        this.hits = hits;
        this.misses = misses;
        this.evictions = evictions;
    }

    public double throughputOpsPerSec() {
        return durationMs == 0 ? Double.MAX_VALUE : (totalOps * 1000.0) / durationMs;
    }

    double hitRate() {
        long total = hits + misses;
        return total == 0 ? 0 : (hits * 100.0) / total;
    }

    public void print() {
        System.out.printf("  %-45s | %,10d ops in %,6d ms | %,.0f ops/sec | hitRate=%.1f%% | evictions=%,d%n",
                cacheName, totalOps, durationMs, throughputOpsPerSec(), hitRate(), evictions);
    }
}
