package model;// ═══════════════════════════════════════════════════════════════════════════
// BENCHMARK CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════════

public class BenchmarkConfig {
    public final int numThreads;
    public final int opsPerThread;
    public final double readRatio;   // 0.0 to 1.0 — fraction of ops that are gets
    public final int keySpaceSize;   // keys drawn from [0, keySpaceSize)
    public final int cacheCapacity;
    public final int numStripes;

    public BenchmarkConfig(int numThreads, int opsPerThread, double readRatio,
                           int keySpaceSize, int cacheCapacity, int numStripes) {
        this.numThreads = numThreads;
        this.opsPerThread = opsPerThread;
        this.readRatio = readRatio;
        this.keySpaceSize = keySpaceSize;
        this.cacheCapacity = cacheCapacity;
        this.numStripes = numStripes;
    }

    @Override
    public String toString() {
        return String.format("threads=%d, ops/thread=%d, readRatio=%.0f%%, keySpace=%d, capacity=%d",
                numThreads, opsPerThread, readRatio * 100, keySpaceSize, cacheCapacity);
    }
}
