# Day 5: High-Performance Concurrent Caches

---

## The Interview Question

> *"Design a thread-safe LRU cache that supports O(1) get and put under high concurrency. How do you handle the fact that even reads mutate the eviction order? How would you scale it to 64 concurrent threads?"*

**What the interviewer is testing:**
- Do you know why LRU reads are secretly writes (pointer mutation)?
- Can you implement HashMap + DLL with O(1) operations?
- Do you understand lock striping and when it helps vs hurts?
- Can you reason about structural deadlocks and how to prevent them?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: Cache Concurrency Fundamentals](#part-1-cache-concurrency-fundamentals)
2. [Part 2: Architecture Overview](#part-2-architecture-overview)
3. [Part 3: Complexity Summary](#part-3-complexity-summary)
4. [Part 4: Benchmark Observation — Why Global Lock Outperforms Striped](#part-4-benchmark-observation--why-global-lock-outperforms-striped)
5. [Part 5: Interview Talking Points](#part-5-interview-talking-points)
6. [Part 6: LFU — How It Differs from LRU](#part-6-lfu--how-it-differs-from-lru)
7. [How to Run](#how-to-run)
8. [Directory Structure](#directory-structure)

---

## Part 1: Cache Concurrency Fundamentals

Before diving into the architecture, let's establish the foundational concepts that make this system non-trivial.

---

### 1. Why an LRU Cache Requires BOTH a HashMap and a Doubly Linked List

An LRU (Least Recently Used) cache must support two operations in **O(1) time**:

| Operation | What it needs |
|-----------|--------------|
| **Lookup by key** | Hash map → O(1) random access |
| **Track & update recency order** | Doubly linked list → O(1) insertion, deletion, reordering |

**Why not just a HashMap?**
A HashMap gives O(1) lookup, but it has no concept of ordering. When the cache is full, you'd need to scan all entries to find the least-recently-used one — that's O(n).

**Why not just a Linked List?**
A linked list maintains order perfectly, but finding a node by key requires O(n) traversal.

**The Hybrid Solution:**
```
HashMap<Key, model.Node>  ──────►  model.Node lives inside a Doubly Linked List
                              (sorted by access recency: HEAD = most recent)
```

- **`get(key)`**: HashMap finds the model.Node in O(1). Then "move" that model.Node to the head of the DLL in O(1) (pointer surgery: unlink from current position, re-link at head).
- **`put(key, value)`**: If key exists, update value and move to head. If key is new, create a model.Node, add to head, insert into HashMap. If capacity exceeded, remove the **tail** node (least recently used) from both the DLL and the HashMap.
- **`evict()`**: Remove the node at the tail of the DLL. Remove its key from the HashMap. Both O(1).

The doubly-linked list uses **sentinel nodes** (dummy head and dummy tail) to eliminate null-checks on boundary operations.

---

### 2. Why Concurrent Reads Behave Like Writes (The Pointer Modification Bottleneck)

In a typical concurrent data structure, reads can proceed in parallel because they don't mutate state. **An LRU cache is fundamentally different.**

Consider `get(key)`:
1. Look up the key in the HashMap → this is a read.
2. Move the found node to the head of the DLL → **this is a WRITE** (pointer mutation).

```
Before get("B"):   HEAD ↔ C ↔ A ↔ B ↔ D ↔ TAIL
After  get("B"):   HEAD ↔ B ↔ C ↔ A ↔ D ↔ TAIL
                         ^^^
                   B's prev/next pointers changed
                   C's prev pointer changed
                   A's next pointer changed (previously pointed to B)
                   D's prev pointer changed (previously pointed to B)
```

Every single `get()` call mutates 4-6 pointers in the linked list. There is **no read-only path** through an LRU cache. This means:

- You **cannot** use a `ReadWriteLock` effectively (there are no true "readers").
- Every operation — get or put — must acquire an exclusive lock on the list structure.
- Under high concurrency, this single lock becomes the throughput bottleneck.

**This is precisely why we need lock striping.**

---

### 3. Lock Striping / Segmentation

**The Idea:** Instead of one big cache with one lock, partition the cache into **N independent segments (stripes)**. Each stripe is a fully self-contained mini-cache with its own:
- Lock
- HashMap
- Doubly Linked List
- Capacity budget (totalCapacity / N)

**Key-to-Stripe Mapping:**
```java
int stripeIndex = Math.abs(key.hashCode() % numStripes);
```

**Why This Scales:**

| Threads | Global Lock (Version A) | 16 Stripes (Version B) |
|---------|------------------------|------------------------|
| 1 | Baseline | ~Same (slight overhead) |
| 4 | High contention | ~4x throughput |
| 16 | Severe contention | ~16x throughput (ideal) |
| 64 | Thrashing | ~16x throughput (saturated at stripe count) |

With N stripes, up to N threads can operate **simultaneously** without contention (assuming uniform key distribution). The theoretical peak parallelism equals the stripe count.

**Trade-offs:**
- Each stripe has capacity `ceil(totalCapacity / N)`, so LRU eviction is **per-stripe**, not globally optimal. A "hot" stripe may evict entries that a global LRU would keep.
- More stripes = more memory overhead (sentinel nodes, lock objects per stripe).
- Diminishing returns past `numStripes > numCores`.

---

### 4. Structural Deadlocks and How to Avoid Them

**What is a structural deadlock?**

If an operation needs to acquire locks on **multiple stripes simultaneously** (e.g., "move key from stripe A to stripe B"), and two threads acquire them in opposite order:

```
Thread 1: lock(stripe[2]) → tries lock(stripe[5]) → BLOCKED
Thread 2: lock(stripe[5]) → tries lock(stripe[2]) → BLOCKED
→ DEADLOCK
```

**How we avoid this in our design:**

1. **Single-stripe-per-operation guarantee:** A key's stripe is determined by its hash and NEVER changes. `get(key)` and `put(key, value)` each touch exactly ONE stripe. No cross-stripe operations exist, so deadlock is structurally impossible.

2. **If cross-stripe operations were needed** (e.g., a `transferIfAbsent(fromKey, toKey)` API), the canonical defense is **lock ordering**: always acquire locks in ascending stripe index order.
   ```java
   int s1 = Math.min(stripeA, stripeB);
   int s2 = Math.max(stripeA, stripeB);
   segments[s1].lock();
   segments[s2].lock();
   // ... do work ...
   segments[s2].unlock();
   segments[s1].unlock();
   ```

3. **Keep critical sections short:** Even within a single stripe, hold the lock only for the pointer surgery + map operation. Never do I/O, allocation-heavy work, or call external code while holding the lock.

---

## Part 2: Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    cache.StripedLRUCache<K, V>              │
│                                                             │
│   put(key, val) / get(key)                                  │
│         │                                                   │
│         ▼                                                   │
│   stripe = hash(key) % N                                    │
│         │                                                   │
│         ▼                                                   │
│  ┌────────────┐  ┌────────────┐       ┌────────────┐        │
│  │ Segment[0] │  │ Segment[1] │  ...  │Segment[N-1]│        │
│  │            │  │            │       │            │        │
│  │ Lock       │  │ Lock       │       │ Lock       │        │
│  │ HashMap    │  │ HashMap    │       │ HashMap    │        │
│  │ DLL (H↔T)  │  │ DLL (H↔T)  │       │ DLL (H↔T)  │        │
│  │ size/cap   │  │ size/cap   │       │ size/cap   │        │
│  └────────────┘  └────────────┘       └────────────┘        │
└─────────────────────────────────────────────────────────────┘
```

### Version A — Global Lock LRU Cache (`cache.GlobalLockLRUCache`)
- Single `ReentrantLock` guards the entire structure.
- One `HashMap<K, model.Node<K,V>>` + one DLL with sentinel head/tail.
- Simple, correct, but serializes all threads.
- **Also serves as the reusable segment unit** for Version B (no separate Segment class needed).

### Version B — Striped (Segmented) Lock LRU Cache (`cache.StripedLRUCache`)
- Array of `cache.GlobalLockLRUCache` instances, each acting as an independent stripe/segment.
- Each segment has its own `ReentrantLock`, `HashMap`, and DLL (inherited from `cache.GlobalLockLRUCache`).
- Capacity distributed as `ceil(totalCapacity / numStripes)` per segment.
- Near-linear throughput scaling up to `numStripes` concurrent threads.
- **Zero code duplication** — `cache.StripedLRUCache` delegates to `cache.GlobalLockLRUCache` instances.

---

## Directory Structure

| File | Purpose |
|------|---------|
| `README.md` | This document — fundamentals + architecture |
| `src/model.Node.java` | Shared doubly-linked list node class used by both cache implementations |
| `src/cache.ConcurrentCache.java` | Common interface (`get`, `put`, `name`) for cache implementations |
| `src/cache.GlobalLockLRUCache.java` | **Version A** — Single global `ReentrantLock` LRU cache. Also reused as the segment unit inside `cache.StripedLRUCache` |
| `src/cache.StripedLRUCache.java` | **Version B** — Routes keys to an array of `cache.GlobalLockLRUCache` instances (stripes) via hash |
| `src/ComprehensiveCacheBenchmark.java` | Multi-threaded benchmark harness + correctness smoke test |
| `src/InterviewLeanCacheBenchmark.java` | Self-contained whiteboard-ready striped LRU (~110 lines of core logic) |

---

## How to Run

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day5:run                                              # Runs ComprehensiveCacheBenchmark
./gradlew :day5:run -PmainClass=InterviewLeanCacheBenchmark      # Runs the lean interview version
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on any `main()` method directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out ComprehensiveCacheBenchmark
java -cp out InterviewLeanCacheBenchmark
```

---

## Part 3: Complexity Summary

| Operation | Time Complexity | Space Complexity |
|-----------|----------------|-----------------|
| `get(key)` | O(1) amortized | — |
| `put(key, val)` | O(1) amortized | — |
| `evict()` | O(1) | — |
| Total space | — | O(capacity) |
| Lock contention (Version B) | O(1/N) probability per op | O(N) lock objects |

---

## Part 4: Benchmark Observation — Why Global Lock Outperforms Striped

In our benchmarks, the global lock version consistently outperforms the striped version across all tested scenarios (varying thread counts, read/write ratios, stripe counts, and key space sizes). This is counterintuitive — after all, the entire point of lock striping is to improve throughput under contention. Here's why:

### Root Causes

**1. Ultra-short critical sections eliminate meaningful contention**

The work protected by the lock is ~5 pointer assignments + 1 HashMap lookup, taking roughly 20-50 nanoseconds. At this timescale, threads acquire and release the lock so quickly that they almost never actually *block*. The lock is "hot" but not "contended" — there's a critical difference:
- **Hot lock:** frequently acquired, but each hold is so brief that waiters rarely accumulate.
- **Contended lock:** multiple threads are simultaneously blocked, waiting their turn.

With a 20-50ns hold time and modern CPU speeds, even 32 threads rarely find the lock occupied when they try to acquire it.

**2. JVM lock optimizations heavily favor a single hot lock**

HotSpot JVM applies aggressive optimizations that make a single lock nearly free:
- **Thin/lightweight locks:** For low-contention, a single CAS (compare-and-swap) is used instead of an OS mutex. No kernel involvement, no context switch.
- **Adaptive spinning:** Before parking a thread, the JVM spins briefly. If the lock is always released within a few nanoseconds, threads never actually park.
- **Lock coarsening:** The JIT compiler may merge adjacent lock/unlock sequences, reducing overhead further.

These optimizations are most effective when there's exactly one lock — the JVM can predict and optimize access patterns beautifully.

**3. Striped version pays overhead that outweighs its benefit**

Each operation in the striped version pays costs that the global version avoids:
- Extra hash computation (`h ^= h >>> 16`) for stripe selection
- Array index calculation + bounds check
- Potential L1/L2 cache misses: 16 separate HashMaps + 16 DLLs scatter across memory, while one global structure stays cache-hot

When the work inside the lock is only 20-50ns, this overhead is proportionally significant — it can represent 20-40% of the total operation cost.

**4. Memory locality favors single structure**

One HashMap + one DLL fits comfortably in L1/L2 cache and stays hot under repeated access. Multiple segments compete for cache lines, causing evictions and stalls at the CPU cache level (not to be confused with LRU cache evictions).

### The Key Insight

Lock striping is designed for scenarios where **lock hold time is non-trivial** — for example, when operations under the lock involve:
- Network I/O (cache-aside fetches from a database)
- Serialization/deserialization of large values
- Expensive computation (crypto, compression)
- Memory allocation-heavy operations

In such real-world systems, the lock is held for microseconds or milliseconds, contention becomes severe, and striping provides massive relief. In a pure in-memory pointer-surgery microbenchmark, the critical section is so fast that contention essentially doesn't exist, and striping's overhead dominates its benefit.

### Interview Soundbite

> "Lock striping trades per-operation overhead (extra hashing, cache misses, memory scatter) for reduced contention. This trade-off only pays off when lock hold time is significant enough for contention to actually occur. In our microbenchmark, the critical section is ~20-50ns of pointer surgery — the JVM's adaptive spinning means threads almost never block, so the contention we're trying to eliminate doesn't meaningfully exist. The striped version pays the overhead cost but never collects the parallelism benefit. In production systems with heavier per-operation work (I/O, serialization), striping would dominate."

---

## Part 5: Interview Talking Points

1. **"Why not ConcurrentHashMap + LinkedList?"** — ConcurrentHashMap gives concurrent reads, but LRU's `get()` mutates the list. You'd still need to lock the list separately, creating a two-lock protocol that's error-prone.

2. **"Why not LinkedHashMap?"** — It uses access-order mode internally, but its iteration/eviction isn't thread-safe, and the interviewer wants to see you manage pointers manually.

3. **"How would you make this distributed?"** — Consistent hashing to partition keys across nodes (each node runs a local striped cache). Gossip protocol or TTL-based invalidation for coherence.

4. **"What about fairness?"** — `ReentrantLock(true)` enables FIFO ordering of waiting threads at the cost of throughput. For caches, unfair locks are typically preferred (higher throughput, acceptable tail latency).

5. **"Why does global lock beat striped in benchmarks?"** — See section above. The critical section is so short (~20-50ns pointer surgery) that the JVM's lock optimizations eliminate real contention, while striping's overhead (hash spreading, cache line misses, memory scatter) dominates. Striping pays off when per-operation work is heavier (I/O, serialization, computation under lock).

---

## Part 6: LFU — How It Differs from LRU

The folder title mentions LFU (Least Frequently Used). While we implement LRU in this project (it's more commonly asked and demonstrates pointer surgery under concurrency), here's how LFU differs and how you'd adapt the striped approach.

### Core Difference

| | LRU (Least Recently Used) | LFU (Least Frequently Used) |
|---|---|---|
| **Eviction criterion** | Evict the entry accessed **longest ago** | Evict the entry accessed the **fewest times** |
| **Tracks** | Recency (time of last access) | Frequency (count of accesses) |
| **Data structure** | HashMap + Doubly Linked List (ordered by recency) | HashMap + Frequency Map + Doubly Linked Lists per frequency |
| **Best for** | General-purpose caching (temporal locality) | Workloads with stable hot keys (frequency locality) |
| **Weakness** | One-time scan pollutes the cache | New entries start at frequency=1, easily evicted before they "warm up" |

### LFU Internal Structure

```
┌─────────────────────────────────────────────────────────────────┐
│  HashMap<Key, Node>                                             │
│    → O(1) lookup by key                                         │
│                                                                 │
│  FrequencyMap<Integer, DoublyLinkedList>                        │
│    freq=1: [nodeA ↔ nodeB ↔ nodeC]     ← least frequent         │
│    freq=2: [nodeD ↔ nodeE]                                      │
│    freq=5: [nodeF]                      ← most frequent         │
│                                                                 │
│  minFrequency: 1  (tracks the lowest active frequency bucket)   │
└─────────────────────────────────────────────────────────────────┘
```

**On `get(key)`:**
1. HashMap lookup → find the node (O(1))
2. Remove node from its current frequency list (e.g., freq=2)
3. Increment node's frequency → move to freq=3 list
4. If the old frequency list is now empty AND it was `minFrequency`, increment `minFrequency`

**On eviction (cache full):**
1. Go to `frequencyMap[minFrequency]`
2. Remove the **tail** of that list (least recently used among least frequently used)
3. Remove from HashMap

### How to Make LFU Concurrent (Adapting Our Striped Approach)

The same striping strategy from our LRU applies:

1. **Stripe by key hash** — each stripe has its own lock, HashMap, and frequency structure
2. **Single-stripe-per-operation** — a key's stripe never changes, so deadlock is impossible
3. **Per-stripe `minFrequency` tracking** — each stripe independently tracks its own minimum

The trade-off is identical to LRU striping: eviction is per-stripe, not globally optimal. A "hot" stripe may evict entries that a globally-aware LFU would keep.

### When to Use LFU Over LRU

| Scenario | Better choice | Why |
|----------|--------------|-----|
| General web cache | LRU | Access patterns are temporal; recent = likely accessed again soon |
| CDN edge cache with stable popular content | LFU | Popular videos/images are accessed thousands of times; they should stay cached regardless of recency |
| Database buffer pool | LRU (or Clock) | SQL queries exhibit temporal locality; LFU would cache stale index pages forever |
| DNS cache | LFU | Popular domains are resolved millions of times; rare domains should be evicted |
| Mixed workload (unknown pattern) | LRU | Safer default; LFU can be gamed by historical hot keys that are no longer relevant |

### Interview Follow-Up

If asked "How would you implement LFU?", the key insight to communicate is:

> "LFU requires O(1) for get, put, and eviction. The trick is maintaining a frequency-indexed collection of doubly-linked lists, plus a `minFrequency` pointer. On access, nodes move between frequency buckets. On eviction, we remove from the `minFrequency` bucket's tail. For concurrency, I'd apply the same lock-striping pattern as LRU — each stripe has its own frequency map and min tracker."

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
