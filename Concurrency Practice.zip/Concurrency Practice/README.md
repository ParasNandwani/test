# Cracking the Concurrency Interview

### A 10-Day Systems Programming Course for Senior/Staff Engineering Interviews

---

## Why This Course Exists

Concurrency, multi-threading, and low-latency systems design are among the **hardest topics to prepare for** in software engineering interviews. The resources online are either too academic (textbook theory without practical application) or too shallow (blog posts that scratch the surface).

This course bridges that gap. It was built from the ground up to take you from **hardware fundamentals to production-grade implementations** in 10 structured days — with theory, working code, and interview-ready talking points for each topic.

---

## Who This Is For

- Engineers preparing for **Staff/Senior-level systems programming rounds**
- Developers who want to deeply understand **how concurrency works at the hardware and JVM level**
- Anyone who has struggled with concurrency in interviews and wants a structured, buildable preparation path

---

## What Makes This Different

| Aspect | What Other Courses Do | What This Course Does |
|--------|----------------------|----------------------|
| **Starting point** | Jump straight to `synchronized` and `volatile` without explaining *why* they exist | Starts at CPU caches, MESI protocol, and cache lines — you understand the hardware *before* the keywords |
| **Theory vs Practice** | Either pure theory (textbooks) or pure code (GitHub repos with no explanation) | Every day has deep theory AND a fully working project you can run and benchmark |
| **Interview readiness** | Teach generic concurrency knowledge | Every day ends with interview talking points, anticipated follow-up Q&A, and common traps |
| **Code quality** | Toy examples (`Thread.sleep()` demos, counter++ with race conditions) | Production-grade patterns: benchmarks, stress tests, graceful shutdown, backpressure handling |
| **Two-track approach** | One-size-fits-all content | Each day has a **Comprehensive version** (full stress tests) AND an **Interview Lean version** (~100 lines, whiteboard-ready) |

---

## What You'll Be Able To Do After

After completing this course, you'll be able to:

1. **Explain** false sharing, cache-line bouncing, and MESI invalidation at a hardware level
2. **Implement** lock-free data structures using CAS, memory barriers, and lazySet()
3. **Build** production systems: WAL-backed stores, concurrent caches, rate limiters, schedulers, message brokers
4. **Articulate** trade-offs between throughput, latency, durability, and correctness in any systems design discussion
5. **Write** correct concurrent code with proper lock safety, condition variables, graceful shutdown, and backpressure handling
6. **Identify** bottlenecks: lock contention, GC pressure, head-of-line blocking, false sharing — and propose fixes

---

## Course Structure

| Day | Topic | What You Build | Key Concepts |
|-----|-------|----------------|--------------|
| **1** | [Concurrency & The Java Memory Model](./Day%201%20-%20Concurrency%20and%20The%20Java%20Memory%20Model/README.md) | Counter Benchmark (4 strategies) | Threads, CPU caches, MESI protocol, CAS, false sharing, JMM |
| **2** | [Advanced Synchronization & Memory Management](./Day%202%20-%20Advanced%20Synchronization%20and%20Memory%20Management/README.md) | Metrics Ingestion Pipeline | Memory barriers, lazySet(), StampedLock, SPSC ring buffer, GC pressure |
| **3** | [Storage and File I/O](./Day%203%20-%20Storage%20and%20File%20IO/README.md) | I/O Performance Engine | User/kernel space, page cache, fsync, mmap, sequential vs random I/O |
| **4** | [Durable Key-Value Store with WAL](./Day%204%20-%20Durable%20Key%20Value%20Store%20with%20WAL/README.md) | WAL-backed KV Store | Write-ahead logging, crash recovery, sync vs async durability |
| **5** | [High-Performance Concurrent Caches](./Day%205%20-%20High%20Performance%20Concurrent%20Caches%20LRU%20LFU/README.md) | Striped LRU Cache | HashMap+DLL hybrid, lock striping, structural deadlock prevention |
| **6** | [Schedulers & Rate Limiters](./Day%206%20-%20Multi%20Threaded%20Schedulers%20and%20Token%20Bucket%20Rate%20Limiters/README.md) | Task Scheduler + Token Bucket | Condition variables, awaitNanos, lazy computation, nanoTime |
| **7** | [Double-Buffered Log Aggregator](./Day%207%20-%20Double%20Buffered%20Log%20Aggregator/README.md) | Production Log Engine | Double-buffering, backpressure policies, graceful shutdown |
| **8** | [Concurrent Pub-Sub Queues](./Day%208%20-%20Concurrent%20Pub-Sub%20Queues%20With%20Topics/README.md) | Message Broker with Topics | Fan-out, subscriber isolation, per-consumer buffers, backpressure strategies |
| **9** | [Async Composition with CompletableFuture](./Day%209%20-%20Async%20Composition%20with%20CompletableFuture/README.md) | Async Service Aggregator | CompletableFuture pipelines, fan-out with allOf, timeouts, partial failure recovery |
| **10** | [Interview Playbook & Practice](./Day%2010%20-%20Interview%20Playbook%20and%20Practice%20Questions/README.md) | Synthesis + 3 Timed Simulations | Decision frameworks, cheat sheets, the "10 Commandments", practice questions |

---

## Learning Path

- **Days 1–2**: Foundation — understand hardware-level concurrency (required for everything after)
- **Days 3–4**: Storage — OS-level I/O and durability patterns
- **Days 5–9**: Applied systems — build increasingly complex concurrent systems
- **Day 10**: Review & Practice — synthesize all patterns into a decision framework, then test with timed simulations

---

## How Each Day is Structured

Every day folder contains:

1. **`README.md`** — Theory + prerequisites + architecture diagrams + interview talking points
2. **`src/`** — Working Java source code
3. **`build.gradle`** — Per-day build configuration (auto-detected by IDE)

Most days include two runnable entry points:
- **Comprehensive version** — Full stress tests with assertions (production-grade)
- **Interview Lean version** — Self-contained, whiteboard-ready (~80–150 lines)

---

## Quick Start

### Option A: GitHub Codespaces (Recommended — Zero Setup)

**No JDK? No IDE? No problem.** Run everything directly in your browser — no downloads, no installation, no "works on my machine" issues.

> **New to Codespaces?** It's a cloud-hosted development environment powered by GitHub. Think of it as a full Linux machine + VS Code editor running in your browser tab. Learn more: [GitHub Codespaces Documentation](https://docs.github.com/en/codespaces/overview)

**How to launch:**

1. Go to the [repository page on GitHub](https://github.com/NextLevelSDE/cracking-concurrency-interview)
2. Click the green **"<> Code"** button
3. Select the **"Codespaces"** tab
4. Click **"Create codespace on main"**
5. Wait ~60 seconds for the environment to build

That's it — you'll see VS Code in your browser with Java 17 ready to go. Open the terminal and run:

```bash
./gradlew :day1:run    # Run Day 1
./gradlew :day5:run    # Run Day 5
```

Or click the **▶ Run** button above any `main()` method — the Java Extension Pack enables this automatically.

**What's pre-configured** (via `.devcontainer/devcontainer.json`):

| Component | What You Get |
|-----------|-------------|
| **JDK** | Java 17 (Microsoft OpenJDK image) |
| **IDE** | VS Code in-browser with full Java support |
| **Extensions** | Java Extension Pack (Language Support, Debugger, Test Runner, Maven/Gradle) |
| **Build Tool** | Gradle Wrapper included — no installation needed |
| **Terminal** | Full Linux terminal for running commands |

**Tips:**
- **Free tier:** 60 hours/month free on GitHub Free (120 on Pro) — more than enough for this course
- **Auto-stop:** Codespaces stop after 30 minutes of inactivity; your work is saved
- **Performance:** 2-core / 8GB RAM default — sufficient for all exercises
- **Persistence:** Files are persisted across sessions; only deleted when you delete the codespace

---

### Option B: Run Locally

```bash
# Clone the repo
git clone https://github.com/NextLevelSDE/cracking-concurrency-interview.git
cd cracking-concurrency-interview

# Run any day's code (no Gradle installation needed — wrapper included)
./gradlew :day1:run    # Day 1: Counter Benchmark
./gradlew :day2:run    # Day 2: Metrics Pipeline
./gradlew :day3:run    # Day 3: I/O Benchmark
./gradlew :day4:run    # Day 4: Key-Value Store
./gradlew :day5:run    # Day 5: LRU Cache Benchmark
./gradlew :day6:run    # Day 6: Scheduler + Rate Limiter
./gradlew :day7:run    # Day 7: Double-Buffered Logger
./gradlew :day8:run    # Day 8: Pub-Sub Message Broker
./gradlew :day9:run    # Day 9: Async Service Aggregator
./gradlew :day10:run   # Day 10: Practice Question 1
```

**Requirements:** JDK 17+ (that's it — Gradle Wrapper handles everything else).

**IDE Setup:** Open the root folder in IntelliJ IDEA or VS Code. The IDE will auto-detect the Gradle multi-module project and resolve all 10 days as subprojects. You can then click ▶ on any `main()` method directly.

---

### Running Individual Classes

Beyond the default `./gradlew :dayN:run`, you can run specific classes:

```bash
./gradlew :day6:run -PmainClass=runners.InterviewLeanRunner
./gradlew :day7:run -PmainClass=runners.InterviewLeanFlusherRunner
./gradlew :day8:run -PmainClass=runners.ComprehensivePubSubStressTest
./gradlew :day9:run -PmainClass=runners.ComprehensiveAsyncStressTest
```

Or simply right-click any `main()` method in your IDE and select **Run**.

---

### When to Use Codespaces vs Local

| Scenario | Recommendation |
|----------|---------------|
| You don't have JDK installed | ✅ Use Codespaces |
| You're on a Chromebook / iPad / library computer | ✅ Use Codespaces |
| You want to start immediately without setup | ✅ Use Codespaces |
| You want offline access | Use local setup |
| You prefer IntelliJ IDEA over VS Code | Use local setup |
| You need maximum benchmark accuracy | Use local setup (shared cloud VMs have variable performance) |

---

## Prerequisites

**For local setup only** (skip this if using Codespaces):

- **JDK 17 or higher** (tested with JDK 21)
- An IDE (IntelliJ IDEA recommended, VS Code with Java Extension Pack also works)
- Basic Java familiarity (generics, collections, lambdas)

No other installations required — the Gradle Wrapper (`./gradlew`) is included.

---

## License

This material is licensed under a **Personal Use License**. See the full [LICENSE](./LICENSE) file.

**In short:** You may use these materials for your own personal study and interview preparation. You may NOT redistribute, share, resell, or publicly post these materials. All intellectual property remains with NextLevelSDE.

---

© 2026 NextLevelSDE. All rights reserved.