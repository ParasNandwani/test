package runners;

import engine.AggregatedResult;
import engine.AsyncServiceAggregator;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * INTERVIEW-READY: Minimal, clean demonstration of CompletableFuture-based async aggregation.
 *
 * This file is designed to be presentable on a whiteboard. It shows:
 * 1. Full async aggregation pipeline (fan-out, timeouts, error recovery, combine)
 * 2. Partial failure handling (optional services degrade gracefully)
 * 3. thenCompose (chaining dependent async calls)
 * 4. thenCombine (combining independent async results)
 * 5. anyOf (hedged request pattern)
 * 6. Multiple concurrent aggregations (proving thread efficiency)
 * 7. Proper resource cleanup (AutoCloseable)
 *
 * No external dependencies. No test frameworks. Just core Java concurrency.
 */
public class InterviewLeanAsyncAggregator {

    public static void main(String[] args) throws Exception {
        System.out.println("=== CompletableFuture Async Aggregator Demo ===\n");

        try (AsyncServiceAggregator aggregator = new AsyncServiceAggregator()) {

            // ─── Demo 1: Full aggregation pipeline ───
            System.out.println("[Demo 1] Full async aggregation (4 services concurrently)");
            System.out.println("  Launching: UserService, PricingService, InventoryService, RecommendationService");
            System.out.println("  Calling thread returns IMMEDIATELY — not blocked.\n");

            CompletableFuture<AggregatedResult> future = aggregator.aggregateAsync("req-001");

            // The calling thread is free here! In a web server, it would serve other requests.
            System.out.println("  [Calling thread is free — doing other work while services respond...]");

            // Block only when we actually need the result (e.g., to send HTTP response)
            AggregatedResult result = future.join();

            System.out.println("  Result: " + result);
            System.out.println("  Success: " + result.isSuccess());
            System.out.println("  Total latency: " + result.getTotalLatency().toMillis() + "ms");
            if (!result.getFailedServices().isEmpty()) {
                System.out.println("  Failed/fallback services: " + result.getFailedServices());
            }

            // ─── Demo 2: thenCompose — dependent async calls ───
            System.out.println("\n[Demo 2] thenCompose: fetch user → then fetch their recommendations");
            System.out.println("  Second call DEPENDS on first result (sequential dependency).\n");

            String composed = aggregator.fetchUserThenRecommendations("user-42").join();
            System.out.println("  Result: " + composed);

            // ─── Demo 3: thenCombine — independent parallel combination ───
            System.out.println("\n[Demo 3] thenCombine: fetch user AND pricing concurrently, combine results");
            System.out.println("  Both calls are INDEPENDENT — run in parallel, combined when both done.\n");

            String combined = aggregator.fetchUserAndPricingCombined("req-002").join();
            System.out.println("  Result: " + combined);

            // ─── Demo 4: anyOf — hedged request (first response wins) ───
            System.out.println("\n[Demo 4] anyOf: hedged request — send to 2 backends, use fastest response");
            System.out.println("  Useful for latency-sensitive systems (hedge your bets).\n");

            String hedged = aggregator.hedgedRequest("critical-data").join();
            System.out.println("  Result: " + hedged);

            // ─── Demo 5: Multiple concurrent aggregations ───
            System.out.println("\n[Demo 5] 10 concurrent aggregation pipelines (simulating 10 HTTP requests)");
            System.out.println("  All 10 launch simultaneously — thread pool handles all of them.\n");

            long start = System.nanoTime();
            List<CompletableFuture<AggregatedResult>> futures = new ArrayList<>();
            for (int i = 0; i < 10; i++) {
                futures.add(aggregator.aggregateAsync("concurrent-" + i));
            }

            // Wait for all 10 to complete
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
            double totalMs = (System.nanoTime() - start) / 1_000_000.0;

            int successes = 0;
            int failures = 0;
            for (CompletableFuture<AggregatedResult> f : futures) {
                if (f.join().isSuccess()) successes++;
                else failures++;
            }

            System.out.printf("  10 aggregations completed in %.0f ms%n", totalMs);
            System.out.printf("  Successes: %d, Failures: %d%n", successes, failures);
            System.out.println("  (If sequential, would take ~10x longer. Parallelism works!)");

            // ─── Demo 6: Service metrics ───
            System.out.println("\n[Service Metrics After All Demos]");
            System.out.println("  " + aggregator.getUserService());
            System.out.println("  " + aggregator.getPricingService());
            System.out.println("  " + aggregator.getInventoryService());
            System.out.println("  " + aggregator.getRecommendationService());

        } // AutoCloseable: I/O executor shut down here

        System.out.println("\n[Aggregator closed — I/O pool shut down cleanly]");
        System.out.println("\n=== Demo Complete ===");
    }
}