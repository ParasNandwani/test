package runners;

import engine.AggregatedResult;
import engine.AsyncServiceAggregator;
import engine.ServiceCall;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Comprehensive stress test for the CompletableFuture-based async aggregation engine.
 *
 * Tests 5 scenarios:
 * 1. High-concurrency aggregation throughput
 * 2. Partial failure recovery (optional services fail, pipeline degrades gracefully)
 * 3. Timeout enforcement (required service exceeds deadline → pipeline fails correctly)
 * 4. Thread pool isolation (I/O pool doesn't starve the system)
 * 5. Resource cleanup (executors shut down properly, no thread leaks)
 *
 * Uses assertions (-ea) for correctness verification.
 */
public class ComprehensiveAsyncStressTest {

    public static void main(String[] args) throws Exception {
        System.out.println("╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║   CompletableFuture Async Aggregator — Stress Test Suite    ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝\n");

        scenario1_highConcurrencyThroughput();
        scenario2_partialFailureRecovery();
        scenario3_timeoutEnforcement();
        scenario4_threadPoolIsolation();
        scenario5_resourceCleanup();

        System.out.println("\n╔══════════════════════════════════════════════════════════════╗");
        System.out.println("║              ALL 5 SCENARIOS PASSED ✓                       ║");
        System.out.println("╚══════════════════════════════════════════════════════════════╝");
    }

    /**
     * Scenario 1: Launch 100 concurrent aggregation pipelines.
     * Proves that the system handles high concurrency without thread exhaustion.
     */
    private static void scenario1_highConcurrencyThroughput() throws Exception {
        System.out.println("── Scenario 1: High-Concurrency Throughput ──────────────────────");
        System.out.println("   Launching 100 concurrent aggregation pipelines...\n");

        try (AsyncServiceAggregator aggregator = new AsyncServiceAggregator()) {
            long start = System.nanoTime();

            List<CompletableFuture<AggregatedResult>> futures = new ArrayList<>();
            for (int i = 0; i < 100; i++) {
                futures.add(aggregator.aggregateAsync("stress-" + i));
            }

            // Wait for all to complete
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
            double totalMs = (System.nanoTime() - start) / 1_000_000.0;

            int successes = 0;
            int failures = 0;
            long totalLatencyMs = 0;
            for (CompletableFuture<AggregatedResult> f : futures) {
                AggregatedResult r = f.join();
                if (r.isSuccess()) successes++;
                else failures++;
                totalLatencyMs += r.getTotalLatency().toMillis();
            }

            double avgLatencyMs = totalLatencyMs / 100.0;

            System.out.printf("   Completed: 100 aggregations in %.0f ms%n", totalMs);
            System.out.printf("   Successes: %d, Failures: %d%n", successes, failures);
            System.out.printf("   Avg per-aggregation latency: %.0f ms%n", avgLatencyMs);
            System.out.printf("   Effective throughput: %.0f aggregations/sec%n", 100 / (totalMs / 1000));

            // Assertions
            assert successes + failures == 100 : "Should have exactly 100 results";
            // With default 1%/2% failure rates on required services, most should succeed
            assert successes >= 80 : "Expected at least 80 successes, got " + successes;
            // Total time should be much less than 100 * per-call latency (parallelism works)
            assert totalMs < 5000 : "100 concurrent aggregations should complete in < 5s, took " + totalMs + "ms";

            System.out.println("   ✓ PASSED\n");
        }
    }

    /**
     * Scenario 2: Force optional services to always fail.
     * Proves that the pipeline degrades gracefully — returns success with fallback values.
     */
    private static void scenario2_partialFailureRecovery() throws Exception {
        System.out.println("── Scenario 2: Partial Failure Recovery ─────────────────────────");
        System.out.println("   Optional services (Inventory, Recs) always fail.");
        System.out.println("   Required services (User, Pricing) always succeed.\n");

        ExecutorService pool = Executors.newFixedThreadPool(10);
        try {
            // Required: always succeed (fast)
            ServiceCall userService = ServiceCall.alwaysSucceeds("UserService", 20, pool);
            ServiceCall pricingService = ServiceCall.alwaysSucceeds("PricingService", 15, pool);

            // Optional: always fail
            ServiceCall inventoryService = ServiceCall.alwaysFails("InventoryService", 10, pool);
            ServiceCall recsService = ServiceCall.alwaysFails("RecommendationService", 10, pool);

            AsyncServiceAggregator aggregator = new AsyncServiceAggregator(
                    userService, pricingService, inventoryService, recsService,
                    500, 200, 1000, pool
            );

            // Run 10 aggregations — all should succeed with fallbacks
            int successCount = 0;
            int fallbackCount = 0;

            for (int i = 0; i < 10; i++) {
                AggregatedResult result = aggregator.aggregateAsync("partial-" + i).join();
                if (result.isSuccess()) successCount++;
                fallbackCount += result.getFailedServices().size();
            }

            System.out.printf("   Successes: %d/10 (all should be 10 — required services ok)%n", successCount);
            System.out.printf("   Fallbacks used: %d (should be 20 — 2 optional × 10 requests)%n", fallbackCount);

            // Assertions
            assert successCount == 10 : "All aggregations should succeed (required services ok)";
            assert fallbackCount == 20 : "Each aggregation should have 2 fallbacks, got " + fallbackCount;

            System.out.println("   ✓ PASSED\n");
        } finally {
            pool.shutdown();
            pool.awaitTermination(5, TimeUnit.SECONDS);
        }
    }

    /**
     * Scenario 3: Required service exceeds timeout.
     * Proves that orTimeout correctly fails the pipeline for required services.
     */
    private static void scenario3_timeoutEnforcement() throws Exception {
        System.out.println("── Scenario 3: Timeout Enforcement ─────────────────────────────");
        System.out.println("   UserService latency=2000ms, timeout=100ms → must fail.");
        System.out.println("   RecsService latency=2000ms, timeout=100ms → must use fallback.\n");

        ExecutorService pool = Executors.newFixedThreadPool(10);
        try {
            // User service: very slow (2 seconds) — will exceed 100ms timeout
            ServiceCall slowUser = ServiceCall.alwaysSucceeds("UserService", 2000, pool);
            ServiceCall fastPricing = ServiceCall.alwaysSucceeds("PricingService", 10, pool);
            ServiceCall fastInventory = ServiceCall.alwaysSucceeds("InventoryService", 10, pool);
            ServiceCall slowRecs = ServiceCall.alwaysSucceeds("RecommendationService", 2000, pool);

            AsyncServiceAggregator aggregator = new AsyncServiceAggregator(
                    slowUser, fastPricing, fastInventory, slowRecs,
                    100,  // required timeout: 100ms (user will exceed this)
                    50,   // optional timeout: 50ms (recs will exceed this)
                    300,  // global timeout: 300ms
                    pool
            );

            AggregatedResult result = aggregator.aggregateAsync("timeout-test").join();

            System.out.printf("   Success: %s (expected: false — required service timed out)%n", result.isSuccess());
            System.out.printf("   Latency: %d ms (should be ~100ms, not 2000ms)%n", result.getTotalLatency().toMillis());

            // Assertions
            assert !result.isSuccess() : "Aggregation should FAIL when required service times out";
            assert result.getTotalLatency().toMillis() < 500 : "Should fail fast (~100ms), not wait for full 2s";

            System.out.println("   ✓ PASSED\n");
        } finally {
            pool.shutdown();
            pool.awaitTermination(5, TimeUnit.SECONDS);
        }
    }

    /**
     * Scenario 4: Prove thread pool isolation.
     * Launch aggregations while also doing CPU-bound work on the calling thread.
     * The calling thread should NOT be blocked.
     */
    private static void scenario4_threadPoolIsolation() throws Exception {
        System.out.println("── Scenario 4: Thread Pool Isolation ───────────────────────────");
        System.out.println("   Launching 20 aggregations while main thread does CPU work.");
        System.out.println("   Main thread must NOT be blocked by I/O calls.\n");

        try (AsyncServiceAggregator aggregator = new AsyncServiceAggregator()) {
            // Launch 20 aggregations — returns immediately
            long launchStart = System.nanoTime();
            List<CompletableFuture<AggregatedResult>> futures = new ArrayList<>();
            for (int i = 0; i < 20; i++) {
                futures.add(aggregator.aggregateAsync("isolation-" + i));
            }
            double launchMs = (System.nanoTime() - launchStart) / 1_000_000.0;

            // Main thread does CPU work while aggregations are in-flight
            long cpuStart = System.nanoTime();
            long sum = 0;
            for (int i = 0; i < 1_000_000; i++) {
                sum += i * i;  // CPU-bound work
            }
            double cpuMs = (System.nanoTime() - cpuStart) / 1_000_000.0;

            // Now wait for aggregations
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();

            System.out.printf("   Launch time (20 pipelines): %.1f ms (should be < 10ms)%n", launchMs);
            System.out.printf("   CPU work on main thread: %.1f ms (ran WHILE I/O was in-flight)%n", cpuMs);
            System.out.printf("   CPU result (prevent optimization): %d%n", sum);

            // Assertions
            assert launchMs < 50 : "Launching pipelines should be near-instant, took " + launchMs + "ms";
            // Main thread was free to do CPU work while I/O was happening
            assert cpuMs < 100 : "CPU work should complete quickly (main thread not blocked)";

            System.out.println("   ✓ PASSED\n");
        }
    }

    /**
     * Scenario 5: Resource cleanup — verify executors shut down and threads are released.
     */
    private static void scenario5_resourceCleanup() throws Exception {
        System.out.println("── Scenario 5: Resource Cleanup ────────────────────────────────");
        System.out.println("   Create aggregator, run work, close it, verify threads stop.\n");

        int threadsBefore = Thread.activeCount();

        // Create, use, and close an aggregator
        AsyncServiceAggregator aggregator = new AsyncServiceAggregator();
        aggregator.aggregateAsync("cleanup-test").join();

        int threadsDuring = Thread.activeCount();
        aggregator.close();

        // Give daemon threads time to terminate
        Thread.sleep(500);
        int threadsAfter = Thread.activeCount();

        System.out.printf("   Threads before: %d%n", threadsBefore);
        System.out.printf("   Threads during: %d (pool threads active)%n", threadsDuring);
        System.out.printf("   Threads after close: %d (pool threads stopped)%n", threadsAfter);

        // The thread count after should be close to before (within tolerance for JVM internals)
        // We can't assert exact equality due to JVM background threads, but pool threads should be gone
        assert threadsDuring > threadsBefore : "Should have more threads while pool is active";
        // After close, daemon threads should terminate (or be very close to terminating)
        assert threadsAfter <= threadsDuring : "Thread count should not grow after close";

        System.out.println("   ✓ PASSED\n");
    }
}