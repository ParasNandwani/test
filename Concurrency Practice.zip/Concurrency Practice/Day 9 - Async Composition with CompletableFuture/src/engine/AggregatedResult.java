package engine;

import java.time.Duration;
import java.time.Instant;
import java.util.*;

/**
 * Immutable result container for the async service aggregation.
 *
 * Tracks which services succeeded, which used fallback values, and total aggregation time.
 * Thread-safety: All fields are final and set at construction. Safe to share across threads
 * without synchronization.
 *
 * This demonstrates how to represent PARTIAL SUCCESS in an async pipeline — the aggregation
 * can succeed overall even if some optional services failed (graceful degradation).
 */
public final class AggregatedResult {

    private final Map<String, String> serviceResponses;  // service name → response (or fallback)
    private final Set<String> failedServices;            // services that used fallback values
    private final Set<String> timedOutServices;          // services that timed out
    private final Duration totalLatency;
    private final Instant timestamp;
    private final boolean success;                       // true if all REQUIRED services succeeded

    private AggregatedResult(Builder builder) {
        this.serviceResponses = Collections.unmodifiableMap(new LinkedHashMap<>(builder.responses));
        this.failedServices = Collections.unmodifiableSet(new LinkedHashSet<>(builder.failed));
        this.timedOutServices = Collections.unmodifiableSet(new LinkedHashSet<>(builder.timedOut));
        this.totalLatency = builder.totalLatency;
        this.timestamp = Instant.now();
        this.success = builder.success;
    }

    /**
     * Returns the response from the specified service.
     * If the service failed and had a fallback, returns the fallback value.
     */
    public String getResponse(String serviceName) {
        return serviceResponses.get(serviceName);
    }

    /**
     * Returns true if the specified service failed and used a fallback value.
     */
    public boolean didServiceFail(String serviceName) {
        return failedServices.contains(serviceName);
    }

    /**
     * Returns true if the specified service timed out.
     */
    public boolean didServiceTimeout(String serviceName) {
        return timedOutServices.contains(serviceName);
    }

    /**
     * Returns true if all required services succeeded (aggregation is valid).
     */
    public boolean isSuccess() {
        return success;
    }

    public Map<String, String> getAllResponses() {
        return serviceResponses;
    }

    public Set<String> getFailedServices() {
        return failedServices;
    }

    public Set<String> getTimedOutServices() {
        return timedOutServices;
    }

    public Duration getTotalLatency() {
        return totalLatency;
    }

    public Instant getTimestamp() {
        return timestamp;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[AggregatedResult success=").append(success);
        sb.append(" latency=").append(totalLatency.toMillis()).append("ms");
        if (!failedServices.isEmpty()) {
            sb.append(" failed=").append(failedServices);
        }
        if (!timedOutServices.isEmpty()) {
            sb.append(" timedOut=").append(timedOutServices);
        }
        sb.append(" responses={");
        serviceResponses.forEach((k, v) -> sb.append("\n    ").append(k).append("=").append(v));
        sb.append("\n  }]");
        return sb.toString();
    }

    // --- Builder ---

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private final Map<String, String> responses = new LinkedHashMap<>();
        private final Set<String> failed = new LinkedHashSet<>();
        private final Set<String> timedOut = new LinkedHashSet<>();
        private Duration totalLatency = Duration.ZERO;
        private boolean success = true;

        public Builder addResponse(String serviceName, String response) {
            responses.put(serviceName, response);
            return this;
        }

        public Builder addFailure(String serviceName, String fallbackValue) {
            responses.put(serviceName, fallbackValue);
            failed.add(serviceName);
            return this;
        }

        public Builder addTimeout(String serviceName, String fallbackValue) {
            responses.put(serviceName, fallbackValue);
            timedOut.add(serviceName);
            failed.add(serviceName);
            return this;
        }

        public Builder totalLatency(Duration duration) {
            this.totalLatency = duration;
            return this;
        }

        public Builder markFailed() {
            this.success = false;
            return this;
        }

        public AggregatedResult build() {
            return new AggregatedResult(this);
        }
    }
}