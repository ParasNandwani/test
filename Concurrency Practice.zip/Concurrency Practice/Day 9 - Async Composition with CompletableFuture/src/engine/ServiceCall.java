package engine;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Simulates an upstream service call with configurable latency and failure behavior.
 *
 * This class models the real-world scenario where your system depends on external services
 * (user service, pricing service, etc.) that have unpredictable latency and may fail.
 *
 * Thread-safety: All fields are final or AtomicLong. Multiple threads can invoke callAsync()
 * concurrently without synchronization.
 *
 * KEY DESIGN CHOICE: Uses a dedicated I/O executor (NOT ForkJoinPool.commonPool()).
 * In production, network calls block the calling thread during I/O wait. If we used the
 * shared ForkJoinPool (which has only N=cores threads), blocking I/O would starve CPU-bound
 * tasks. A dedicated I/O pool with many threads can tolerate many blocked threads.
 */
public class ServiceCall {

    private final String serviceName;
    private final long typicalLatencyMs;
    private final long worstCaseLatencyMs;
    private final double failureRate; // 0.0 to 1.0
    private final ExecutorService ioExecutor;

    // Metrics
    private final AtomicLong totalCalls = new AtomicLong(0);
    private final AtomicLong successCount = new AtomicLong(0);
    private final AtomicLong failureCount = new AtomicLong(0);
    private final AtomicLong timeoutCount = new AtomicLong(0);

    /**
     * Creates a simulated service call.
     *
     * @param serviceName       Human-readable name for logging/metrics
     * @param typicalLatencyMs  Typical response time (used as base for random variation)
     * @param worstCaseLatencyMs Maximum response time (upper bound for random variation)
     * @param failureRate       Probability of failure (0.0 = never fails, 1.0 = always fails)
     * @param ioExecutor        The executor to run the simulated I/O on
     */
    public ServiceCall(String serviceName, long typicalLatencyMs, long worstCaseLatencyMs,
                       double failureRate, ExecutorService ioExecutor) {
        this.serviceName = serviceName;
        this.typicalLatencyMs = typicalLatencyMs;
        this.worstCaseLatencyMs = worstCaseLatencyMs;
        this.failureRate = failureRate;
        this.ioExecutor = ioExecutor;
    }

    /**
     * Initiates an async service call that completes after simulated latency.
     *
     * Returns a CompletableFuture that:
     * - Completes NORMALLY with a response string after simulated delay (success case)
     * - Completes EXCEPTIONALLY with a RuntimeException (failure case, based on failureRate)
     *
     * The calling thread returns IMMEDIATELY — the simulated I/O happens on the ioExecutor.
     *
     * @param requestPayload The request payload (included in the response for tracing)
     * @return CompletableFuture that will complete with the service response
     */
    public CompletableFuture<String> callAsync(String requestPayload) {
        totalCalls.incrementAndGet();

        return CompletableFuture.supplyAsync(() -> {
            // Simulate network latency
            long latency = simulateLatency();
            try {
                Thread.sleep(latency);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new CompletionException(
                        new RuntimeException(serviceName + " interrupted during call"));
            }

            // Simulate random failure
            if (ThreadLocalRandom.current().nextDouble() < failureRate) {
                failureCount.incrementAndGet();
                throw new CompletionException(
                        new RuntimeException(serviceName + " failed: service unavailable"));
            }

            successCount.incrementAndGet();
            return String.format("[%s] response for '%s' (latency=%dms)",
                    serviceName, requestPayload, latency);
        }, ioExecutor);
    }

    /**
     * Simulates variable latency between typical and worst-case bounds.
     * Uses a distribution that clusters around typical latency with occasional spikes.
     */
    private long simulateLatency() {
        double random = ThreadLocalRandom.current().nextDouble();
        // 80% of calls complete near typical latency; 20% have higher latency up to worst case
        if (random < 0.8) {
            // Typical range: typicalLatency ± 20%
            double variation = 0.8 + (ThreadLocalRandom.current().nextDouble() * 0.4); // 0.8 to 1.2
            return (long) (typicalLatencyMs * variation);
        } else {
            // Worst-case range: between typical and worstCase
            return typicalLatencyMs + (long) (ThreadLocalRandom.current().nextDouble()
                    * (worstCaseLatencyMs - typicalLatencyMs));
        }
    }

    /**
     * Creates a service call that always succeeds with fixed latency.
     * Useful for deterministic testing.
     */
    public static ServiceCall alwaysSucceeds(String name, long latencyMs, ExecutorService executor) {
        return new ServiceCall(name, latencyMs, latencyMs, 0.0, executor);
    }

    /**
     * Creates a service call that always fails after fixed latency.
     * Useful for testing error handling paths.
     */
    public static ServiceCall alwaysFails(String name, long latencyMs, ExecutorService executor) {
        return new ServiceCall(name, latencyMs, latencyMs, 1.0, executor);
    }

    public void incrementTimeoutCount() {
        timeoutCount.incrementAndGet();
    }

    // --- Accessors ---

    public String getServiceName() { return serviceName; }
    public long getTotalCalls() { return totalCalls.get(); }
    public long getSuccessCount() { return successCount.get(); }
    public long getFailureCount() { return failureCount.get(); }
    public long getTimeoutCount() { return timeoutCount.get(); }

    @Override
    public String toString() {
        return String.format("[ServiceCall name=%s total=%d success=%d failed=%d timeout=%d]",
                serviceName, totalCalls.get(), successCount.get(),
                failureCount.get(), timeoutCount.get());
    }
}