package engine;

import java.time.Duration;
import java.util.concurrent.*;

/**
 * Async Service Aggregator using CompletableFuture pipelines.
 *
 * This is the core engine that demonstrates:
 * 1. Fan-out: Multiple service calls launched concurrently via supplyAsync()
 * 2. Per-service timeouts: orTimeout for required, completeOnTimeout for optional
 * 3. Error recovery: exceptionally() for optional services (graceful degradation)
 * 4. Composition: allOf() + thenApply() to combine results without blocking
 * 5. Global timeout: orTimeout on the composed future as a safety net
 * 6. Thread pool isolation: Dedicated I/O executor, NOT the shared ForkJoinPool
 *
 * THREAD MODEL:
 * - All service calls execute on the dedicated ioExecutor (blocking I/O).
 * - Transformation/combination stages run on whichever thread completes them.
 * - The calling thread (e.g., HTTP request handler) returns IMMEDIATELY with a
 *   CompletableFuture — it is NEVER blocked.
 *
 * LIFECYCLE:
 * - Call close() to shut down the I/O executor when the aggregator is no longer needed.
 * - Failing to close() causes thread leaks (the I/O pool threads live forever).
 */
public class AsyncServiceAggregator implements AutoCloseable {

    // Service definitions
    private final ServiceCall userService;
    private final ServiceCall pricingService;
    private final ServiceCall inventoryService;
    private final ServiceCall recommendationService;

    // Configuration
    private final long requiredTimeoutMs;     // Timeout for required services (hard fail)
    private final long optionalTimeoutMs;     // Timeout for optional services (use fallback)
    private final long globalTimeoutMs;       // Overall aggregation budget

    // Shared I/O executor for all service calls
    private final ExecutorService ioExecutor;
    private final boolean ownsExecutor; // true if we created the executor (and must shut it down)

    /**
     * Creates an aggregator with default configuration.
     * Uses an internal I/O thread pool sized for concurrent service calls.
     */
    public AsyncServiceAggregator() {
        this.ioExecutor = Executors.newFixedThreadPool(20, r -> {
            Thread t = new Thread(r, "io-pool-" + Thread.currentThread().getId());
            t.setDaemon(true);
            return t;
        });
        this.ownsExecutor = true;

        // Service definitions with typical latency characteristics
        this.userService = new ServiceCall("UserService", 50, 500, 0.01, ioExecutor);
        this.pricingService = new ServiceCall("PricingService", 30, 300, 0.02, ioExecutor);
        this.inventoryService = new ServiceCall("InventoryService", 40, 400, 0.05, ioExecutor);
        this.recommendationService = new ServiceCall("RecommendationService", 100, 800, 0.10, ioExecutor);

        // Timeout configuration
        this.requiredTimeoutMs = 500;   // Required services must respond within 500ms
        this.optionalTimeoutMs = 200;   // Optional services get 200ms before fallback
        this.globalTimeoutMs = 1000;    // Entire aggregation must complete within 1s
    }

    /**
     * Creates an aggregator with custom services and timeouts.
     * Useful for testing with deterministic services.
     */
    public AsyncServiceAggregator(ServiceCall userService, ServiceCall pricingService,
                                   ServiceCall inventoryService, ServiceCall recommendationService,
                                   long requiredTimeoutMs, long optionalTimeoutMs,
                                   long globalTimeoutMs, ExecutorService ioExecutor) {
        this.userService = userService;
        this.pricingService = pricingService;
        this.inventoryService = inventoryService;
        this.recommendationService = recommendationService;
        this.requiredTimeoutMs = requiredTimeoutMs;
        this.optionalTimeoutMs = optionalTimeoutMs;
        this.globalTimeoutMs = globalTimeoutMs;
        this.ioExecutor = ioExecutor;
        this.ownsExecutor = false; // Caller manages the executor lifecycle
    }

    /**
     * Builds and returns the full CompletableFuture pipeline for aggregating service responses.
     *
     * This method returns IMMEDIATELY — the actual I/O happens asynchronously.
     * The returned CompletableFuture completes when all services have responded
     * (or timed out / failed with fallbacks).
     *
     * PIPELINE STRUCTURE:
     * 1. Launch all 4 service calls concurrently (supplyAsync on I/O pool)
     * 2. Attach per-service timeouts (orTimeout / completeOnTimeout)
     * 3. Attach per-service error recovery (exceptionally for optional services)
     * 4. Fan-in with allOf() — wait for all to resolve
     * 5. Combine results into AggregatedResult (thenApply)
     * 6. Apply global timeout as safety net (orTimeout)
     *
     * @param requestId Unique identifier for this aggregation (for tracing/logging)
     * @return CompletableFuture that will complete with the aggregated result
     */
    public CompletableFuture<AggregatedResult> aggregateAsync(String requestId) {
        long startNanos = System.nanoTime();

        // ─── Stage 1: Launch all service calls concurrently ───
        // Each call returns immediately; actual I/O happens on ioExecutor threads.

        // REQUIRED services: use orTimeout (failure on timeout)
        CompletableFuture<String> userF = userService.callAsync("user-" + requestId)
                .orTimeout(requiredTimeoutMs, TimeUnit.MILLISECONDS);

        CompletableFuture<String> pricingF = pricingService.callAsync("pricing-" + requestId)
                .orTimeout(requiredTimeoutMs, TimeUnit.MILLISECONDS);

        // OPTIONAL services: use completeOnTimeout (fallback on timeout) + exceptionally (fallback on error)
        CompletableFuture<String> inventoryF = inventoryService.callAsync("inventory-" + requestId)
                .completeOnTimeout("[InventoryService] FALLBACK: check availability in-store",
                        optionalTimeoutMs, TimeUnit.MILLISECONDS)
                .exceptionally(ex -> "[InventoryService] FALLBACK: " + ex.getMessage());

        CompletableFuture<String> recsF = recommendationService.callAsync("recs-" + requestId)
                .completeOnTimeout("[RecommendationService] FALLBACK: showing popular items",
                        optionalTimeoutMs, TimeUnit.MILLISECONDS)
                .exceptionally(ex -> "[RecommendationService] FALLBACK: " + ex.getMessage());

        // ─── Stage 2: Fan-in — wait for ALL to resolve ───
        // allOf completes when ALL futures are done (success, fallback, or exception).
        // Required services may still fail (orTimeout throws) — we handle that below.

        CompletableFuture<AggregatedResult> resultF = CompletableFuture.allOf(userF, pricingF, inventoryF, recsF)
                .thenApply(v -> {
                    // All futures are now resolved. Build the aggregated result.
                    Duration latency = Duration.ofNanos(System.nanoTime() - startNanos);
                    AggregatedResult.Builder builder = AggregatedResult.builder()
                            .totalLatency(latency);

                    // Required services — join() won't block (already complete)
                    builder.addResponse("UserService", userF.join());
                    builder.addResponse("PricingService", pricingF.join());

                    // Optional services — check if fallback was used
                    String inventoryResp = inventoryF.join();
                    if (inventoryResp.contains("FALLBACK")) {
                        builder.addFailure("InventoryService", inventoryResp);
                    } else {
                        builder.addResponse("InventoryService", inventoryResp);
                    }

                    String recsResp = recsF.join();
                    if (recsResp.contains("FALLBACK")) {
                        builder.addFailure("RecommendationService", recsResp);
                    } else {
                        builder.addResponse("RecommendationService", recsResp);
                    }

                    return builder.build();
                })
                .exceptionally(ex -> {
                    // If a REQUIRED service failed (timeout or error), we reach here.
                    Duration latency = Duration.ofNanos(System.nanoTime() - startNanos);
                    return AggregatedResult.builder()
                            .totalLatency(latency)
                            .addFailure("AGGREGATION", "Required service failed: " + unwrapException(ex))
                            .markFailed()
                            .build();
                });

        // ─── Stage 3: Global timeout safety net ───
        return resultF.orTimeout(globalTimeoutMs, TimeUnit.MILLISECONDS)
                .exceptionally(ex -> {
                    Duration latency = Duration.ofNanos(System.nanoTime() - startNanos);
                    return AggregatedResult.builder()
                            .totalLatency(latency)
                            .addTimeout("GLOBAL", "Aggregation exceeded " + globalTimeoutMs + "ms budget")
                            .markFailed()
                            .build();
                });
    }

    /**
     * Demonstrates thenCompose: chaining a dependent async call.
     * First fetches user, then uses the user ID to fetch personalized recommendations.
     *
     * This shows the thenCompose pattern: the second call DEPENDS on the first result.
     */
    public CompletableFuture<String> fetchUserThenRecommendations(String userId) {
        return userService.callAsync("user-" + userId)
                .orTimeout(requiredTimeoutMs, TimeUnit.MILLISECONDS)
                .thenCompose(userResponse -> {
                    // Use the user response to make a dependent call
                    return recommendationService.callAsync("recs-for-" + userResponse.hashCode())
                            .completeOnTimeout("[Recs] FALLBACK: popular items", optionalTimeoutMs, TimeUnit.MILLISECONDS);
                })
                .exceptionally(ex -> "Pipeline failed: " + unwrapException(ex));
    }

    /**
     * Demonstrates thenCombine: combining two independent async results.
     * Fetches user AND pricing concurrently, then combines them.
     */
    public CompletableFuture<String> fetchUserAndPricingCombined(String requestId) {
        CompletableFuture<String> userF = userService.callAsync("user-" + requestId)
                .orTimeout(requiredTimeoutMs, TimeUnit.MILLISECONDS);

        CompletableFuture<String> pricingF = pricingService.callAsync("pricing-" + requestId)
                .orTimeout(requiredTimeoutMs, TimeUnit.MILLISECONDS);

        return userF.thenCombine(pricingF, (user, pricing) ->
                        "Combined: {user=" + user + ", pricing=" + pricing + "}")
                .exceptionally(ex -> "Combined pipeline failed: " + unwrapException(ex));
    }

    /**
     * Demonstrates anyOf: hedged request pattern (first to respond wins).
     * Sends the same request to multiple backends and uses the fastest response.
     */
    public CompletableFuture<String> hedgedRequest(String payload) {
        CompletableFuture<String> primary = userService.callAsync("primary-" + payload);
        CompletableFuture<String> backup = pricingService.callAsync("backup-" + payload);

        return CompletableFuture.anyOf(primary, backup)
                .thenApply(result -> "Hedged winner: " + result)
                .orTimeout(requiredTimeoutMs, TimeUnit.MILLISECONDS)
                .exceptionally(ex -> "All hedged requests failed: " + unwrapException(ex));
    }

    /**
     * Unwraps nested CompletionException/ExecutionException to get the root cause message.
     */
    private String unwrapException(Throwable ex) {
        Throwable cause = ex;
        while (cause.getCause() != null && cause instanceof CompletionException) {
            cause = cause.getCause();
        }
        return cause.getClass().getSimpleName() + ": " + cause.getMessage();
    }

    // --- Accessors for metrics ---

    public ServiceCall getUserService() { return userService; }
    public ServiceCall getPricingService() { return pricingService; }
    public ServiceCall getInventoryService() { return inventoryService; }
    public ServiceCall getRecommendationService() { return recommendationService; }

    /**
     * Shuts down the I/O executor. Must be called when the aggregator is no longer needed.
     * Failing to call this causes thread leaks.
     */
    @Override
    public void close() {
        if (ownsExecutor) {
            ioExecutor.shutdown();
            try {
                if (!ioExecutor.awaitTermination(5, TimeUnit.SECONDS)) {
                    ioExecutor.shutdownNow();
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                ioExecutor.shutdownNow();
            }
        }
    }
}