# Day 9: Asynchronous Composition with CompletableFuture

---

## The Interview Question

> *"Design an async service aggregator that fetches data from multiple upstream services concurrently, handles partial failures gracefully, enforces per-call timeouts, and composes results — all without blocking threads. Walk me through your CompletableFuture pipeline."*

**What the interviewer is testing:**
- Do you understand why `Future.get()` is a blocking anti-pattern for high-concurrency systems?
- Can you compose async operations without callback hell (thenApply, thenCompose, thenCombine)?
- Do you know how to handle partial failures (exceptionally, handle) without losing successful results?
- Can you articulate the thread model — which thread runs each stage and why it matters?

**The rest of this document builds your complete answer.**

---

## Table of Contents

1. [Part 1: The Problem — Why Future Falls Short](#part-1-the-problem--why-future-falls-short)
2. [Part 2: CompletableFuture — The Async Composition Primitive](#part-2-completablefuture--the-async-composition-primitive)
3. [Part 3: Starting Async Work](#part-3-starting-async-work)
4. [Part 4: Transforming Results](#part-4-transforming-results)
5. [Part 5: Chaining Dependent Async Calls](#part-5-chaining-dependent-async-calls)
6. [Part 6: Combining Independent Results](#part-6-combining-independent-results)
7. [Part 7: Fan-Out with allOf and anyOf](#part-7-fan-out-with-allof-and-anyof)
8. [Part 8: Error Handling](#part-8-error-handling)
9. [Part 9: Timeouts](#part-9-timeouts)
10. [Part 10: The Async Service Aggregator](#part-10-the-async-service-aggregator)
11. [Part 11: Thread Model — Who Runs What?](#part-11-thread-model--who-runs-what)
12. [Part 12: Code Walkthrough](#part-12-code-walkthrough)
13. [How to Run](#how-to-run)
14. [Design Decisions Summary](#design-decisions-summary)
15. [Directory Structure](#directory-structure)
16. [Virtual Threads (Project Loom) — Modern Java Awareness](#virtual-threads-project-loom--modern-java-awareness)

---

## Part 1: The Problem — Why Future Falls Short

In earlier days, we used `ExecutorService` to submit tasks and get back a `Future<T>`. This works — but has a fundamental limitation that becomes a bottleneck at scale.

---

### The Scenario

You're building a product page service. To render a single page, you need data from 3 upstream services:
- **User Service** — fetch user profile (50ms typical, 500ms worst case)
- **Inventory Service** — check stock levels (30ms typical, 2s worst case)
- **Recommendation Service** — personalized suggestions (100ms typical, 3s worst case)

You want all three calls to run **concurrently** (not sequentially), then combine the results.

---

### The Future.get() Approach (Blocking)

```java
ExecutorService pool = Executors.newFixedThreadPool(3);

Future<User> userFuture       = pool.submit(() -> fetchUser(userId));
Future<Stock> stockFuture     = pool.submit(() -> fetchStock(productId));
Future<List<Product>> recsFuture = pool.submit(() -> fetchRecommendations(userId));

// Now combine results...
User user       = userFuture.get(1, SECONDS);       // BLOCKS this thread
Stock stock     = stockFuture.get(1, SECONDS);      // BLOCKS this thread
List<Product> recs = recsFuture.get(1, SECONDS);    // BLOCKS this thread

return new ProductPage(user, stock, recs);
```

---

### Why This Is a Problem

| Issue | Impact |
|-------|--------|
| **Thread blocking** | The calling thread is parked during each `.get()`. In a web server with 200 threads handling requests, each blocked thread is wasted — it could be serving another request. |
| **Sequential waits** | Even though the three calls run concurrently, the *combining* is sequential: wait for user, THEN wait for stock, THEN wait for recs. If user takes 500ms, you can't start combining stock (which finished in 30ms) until after that. |
| **No composition** | You can't say "when user AND stock are done, compute X." You must manually orchestrate with `.get()` calls. |
| **No error recovery** | If the recommendation service fails, the entire `.get()` throws. You can't gracefully return a page without recommendations — it's all or nothing. |
| **Callback hell alternative** | Without CompletableFuture, the only non-blocking option is raw callbacks — which leads to deeply nested, unreadable code. |

**The core limitation:** `Future<T>` is a **one-shot value box**. You can submit work and later retrieve the result, but you cannot *chain*, *compose*, or *react* to completion without blocking.

---

### What We Need

A primitive that supports:
1. **Non-blocking composition** — "when A completes, automatically start B using A's result"
2. **Parallel combination** — "when A AND B both complete, combine their results"
3. **Error recovery** — "if A fails, use fallback value X instead"
4. **Timeout enforcement** — "if A doesn't complete in 500ms, use default"
5. **No thread blocking** — the thread that created the pipeline stays free to do other work

That primitive is `CompletableFuture<T>`.

---

## Part 2: CompletableFuture — The Async Composition Primitive

`CompletableFuture<T>` is Java's implementation of **Promises** (familiar from JavaScript) or **Futures with continuations**. It represents a value that *will be available in the future*, and lets you attach transformations, combinations, and error handlers that execute automatically when the value arrives.

### The Mental Model

Think of it as a **pipeline of stages**:

```
Stage 1         Stage 2              Stage 3            Stage 4
[Start work] → [Transform result] → [Combine with B] → [Handle errors]
   async           thenApply            thenCombine        exceptionally
```

Each stage:
- Executes **only when the previous stage completes**.
- Runs on a **thread from the ForkJoinPool** (or a custom executor).
- Passes its result to the **next stage** automatically.
- Does NOT block any thread while waiting.

### CompletableFuture vs Future

| Capability | `Future<T>` | `CompletableFuture<T>` |
|------------|-------------|----------------------|
| Submit async work | ✓ (via ExecutorService) | ✓ (supplyAsync) |
| Block until result | ✓ (.get()) | ✓ (.get() / .join()) |
| Transform result without blocking | ✗ | ✓ (thenApply) |
| Chain async calls | ✗ | ✓ (thenCompose) |
| Combine multiple futures | ✗ | ✓ (thenCombine, allOf) |
| Handle errors without try/catch | ✗ | ✓ (exceptionally, handle) |
| Timeouts without external timer | ✗ | ✓ (orTimeout, completeOnTimeout) |
| Attach callbacks on completion | ✗ | ✓ (thenAccept, whenComplete) |

---

## Part 3: Starting Async Work

### supplyAsync — Async computation that returns a value

```java
CompletableFuture<User> userFuture = CompletableFuture.supplyAsync(() -> {
    return fetchUser(userId);  // Runs on ForkJoinPool.commonPool() thread
});
```

The lambda executes **immediately on a background thread**. The calling thread continues without blocking.

### runAsync — Async computation with no return value

```java
CompletableFuture<Void> logFuture = CompletableFuture.runAsync(() -> {
    auditLog.record("page-view", userId);  // Fire and forget
});
```

### With a custom executor

```java
ExecutorService ioPool = Executors.newFixedThreadPool(20);

CompletableFuture<User> userFuture = CompletableFuture.supplyAsync(
    () -> fetchUser(userId),
    ioPool  // Use OUR pool, not the shared ForkJoinPool
);
```

**Why use a custom executor?** The default `ForkJoinPool.commonPool()` has as many threads as CPU cores. If your async tasks do I/O (network, disk), they'll block those threads and starve CPU-bound work. Use a separate I/O pool.

---

## Part 4: Transforming Results

### thenApply — Synchronous transformation (like .map())

```java
CompletableFuture<String> nameFuture = userFuture.thenApply(user -> {
    return user.getFirstName() + " " + user.getLastName();  // Runs when userFuture completes
});
```

`thenApply` takes the completed value, applies a function, and produces a new `CompletableFuture` with the transformed value. The function runs on the completing thread (or the caller's thread if already complete).

### thenAccept — Consume without producing a new value

```java
userFuture.thenAccept(user -> {
    System.out.println("Fetched user: " + user.getName());
});
```

Returns `CompletableFuture<Void>` — useful for side effects (logging, metrics).

### thenRun — Run arbitrary code after completion (ignores the result)

```java
userFuture.thenRun(() -> {
    metrics.increment("user-fetches");
});
```

### The *Async* variants

Every method has an `Async` version that guarantees execution on a **different thread**:

```java
userFuture.thenApplyAsync(user -> transform(user));          // Runs on ForkJoinPool thread
userFuture.thenApplyAsync(user -> transform(user), ioPool);  // Runs on our custom pool
```

**When to use Async variants:** When the transformation itself is expensive (CPU-heavy parsing, serialization) and you don't want to block the thread that completed the previous stage.

---

## Part 5: Chaining Dependent Async Calls

### thenCompose — Chain async calls (like .flatMap())

When the transformation itself returns a `CompletableFuture`, use `thenCompose` to avoid nested futures:

```java
// Step 1: Fetch user
// Step 2: Using the user's ID, fetch their orders (another async call)
CompletableFuture<List<Order>> ordersFuture = userFuture.thenCompose(user -> {
    return fetchOrders(user.getId());  // Returns CompletableFuture<List<Order>>
});
```

**Without thenCompose (wrong):**
```java
// thenApply would give us CompletableFuture<CompletableFuture<List<Order>>> — nested!
CompletableFuture<CompletableFuture<List<Order>>> nested = userFuture.thenApply(user -> {
    return fetchOrders(user.getId());
});
```

**The rule:** If your transformation function returns a plain value → `thenApply`. If it returns a `CompletableFuture` → `thenCompose`.

---

## Part 6: Combining Independent Results

### thenCombine — Combine two independent futures

```java
CompletableFuture<User> userFuture = fetchUserAsync(userId);
CompletableFuture<Stock> stockFuture = fetchStockAsync(productId);

CompletableFuture<ProductInfo> combined = userFuture.thenCombine(stockFuture, (user, stock) -> {
    return new ProductInfo(user.getName(), stock.getQuantity());
});
```

Both futures run **concurrently**. When **both** complete, the combiner function runs. Neither blocks the other.

### Combining more than two

For 3+ futures, chain `thenCombine` calls:

```java
CompletableFuture<PageData> page = userFuture
    .thenCombine(stockFuture, (user, stock) -> new Partial(user, stock))
    .thenCombine(recsFuture, (partial, recs) -> new PageData(partial, recs));
```

Or use `allOf` (next section) for cleaner fan-out patterns.

---

## Part 7: Fan-Out with allOf and anyOf

### allOf — Wait for ALL futures to complete

```java
CompletableFuture<User> userF = fetchUserAsync(userId);
CompletableFuture<Stock> stockF = fetchStockAsync(productId);
CompletableFuture<List<Product>> recsF = fetchRecsAsync(userId);

CompletableFuture<Void> allDone = CompletableFuture.allOf(userF, stockF, recsF);

// When ALL complete, combine results:
CompletableFuture<PageData> page = allDone.thenApply(v -> {
    // At this point, all three are guaranteed complete — .join() won't block
    User user = userF.join();
    Stock stock = stockF.join();
    List<Product> recs = recsF.join();
    return new PageData(user, stock, recs);
});
```

**Key insight:** `allOf` returns `CompletableFuture<Void>` — it signals completion but doesn't carry the values. You retrieve values from the individual futures using `.join()` (which won't block since they're already complete).

### anyOf — First to complete wins

```java
CompletableFuture<Object> fastest = CompletableFuture.anyOf(
    fetchFromPrimary(key),
    fetchFromReplica(key),
    fetchFromCache(key)
);

fastest.thenAccept(result -> {
    // Use whichever completed first
    respondToClient((String) result);
});
```

**Use case:** Hedged requests — send the same request to multiple backends and use the fastest response. Common in latency-sensitive systems.

---

## Part 8: Error Handling

Errors in async pipelines are tricky. CompletableFuture provides three strategies:

### exceptionally — Recover from exceptions with a fallback value

```java
CompletableFuture<List<Product>> recsFuture = fetchRecsAsync(userId)
    .exceptionally(ex -> {
        log.warn("Recommendation service failed: " + ex.getMessage());
        return Collections.emptyList();  // Graceful degradation
    });
```

If the upstream stage completes normally, `exceptionally` is skipped. If it fails, the function runs and provides a fallback. The pipeline continues with the fallback value.

### handle — Access both result and exception

```java
CompletableFuture<Response> responseFuture = fetchDataAsync()
    .handle((result, ex) -> {
        if (ex != null) {
            return Response.error("Service unavailable: " + ex.getMessage());
        }
        return Response.success(result);
    });
```

`handle` always runs — regardless of success or failure. Exactly one of `result` or `ex` will be non-null.

### whenComplete — Side effects without transforming the result

```java
fetchDataAsync()
    .whenComplete((result, ex) -> {
        if (ex != null) {
            metrics.increment("fetch-failures");
        } else {
            metrics.increment("fetch-successes");
        }
    })
    .thenApply(result -> process(result));  // Pipeline continues unchanged
```

`whenComplete` is like `handle` but **doesn't change the value** flowing through the pipeline. It's for observability (logging, metrics).

---

## Part 9: Timeouts

### orTimeout — Fail with exception if not completed in time (Java 9+)

```java
CompletableFuture<User> userFuture = fetchUserAsync(userId)
    .orTimeout(500, TimeUnit.MILLISECONDS);  // Throws TimeoutException after 500ms
```

If the future hasn't completed in 500ms, it completes exceptionally with `TimeoutException`. You can chain `.exceptionally()` to handle it:

```java
CompletableFuture<User> userFuture = fetchUserAsync(userId)
    .orTimeout(500, TimeUnit.MILLISECONDS)
    .exceptionally(ex -> {
        if (ex.getCause() instanceof TimeoutException) {
            return User.anonymous();  // Fallback for timeout
        }
        throw new CompletionException(ex);
    });
```

### completeOnTimeout — Use a default value if not completed in time (Java 9+)

```java
CompletableFuture<List<Product>> recsFuture = fetchRecsAsync(userId)
    .completeOnTimeout(Collections.emptyList(), 200, TimeUnit.MILLISECONDS);
```

If the future hasn't completed in 200ms, it completes normally with the provided default value. No exception — the pipeline continues smoothly with the default.

**When to use which:**
- `orTimeout` → when missing the deadline is an error (user service MUST respond)
- `completeOnTimeout` → when the result is optional and a default is acceptable (recommendations are nice-to-have)

---

## Part 10: The Async Service Aggregator

Now we combine everything into a real-world system: an **Async Service Aggregator** that fetches data from multiple upstream services concurrently, handles partial failures, enforces timeouts, and composes results.

---

### The Scenario

A product page API must aggregate data from 4 services:

| Service | Typical Latency | Failure Rate | Required? |
|---------|----------------|--------------|-----------|
| User Profile | 50ms | 1% | Yes — page fails without it |
| Pricing | 30ms | 2% | Yes — page fails without it |
| Inventory | 40ms | 5% | No — show "check availability" on failure |
| Recommendations | 100ms | 10% | No — show empty list on failure |

**Requirements:**
1. All 4 calls must execute concurrently (total latency ≈ max individual latency, not sum)
2. Required services: if they fail → entire aggregation fails
3. Optional services: if they fail → use graceful fallback
4. Per-service timeouts: configurable per call
5. Global timeout: entire aggregation must complete within a budget
6. Thread efficiency: calling thread must NOT block

---

### The Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│                     AsyncServiceAggregator                             │
├──────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  Calling Thread (e.g., HTTP request handler)                         │
│       │                                                              │
│       ├── supplyAsync(fetchUser)     ──► I/O Pool Thread 1           │
│       ├── supplyAsync(fetchPricing)  ──► I/O Pool Thread 2           │
│       ├── supplyAsync(fetchStock)    ──► I/O Pool Thread 3           │
│       ├── supplyAsync(fetchRecs)     ──► I/O Pool Thread 4           │
│       │                                                              │
│       │   (All 4 execute CONCURRENTLY)                               │
│       │                                                              │
│       ├── Per-service timeout (orTimeout / completeOnTimeout)        │
│       ├── Per-service error handling (exceptionally for optional)    │
│       │                                                              │
│       ├── allOf(userF, pricingF, stockF, recsF)                      │
│       │       │                                                      │
│       │       └── thenApply: combine results into AggregatedPage     │
│       │                                                              │
│       ├── orTimeout(globalBudget) on the combined future             │
│       │                                                              │
│       └── Returns CompletableFuture<AggregatedPage> to caller        │
│                                                                      │
│  Calling thread is FREE — never blocked!                             │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

---

### Key Design Decisions

| Decision | Why |
|----------|-----|
| **Custom I/O pool** (not ForkJoinPool) | Network calls block threads. ForkJoinPool has N=cores threads — blocking them starves CPU-bound work. A dedicated I/O pool with 20+ threads can have many blocked without impact. |
| **Per-service timeouts** | Each service has different SLAs. User service gets 500ms (critical); recommendations get 200ms (optional, degradable). |
| **completeOnTimeout for optional** | Recommendations and inventory are nice-to-have. A timeout returns a safe default, not an error. |
| **orTimeout for required** | User and pricing are mandatory. A timeout is a real failure that should propagate. |
| **exceptionally per optional service** | If recommendations throw (not just timeout), we still recover with empty list. |
| **allOf for fan-out** | All calls start simultaneously. We wait for all to resolve (success or fallback). |
| **Global timeout on composed future** | Even if individual timeouts are generous, the page has a total budget (e.g., 1 second). |

---

## Part 11: Thread Model — Who Runs What?

Understanding which thread runs each stage is critical for interviews. Getting this wrong leads to thread starvation or deadlocks.

### Default behavior

| Method | Where the stage runs |
|--------|---------------------|
| `supplyAsync(fn)` | ForkJoinPool.commonPool() |
| `supplyAsync(fn, executor)` | The provided executor |
| `thenApply(fn)` | Either the completing thread OR the calling thread (whoever arrives last) |
| `thenApplyAsync(fn)` | ForkJoinPool.commonPool() (guaranteed different thread) |
| `thenApplyAsync(fn, executor)` | The provided executor |

### The "whoever completes last" rule

For non-`Async` methods (`thenApply`, `thenCombine`, `thenAccept`):
- If the upstream future is **already complete** when you attach the handler → runs on the **current thread** (the one calling `.thenApply()`).
- If the upstream future is **not yet complete** → runs on the **thread that completes it**.

### Interview trap: ForkJoinPool saturation

```java
// DANGEROUS: All stages compete for the same N-core pool
CompletableFuture.supplyAsync(() -> blockingHttpCall())    // Blocks a FJP thread
    .thenApply(response -> heavyParsing(response))         // Needs a FJP thread too
    .thenCompose(data -> anotherBlockingCall(data));        // Blocks ANOTHER FJP thread
```

If you submit more blocking tasks than the pool has threads, the pipeline **deadlocks** — downstream stages can't run because upstream stages hold all the threads.

**The fix:** Use separate executors for I/O vs computation:

```java
ExecutorService ioPool = Executors.newFixedThreadPool(20);      // For blocking I/O
ExecutorService cpuPool = Executors.newFixedThreadPool(cores);  // For computation

CompletableFuture.supplyAsync(() -> blockingHttpCall(), ioPool)
    .thenApplyAsync(response -> heavyParsing(response), cpuPool)
    .thenComposeAsync(data -> anotherBlockingCall(data), ioPool);
```

---

## Part 12: Code Walkthrough

Read the code in this order for maximum understanding. Each file builds on concepts from the previous.

### File 1: `engine/ServiceCall.java` — Start Here (Simplest)
**What to look for:**
- Simulates an upstream service with configurable latency and failure rate.
- Returns a `CompletableFuture<String>` that completes after the simulated delay.
- Uses a dedicated executor for I/O simulation — NOT the ForkJoinPool.

### File 2: `engine/AggregatedResult.java` — The Result Container
**What to look for:**
- Immutable record holding the combined results from all services.
- Tracks which services succeeded and which used fallback values.
- Demonstrates how partial success is represented in the domain model.

### File 3: `engine/AsyncServiceAggregator.java` — The Core Pipeline
**What to look for:**
- `aggregateAsync()` — builds the entire CompletableFuture pipeline.
- Per-service timeout strategy (orTimeout vs completeOnTimeout).
- Error recovery for optional services (exceptionally).
- Fan-out via `allOf()` + combination via `thenApply()`.
- Global timeout on the composed result.
- Proper executor lifecycle management (shutdown in close()).

### File 4: `runners/InterviewLeanAsyncAggregator.java` — Clean Demonstration
**What to look for:** A step-by-step walkthrough showing: normal operation (all services succeed), partial failure (optional service fails gracefully), timeout handling, multiple concurrent aggregations, and pipeline composition.

### File 5: `runners/ComprehensiveAsyncStressTest.java` — Proof Under Pressure
**What to look for:** 5 scenarios stress-testing concurrent aggregation throughput, failure recovery, timeout enforcement, thread pool isolation, and resource cleanup.

---

## How to Run

### Run via Gradle (Recommended)

```bash
# From the course root directory:
./gradlew :day9:run                                                             # Runs InterviewLeanAsyncAggregator
./gradlew :day9:run -PmainClass=runners.ComprehensiveAsyncStressTest            # Runs stress test
```

**IDE:** Open the course root folder in IntelliJ IDEA or VS Code. Click ▶ on any `main()` method directly.

### Alternative: Manual Compile and Run

```bash
# From this day's directory:
find src -name "*.java" | xargs javac -d out
java -cp out runners.InterviewLeanAsyncAggregator
java -ea -cp out runners.ComprehensiveAsyncStressTest
```

---

## Design Decisions Summary

| Decision | Problem it solves | Alternative considered | Why we rejected it |
|----------|------------------|----------------------|-------------------|
| `CompletableFuture` over raw `Future` | Non-blocking composition of async results | `Future.get()` with manual threading | Blocking threads; no composition; no error recovery |
| Dedicated I/O `ExecutorService` | Thread pool isolation | ForkJoinPool.commonPool() | FJP has N=cores threads; blocking I/O starves CPU-bound tasks |
| `completeOnTimeout` for optional services | Graceful degradation | `orTimeout` + catch | Cleaner semantics; no exception thrown for expected case |
| `orTimeout` for required services | Fail-fast on critical path | No timeout (wait forever) | Unbounded waits cascade into system-wide stalls |
| `exceptionally` per-service | Partial failure isolation | Global try-catch around `.join()` | Global catch loses granularity; can't have per-service fallbacks |
| `allOf` for fan-out | Parallel execution of independent calls | Sequential thenCompose chain | Sequential = total latency is SUM; parallel = total latency is MAX |
| Immutable `AggregatedResult` | Thread-safe result sharing | Mutable builder with locks | Immutable = zero synchronization needed; safe to cache/log/return |
| `thenApplyAsync` for heavy transforms | Prevent completing thread from doing expensive work | `thenApply` (runs on completing thread) | If completing thread is an I/O thread, heavy work blocks the I/O pool |

---

## Directory Structure

```
src/
├── engine/
│   ├── ServiceCall.java             # Simulated upstream service (configurable latency + failure)
│   ├── AggregatedResult.java        # Immutable result container with partial-success tracking
│   └── AsyncServiceAggregator.java  # Core CF pipeline: fan-out, timeouts, error recovery, combine
└── runners/
    ├── InterviewLeanAsyncAggregator.java     # Whiteboard-ready demo (~120 lines)
    └── ComprehensiveAsyncStressTest.java     # 5-scenario stress test with assertions
```

---

## Virtual Threads (Project Loom) — Modern Java Awareness

> **Available since:** Java 21 (September 2023) — production-ready, not preview.

### What Are Virtual Threads?

Virtual threads are lightweight threads managed by the JVM, not the OS. They allow you to write blocking-style code that scales like async code.

| Property | Platform Threads (traditional) | Virtual Threads (Loom) |
|----------|-------------------------------|----------------------|
| Managed by | OS kernel | JVM runtime |
| Stack size | ~1 MB | ~few KB (grows on demand) |
| Creation cost | ~1 ms + kernel syscall | ~1 µs (just a Java object) |
| Max practical count | ~2,000-10,000 per JVM | ~1,000,000+ per JVM |
| Context switch cost | ~1-10 µs (kernel) | ~100-200 ns (JVM internal) |
| Scheduling | OS scheduler (preemptive) | JVM scheduler (cooperative at I/O points) |

### When Virtual Threads Help

Virtual threads shine for **I/O-bound workloads** — situations where threads spend most of their time waiting (network calls, database queries, file I/O):

```java
// Before (limited to ~200 concurrent requests by thread pool size):
ExecutorService pool = Executors.newFixedThreadPool(200);

// After (can handle 100,000 concurrent requests, each on its own virtual thread):
ExecutorService pool = Executors.newVirtualThreadPerTaskExecutor();
```

### When Virtual Threads Do NOT Help

| Scenario | Why virtual threads don't help | What to use instead |
|----------|-------------------------------|---------------------|
| **CPU-bound computation** | Virtual threads yield at I/O points; CPU-bound code never yields → no benefit | Platform threads pinned to cores |
| **Lock contention (synchronized)** | `synchronized` blocks PIN the carrier thread, defeating the purpose | Use `ReentrantLock` instead (Loom-friendly) |
| **Low-latency hot paths** | Our ring buffers, CAS loops, lock-free structures are already at nanosecond scale | Keep using platform threads + manual primitives |
| **Thread-local heavy code** | Virtual threads create millions of instances → millions of ThreadLocal copies | Scoped Values (JEP 429) |

### The Key Interview Awareness Point

> "Virtual threads don't replace the concurrency patterns we've built in this course. They replace the *threading model* for I/O-heavy services. A virtual thread still needs a lock if it shares mutable state. It still needs a bounded buffer if producers are faster than consumers. The concurrency *primitives* (locks, CAS, conditions, memory barriers) are unchanged — what changes is that you can now have a million threads without running out of OS resources."

### How to Create Virtual Threads

```java
// Option 1: Executor (recommended)
try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
    executor.submit(() -> handleRequest(request));
}

// Option 2: Thread.ofVirtual()
Thread.ofVirtual().name("handler-", 0).start(() -> handleRequest(request));

// Option 3: Structured Concurrency (preview in Java 21+)
try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {
    var user = scope.fork(() -> fetchUser(id));
    var order = scope.fork(() -> fetchOrder(id));
    scope.join();
    return new Response(user.get(), order.get());
}
```

---

## License

This material is licensed under a **Personal Use License**. See the [LICENSE](../LICENSE) file in the course root. Redistribution, sharing, or public posting is prohibited.
